[
  {
    "title": "whisker of boxplot",
    "href": "http://onetipperday.sterding.com/2012/06/about-boxplot.html"
  },
  {
    "title": "First Bayesian Mixer Meeting in London",
    "href": "http://www.magesblog.com/2016/02/first-bayesian-mixer-meeting-in-london.html"
  },
  {
    "title": "Using the new ‘viridis’ colormap in R (thanks to Simon Garnier)",
    "href": "http://rud.is/b/2015/07/20/using-the-new-viridis-colormap-in-r-thanks-to-simon-garnier/"
  },
  {
    "title": "Recognizing Patterns in the Purchase Process by Following the Pathways Marked By Others",
    "href": "http://joelcadwell.blogspot.com/2014/09/recognizing-patterns-in-purchase.html"
  },
  {
    "title": "European MEP Data",
    "href": "http://wiekvoet.blogspot.com/2014/05/european-election-data.html"
  },
  {
    "title": "For a short time: Half Off Some Manning Data Science Books",
    "href": "http://www.win-vector.com/blog/2016/05/for-a-short-time-half-off-some-manning-data-science-books/"
  },
  {
    "title": "Should I use premium Diesel? Result: No",
    "href": "http://wiekvoet.blogspot.com/2015/05/should-i-use-premium-diesel-result-no.html"
  },
  {
    "title": "The grade level of Congress speeches, analyzed with R",
    "href": "http://blog.revolutionanalytics.com/2012/05/the-grade-level-of-congress-speeches-analyzed-with-r.html"
  },
  {
    "title": "Predicting Pizza",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2010/03/predicting-pizza.html"
  },
  {
    "title": "Hard drive occupation prediction with R – part 2",
    "href": "http://www.lpenz.org/articles/df0pred-2/"
  },
  {
    "title": "The Answer Depends on the Question",
    "href": "http://www.johnmyleswhite.com/notebook/2010/11/03/the-answer-depends-on-the-question/"
  },
  {
    "title": "Downloading CBS Fantasy Football Projections in R",
    "href": "http://fantasyfootballanalytics.net/2013/03/downloading-cbs-fantasy-football.html"
  },
  {
    "title": "Filtering cases",
    "href": "http://learningrbasic.blogspot.com/2009/06/filtering-cases.html"
  },
  {
    "title": "FIFA 15 Analysis with R",
    "href": "http://suehpro.blogspot.com/2014/09/fifa-15-analysis-with-r.html"
  },
  {
    "title": "Plotting conditional densities",
    "href": "http://rsnippets.blogspot.com/2012/04/plotting-conditional-densities.html"
  },
  {
    "title": "A Video Tour of R, for Beginners",
    "href": "http://blog.revolutionanalytics.com/2012/11/a-video-tour-of-r-for-beginners.html"
  },
  {
    "title": "Mary, Chloe, and Miriam at breakfast",
    "href": "http://biostatmatt.com/archives/443"
  },
  {
    "title": "Updates for Proportional Minimum Variance and Adaptive Shrinkage methods",
    "href": "https://systematicinvestor.wordpress.com/2013/10/29/updates-for-proportional-minimum-variance-and-adaptive-shrinkage-methods/"
  },
  {
    "title": "Wanted: R Analysis of New Scientist Covers",
    "href": "http://blog.revolutionanalytics.com/2010/08/wanted-analysis-of-new-scientist-covers.html"
  },
  {
    "title": "Rblpapi: Connecting R to Bloomberg",
    "href": "http://dirk.eddelbuettel.com/blog/2015/08/14/"
  },
  {
    "title": "R User Groups and \"after hours\" Creativity",
    "href": "http://blog.revolutionanalytics.com/2014/10/r-user-groups-and-after-hours-creativity.html"
  },
  {
    "title": "Temporary Debian mail outage",
    "href": "http://dirk.eddelbuettel.com/blog/2009/05/23/"
  },
  {
    "title": "Export R plot to Illustrator or Inkscape",
    "href": "https://web.archive.org/web/http://eldonprince.com/2012/09/06/export-r-plot-to-illustrator-or-inkscape/"
  },
  {
    "title": "Evaluating the Potential Incorporation of R into Research Methods Education in Psychology",
    "href": "http://jeromyanglim.blogspot.com/2013/07/evaluating-potential-incorporation-of-r.html"
  },
  {
    "title": "R editor improvements for Bio7",
    "href": "http://bio7.org/?p=2276"
  },
  {
    "title": "Designing and Analyzing Studies with Optmatch and RItools (Part 1)",
    "href": "http://www.markmfredrickson.com/thoughts/2011-04-26-draft-designing-and-analyzing-studies-with-optmatch-and-ritools-part-1.html"
  },
  {
    "title": "All your models belong to us: how to combine package archivist and function trace()",
    "href": "http://smarterpoland.pl/index.php/2016/05/all-your-models-belong-to-us-how-to-combine-package-archivist-and-function-trace/"
  },
  {
    "title": "Google Correlate Certainly Does Not Imply Causation",
    "href": "https://web.archive.org/web/http://www.speakingstatistically.com/2011/07/google-correlate-certainly-does-not.html"
  },
  {
    "title": "Integration of R, RStudio and Hadoop in a VirtualBox Cloudera Demo VM on Mac OS X",
    "href": "http://blogr-cs.blogspot.com/2012/12/integration-of-r-rstudio-and-hadoop-in.html"
  },
  {
    "title": "randomness in coin tosses and last digits of prime numbers",
    "href": "https://xianblog.wordpress.com/2014/10/07/randomness-in-coin-tosses-and-last-digits-of-prime/"
  },
  {
    "title": "Modis QC Bits",
    "href": "https://stevemosher.wordpress.com/2012/12/05/modis-qc-bits/"
  },
  {
    "title": "R User Group Roundup",
    "href": "http://blog.revolutionanalytics.com/2014/08/r-user-group-roundup-1.html"
  },
  {
    "title": "Put some cushions on the sofa",
    "href": "https://web.archive.org/web/http://schamberlain.github.io/2013/06/sofa/"
  },
  {
    "title": "Popularity of R continues",
    "href": "http://industrialengineertools.blogspot.com/2012/07/popularity-of-r-continues.html"
  },
  {
    "title": "One-liners which make me love R: twitteR’s searchTwitter() #rstats",
    "href": "https://jeffreybreen.wordpress.com/2011/07/21/one-liners-twitter/"
  },
  {
    "title": "Silhouettes",
    "href": "https://aschinchon.wordpress.com/2015/03/02/silhouettes/"
  },
  {
    "title": "Estimation of the number PI – A Monte Carlo simulation",
    "href": "http://probaperception.blogspot.com/2012/10/estimation-of-number-pi-monte-carlo.html"
  },
  {
    "title": "Shiny-server System Performance Monitoring for Open Source Edition",
    "href": "https://web.archive.org/web/http://withr.me/blog/2014/04/09/shiny-server-system-monitoring-for-open-source-edition/"
  },
  {
    "title": "How Scenic is the HS2 Route?",
    "href": "https://web.archive.org/web/http://www.alex-singleton.com/how-scenic-is-the-hs2-route/"
  },
  {
    "title": "from OTU table to HEATMAP!",
    "href": "https://learningomics.wordpress.com/2013/02/23/from-otu-table-to-heatma/"
  },
  {
    "title": "Hillary Clinton’s Biggest 2016 Rival: Herself",
    "href": "http://www.econometricsbysimulation.com/2016/01/hillary-clintons-biggest-2016-rival.html"
  },
  {
    "title": "Words in Politics: Some extensions of the word cloud",
    "href": "http://blog.fellstat.com/?p=101"
  },
  {
    "title": "Mortality by Weekday and Age",
    "href": "http://freakonometrics.hypotheses.org/48134"
  },
  {
    "title": "Direction of Change Forecasting II: The case of the UK",
    "href": "https://web.archive.org/web/http://unstarched.net/2013/09/25/direction-of-change-forecasting-ii-the-case-of-the-uk/"
  },
  {
    "title": "Rootograms",
    "href": "http://www.fromthebottomoftheheap.net/2016/06/07/rootograms/"
  },
  {
    "title": "Slides and replay for \"Backtesting FINRA’s Limit Up/Down Rules\" available",
    "href": "http://blog.revolutionanalytics.com/2011/10/slides-and-replay-for-backtesting-finras-limit-updown-rules-available.html"
  },
  {
    "title": "Revolution Analytics named Startup to Watch in 2012",
    "href": "http://blog.revolutionanalytics.com/2012/01/revolution-analytics-named-startup-to-watch-in-2012.html"
  },
  {
    "title": "Visualizing Sort Algorithms With ggplot",
    "href": "http://jkunst.com/r/visualizing-sort-algorithms-with-ggplot/"
  },
  {
    "title": "Convert decimal to IEEE-754 in R",
    "href": "http://statistic-on-air.blogspot.com/2010/10/convert-decimal-to-ieee-754-in-r.html"
  },
  {
    "title": "Reinterpreting Lee-Carter Mortality Model",
    "href": "http://freakonometrics.hypotheses.org/17931"
  }
]
