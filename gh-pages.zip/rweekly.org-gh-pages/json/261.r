[
  {
    "title": "Statistics forum",
    "href": "https://xianblog.wordpress.com/2011/03/22/statistics-forum/"
  },
  {
    "title": "Zacks Data on Quandl",
    "href": "http://www.exegetic.biz/blog/2014/11/zacks-data-on-quandl/?utm_source=rss&utm_medium=rss&utm_campaign=zacks-data-on-quandl"
  },
  {
    "title": "Tweets vs. Likes: What gets shared on Twitter vs. Facebook?",
    "href": "http://blog.echen.me/2011/07/28/tweets-vs-likes-what-gets-shared-on-twitter-vs-facebook/"
  },
  {
    "title": "How to install rNOMADS with GRIB file support on Windows",
    "href": "https://bovineaerospace.wordpress.com/2015/04/26/how-to-install-rnomads-with-grib-file-support-on-windows/"
  },
  {
    "title": "My visits and RDataMining talks in North America",
    "href": "https://rdatamining.wordpress.com/2014/10/11/my-visits-and-rdatamining-talks-in-north-america/"
  },
  {
    "title": "R goes to StackExchange",
    "href": "https://benmazzotta.wordpress.com/2010/07/06/r-goes-to-stackexchange/"
  },
  {
    "title": "Announcing the R Shapefile Contest",
    "href": "http://www.arilamstein.com/blog/2016/07/12/announcing-r-shapefile-contest/"
  },
  {
    "title": "Mid-year R Packages Update Summary",
    "href": "https://rud.is/b/2016/07/24/mid-year-r-packages-update-summary/"
  },
  {
    "title": "Kasseler useR Group: Data Science and Networking",
    "href": "http://blog.eoda.de/2015/09/23/kasseler-user-group-data-science-and-networking/"
  },
  {
    "title": "Transitions in R redux",
    "href": "http://the-praise-of-insects.blogspot.com/2010/04/transitions-in-r-redux.html"
  },
  {
    "title": "My Course Wish List at CMSE next year",
    "href": "https://pairach.com/2012/08/31/my-course-wish-list-at-cmse-next-year/"
  },
  {
    "title": "What the BBC isn’t telling you",
    "href": "https://gianlubaio.blogspot.com/2013/04/what-bbc-isnt-telling-you.html"
  },
  {
    "title": "analyze the american national election studies (anes) with r",
    "href": "http://www.asdfree.com/2013/11/analyze-american-national-election.html"
  },
  {
    "title": "BARUG Meetup at the Googleplex",
    "href": "https://opensource.googleblog.com/2012/09/barug-meetup-at-googleplex.html"
  },
  {
    "title": "Looking forward to 2016",
    "href": "http://blog.revolutionanalytics.com/2015/12/looking-forward-to-2016.html"
  },
  {
    "title": "R is indispensable, because it’s reproducible",
    "href": "http://blog.revolutionanalytics.com/2010/08/r-is-indispensable-because-its-reproducible.html"
  },
  {
    "title": "Functional regression, INLA, and how to build the World’s Slowest Fourier Transform",
    "href": "https://dahtah.wordpress.com/2012/03/29/functional-regression-inla-and-how-to-build-the-worlds-slowest-fourier-transform/"
  },
  {
    "title": "Sampling Distributions and Central Limit Theorem in R",
    "href": "https://qualityandinnovation.com/2015/03/30/sampling-distributions-and-central-limit-theorem-in-r/"
  },
  {
    "title": "A legitimate use for the stupidest variable name ever",
    "href": "https://4dpiecharts.com/2011/02/02/a-legitimate-use-for-the-stupidest-variable-name-ever/"
  },
  {
    "title": "Workflow with Python and R",
    "href": "https://statbandit.wordpress.com/2009/03/06/workflow-with-python-and-r/"
  },
  {
    "title": "Modelling with R: part 5",
    "href": "http://programming-r-pro-bro.blogspot.com/2011/10/modelling-with-r-part-5.html"
  },
  {
    "title": "Using R in LaTeX with knitr and RStudio",
    "href": "https://statisfaction.wordpress.com/2013/02/28/using-r-in-latex-with-knitr-and-rstudio/"
  },
  {
    "title": "Creating Scientific Posters using R, Latex, Beamer and Beamerposter",
    "href": "http://www.paulhurley.co.uk/index.php/categories/computing-geek/27-r-stats/72-creating-science-posters-using-r-latex-beamer-and-beamerposter-2"
  },
  {
    "title": "New R User Group in Cleveland",
    "href": "http://blog.revolutionanalytics.com/2012/01/new-r-user-group-in-cleveland.html"
  },
  {
    "title": "Running R from Eclipse – StatET installation and Usage",
    "href": "http://www.studytrails.com/r/running-r-from-eclipse-statet-installation-and-usage/"
  },
  {
    "title": "Capital in the Netherlands, 2006-2013",
    "href": "http://wiekvoet.blogspot.com/2015/01/capital-in-netherlands-2006-2013.html"
  },
  {
    "title": "R 3.0.1 is released",
    "href": "https://www.r-statistics.com/2013/05/r-3-0-1-is-released/"
  },
  {
    "title": "Species occurrence data to CartoDB",
    "href": "http://ropensci.org/blog/2013/11/04/data-to-cartodb/"
  },
  {
    "title": "Why R is Hard to Learn",
    "href": "http://r4stats.com/2012/06/13/why-r-is-hard-to-learn/"
  },
  {
    "title": "7 new R jobs from around the world (2015-12-31)",
    "href": "https://www.r-users.com/jobs/content-development-intern-20hour-cambridge-massachusetts-u-s/"
  },
  {
    "title": "5 Sigma in CRU",
    "href": "https://stevemosher.wordpress.com/2010/09/05/5-sigma-in-cru/"
  },
  {
    "title": "Common Data Creation Commands",
    "href": "https://feedproxy.google.com/~r/CoffeeAndEconometricsInTheMorning/~3/ZqU6phZamQU/common-data-creation-commands.html"
  },
  {
    "title": "Using webp in R: A New Format for Lossless and Lossy Image Compression",
    "href": "https://www.opencpu.org/posts/webp-release/"
  },
  {
    "title": "the Flatland paradox [#2]",
    "href": "https://xianblog.wordpress.com/2015/05/27/the-flatland-paradox-2/"
  },
  {
    "title": "Want to win \"Guess who?\" – Have an institutional neural network approach",
    "href": "http://probaperception.blogspot.com/2012/10/the-best-strategy-to-play-guess-who.html"
  },
  {
    "title": "R training: Visualization, Big Data, Data Mining, and Marketing Analytics",
    "href": "http://blog.revolutionanalytics.com/2012/08/r-training-visualization-big-data-data-mining-and-marketing-analytics.html"
  },
  {
    "title": "\"Applications of R\" contest submissions online",
    "href": "http://blog.revolutionanalytics.com/2011/11/applications-of-r-contest-submissions-online.html"
  },
  {
    "title": "Mapping Flows in R … with data.table and lattice",
    "href": "https://procomun.wordpress.com/2015/04/14/mapping-flows-in-r-with-data-table-and-lattice/"
  },
  {
    "title": "Global Homicide Rates by Government Type",
    "href": "https://feedproxy.google.com/~r/graphoftheweek/fzVA/~3/6VBHFGQ5Qys/global-homicide-rates.html"
  },
  {
    "title": "Jim Albert’s Baseball Blog",
    "href": "http://andrewgelman.com/2016/01/20/jim-alberts-baseball-blog-and-little-professor-baseball/"
  },
  {
    "title": "A (fast!) null model of bipartite networks",
    "href": "https://web.archive.org/web/http://timotheepoisot.fr/2010/09/fast-null-model-bipartite-networks/"
  },
  {
    "title": "Annotated Facets with ggplot2",
    "href": "https://statbandit.wordpress.com/2016/10/20/annotated-facets-with-ggplot2/"
  },
  {
    "title": "SPSS to R: An R package to convert SPSS syntax",
    "href": "https://web.archive.org/web/http://educate-r.org//2013/11/26/SPSStoR/"
  },
  {
    "title": "First-Cut Approach to Synchronizing Field Notes with GPS Data",
    "href": "https://casoilresource.lawr.ucdavis.edu/"
  },
  {
    "title": "Practical Kullback-Leibler (KL) Divergence: Discrete Case",
    "href": "http://memosisland.blogspot.com/2015/08/practical-kullback-leibler-kl.html"
  },
  {
    "title": "Importing 100 years of climate change into R",
    "href": "https://biologyforfun.wordpress.com/2014/05/05/importing-100-years-of-climate-change-into-r/"
  },
  {
    "title": "R Statistics for Digital Analytics: 8 Blogs you should Follow",
    "href": "http://www.analyticsforfun.com/2015/03/r-stats-digital-analytics-8-blogs-you.html"
  },
  {
    "title": "Are Fox News Polls Biased?",
    "href": "http://www.econometricsbysimulation.com/2013/05/are-fox-news-polls-biased.html"
  },
  {
    "title": "Norman Nie talks R and statistics with CNET’s Dave Rosenberg",
    "href": "http://blog.revolutionanalytics.com/2010/06/norman-nie-talks-r-and-statistics-with-cnets-dave-rosenberg.html"
  },
  {
    "title": "See R in action at the BUILD conference",
    "href": "http://blog.revolutionanalytics.com/2015/04/see-r-in-action-at-the-build-conference.html"
  }
]
