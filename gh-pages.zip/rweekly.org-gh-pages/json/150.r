[
  {
    "title": "tweets of ggtree",
    "href": "http://guangchuangyu.github.io/2016/02/tweets-of-ggtree/"
  },
  {
    "title": "The definitive guide to plotting confidence intervals in R",
    "href": "http://is-r.tumblr.com/post/38538981197/the-definitive-guide-to-plotting-confidence"
  },
  {
    "title": "Women in Orchestras",
    "href": "https://aschinchon.wordpress.com/2016/06/06/women-in-orchestras/"
  },
  {
    "title": "Scaling the R ecosystem: Possible Directions for Improving Dependency Versioning",
    "href": "https://www.opencpu.org/"
  },
  {
    "title": "The fun Package: Use R for Fun!",
    "href": "http://yihui.name/en/2011/08/the-fun-package-use-r-for-fun/"
  },
  {
    "title": "R Commander – one-way analysis of variance",
    "href": "http://www.wekaleamstudios.co.uk/posts/r-commander-one-way-analysis-of-variance/"
  },
  {
    "title": "Make Your Date Folder Clean with Function unzip & unz",
    "href": "https://web.archive.org/web/http://tianhuidong.github.com/blog/2013/02/26/make-your-date-folder-clean-with-unzip-and-unz/"
  },
  {
    "title": "London 2012 Olympics — world record in women 400-metre medley",
    "href": "https://web.archive.org/web/http://ec2-184-73-106-109.compute-1.amazonaws.com/wordpress/?p=391&utm_source=rss&utm_medium=rss&utm_campaign=london-2012-olympics-world-record-in-women-400-metre-medley"
  },
  {
    "title": "Using the R multicore package in Linux with wild and passionate abandon",
    "href": "http://www.cerebralmastication.com/2010/02/using-the-r-multicore-package-in-linux-with-wild-and-passionate-abandon/"
  },
  {
    "title": "R package for sequence analysis",
    "href": "http://sgsong.blogspot.com/2009/11/r-package-for-sequence-analysis.html"
  },
  {
    "title": "Rcpp 0.6.4",
    "href": "http://dirk.eddelbuettel.com/blog/2009/03/01/"
  },
  {
    "title": "Cross-valitation variability example, part I",
    "href": "http://rsnippets.blogspot.com/2012/05/cross-valitation-variability-example.html"
  },
  {
    "title": "Follow-up: So … daylight savings time does not minimize variance in sunrises",
    "href": "http://www.decisionsciencenews.com/2012/12/03/so-daylight-savings-time-does-minimize-variance-in-sunrises/"
  },
  {
    "title": "The Open Governing Index: How open is the R project?",
    "href": "http://biostatmatt.com/archives/1546"
  },
  {
    "title": "Learn R interactively with our new Introduction to R tutorial",
    "href": "https://www.datacamp.com/community/blog/interactive-r-tutorial"
  },
  {
    "title": "UseR! 2013: it’s a wrap!",
    "href": "http://blog.revolutionanalytics.com/2013/07/user-2013-days-2-3.html"
  },
  {
    "title": "New World Bank Data Available",
    "href": "http://www.r-chart.com/2010/09/new-world-bank-data-available.html"
  },
  {
    "title": "Benford’s Law after converting count data to be in base 5",
    "href": "https://gossetsstudent.wordpress.com/2012/03/08/benfords-law-after-converting-count-data-to-be-in-base-5/"
  },
  {
    "title": "Review of “Numerical Methods and Optimization in Finance” by Gilli, Maringer and Schumann",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/eXTuEqkPul4/"
  },
  {
    "title": "UseR 2010 and commercial applications of R",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2010/01/user-2010-and-commercial-applications-of-r.html"
  },
  {
    "title": "#2 Data Classes (CloudStat)",
    "href": "https://web.archive.org/web/http://pr.cloudst.at/post/12375721580"
  },
  {
    "title": "R 2.15.1 scheduled for June 22",
    "href": "http://blog.revolutionanalytics.com/2012/05/r-2151-scheduled-for-june-22.html"
  },
  {
    "title": "Network visualization in R with the igraph package",
    "href": "https://web.archive.org/web/http://re-design.dimiter.eu/2012/11/05/network-visualization-in-r-with-the-igraph-package/"
  },
  {
    "title": "Estimating arrival times of people in a shop using R",
    "href": "http://firsttimeprogrammer.blogspot.com/2015/07/estimating-arrival-times-of-people-in.html"
  },
  {
    "title": "Oracle’s Big Data Appliance to include R",
    "href": "http://blog.revolutionanalytics.com/2011/10/r-oracle-big-data-appliance.html"
  },
  {
    "title": "An implementation of the Newton-Raphson algorithm in C/C++ and R",
    "href": "https://web.archive.org/web/https://quantcorner.wordpress.com/2012/09/14/an-implementation-of-the-newton-raphson-algorithm-in-c-cpp-and-r/"
  },
  {
    "title": "Detecting regime change in irregular time series",
    "href": "https://cartesianfaith.com/2013/07/11/detecting-regime-change-in-irregular-time-series/"
  },
  {
    "title": "Entropy augmentation the modulo way",
    "href": "http://www.statisticsblog.com/2010/06/entropy-augmentation-the-modulo-way/"
  },
  {
    "title": "Coming to R from SQL, Python, SAS, Matlab, or Lisp",
    "href": "http://www.gettinggeneticsdone.com/2010/01/coming-to-r-from-sql-python-sas-matlab.html"
  },
  {
    "title": "High performance JSON streaming in R: Part 1",
    "href": "https://www.opencpu.org/posts/jsonlite-streaming/"
  },
  {
    "title": "Interview with Romain Francois at useR! 2014",
    "href": "http://datascience.la/interview-with-romain-francois-at-user-2014/"
  },
  {
    "title": "Plotting time vs date in R",
    "href": "http://datadebrief.blogspot.com/2010/10/plotting-time-vs-date-in-r.html"
  },
  {
    "title": "Developing a R Tutorial shiny dashboard app",
    "href": "http://datascienceplus.com/developing-a-r-tutorial-shiny-dashboard-app/"
  },
  {
    "title": "GSoC 2009 Chicago area meeting",
    "href": "http://dirk.eddelbuettel.com/blog/2009/04/30/"
  },
  {
    "title": "Which R documents to read, and which R packages to use",
    "href": "https://rdatamining.wordpress.com/2011/05/29/which-r-documents-to-read-and-which-r-packages-to-use/"
  },
  {
    "title": "Visualizing MLB Hall of Fame votes with R",
    "href": "http://blog.revolutionanalytics.com/2013/02/visualizing-mlb-hall-of-fame-votes-with-r.html"
  },
  {
    "title": "How to make your own 3-D sculpture with R",
    "href": "http://blog.revolutionanalytics.com/2013/01/how-to-make-your-own-3-d-sculpture-with-r.html"
  },
  {
    "title": "Bayesian and Frequentist Approaches: Ask the Right Question",
    "href": "http://www.win-vector.com/blog/2013/05/bayesian-and-frequentist-approaches-ask-the-right-question/?utm_source=rss&utm_medium=rss&utm_campaign=bayesian-and-frequentist-approaches-ask-the-right-question"
  },
  {
    "title": "Docker’s Killer Feature",
    "href": "https://www.joyent.com/blog/dockers-killer-feature"
  },
  {
    "title": "Screencast: The Making of 3dfcc505dc",
    "href": "http://www.milktrader.net/2012/06/screencast-making-of-3dfcc505dc.html"
  },
  {
    "title": "Tuning Notepad++",
    "href": "http://factbased.blogspot.com/2010/08/tuning-notepad.html"
  },
  {
    "title": "Example 8.34: lack of robustness of t test with small n",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/7sT3hTH0DwI/example-834-lack-of-robustness-of-t.html"
  },
  {
    "title": "A Filter Selection Method Inspired From Statistics",
    "href": "https://quantstrattrader.wordpress.com/2015/11/09/a-filter-selection-method-inspired-from-statistics/"
  },
  {
    "title": "Loading and/or Installing Packages Programmatically",
    "href": "http://viksalgorithms.blogspot.com/2012/05/loading-andor-installing-packages.html"
  },
  {
    "title": "Happy Thanksgiving from Revolution Analytics",
    "href": "http://blog.revolutionanalytics.com/2013/11/happy-thanksgiving-from-revolution-analytics.html"
  },
  {
    "title": "Assumptions of the Linear Model",
    "href": "https://danieljhocking.wordpress.com/2011/10/07/assumptions-of-the-linear-model/"
  },
  {
    "title": "On Functional Diversity metrics",
    "href": "https://bartomeuslab.com/2014/04/29/on-functional-diversity-metrics/"
  },
  {
    "title": "Plotting non-overlapping circles…",
    "href": "http://grrrraphics.blogspot.com/2012/06/plotting-non-overlapping-circles.html"
  },
  {
    "title": "Bayes vs. SAS",
    "href": "https://xianblog.wordpress.com/2010/05/07/bayes-vs-sas/"
  },
  {
    "title": "Group-level variances and correlations",
    "href": "http://yusung.blogspot.com/2008/09/group-level-variances-and-correlations.html"
  }
]
