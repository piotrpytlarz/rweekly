[
  {
    "title": "I Want ggplot2/lattice and d3 (gridSVG–The Glue)",
    "href": "http://timelyportfolio.blogspot.com/2013/08/gridsvganother-glue-for-r-to-svg.html"
  },
  {
    "title": "New members for R-core and R Foundation",
    "href": "http://blog.revolutionanalytics.com/2014/09/new-members-for-r-core-and-r-foundation.html"
  },
  {
    "title": "A nice link: “Some hints for the R beginner”",
    "href": "https://www.r-statistics.com/2010/03/nice-link-some-hints-for-the-r-beginner/"
  },
  {
    "title": "You Do Not Need to Tell Me I Have A Typo in My Documentation",
    "href": "http://yihui.name/en/2013/06/fix-typo-in-documentation/"
  },
  {
    "title": "Taking a Ride on the Wild Function –  Introducing the dostats package",
    "href": "https://web.archive.org/web/http://r.andrewredd.us/?p=64"
  },
  {
    "title": "A Graphical Approach to Showing the Result of Classification Models",
    "href": "https://mariosegal.wordpress.com/2013/06/04/a-graphical-approach-to-showing-the-result-of-classification-models/"
  },
  {
    "title": "Quick Update on the Components of Bond Returns",
    "href": "http://timelyportfolio.blogspot.com/2012/01/quick-update-on-components-of-bond.html"
  },
  {
    "title": "2nd Data Analysis Contest Using R",
    "href": "https://procomun.wordpress.com/2013/10/10/2nd-data-analysis-contest/"
  },
  {
    "title": "Classification with Categorical Variables (the fuzzy side)",
    "href": "http://freakonometrics.hypotheses.org/19529"
  },
  {
    "title": "R Documentation and R Manuals: Github and Bioconductor technicalities | RDocumentation",
    "href": "https://www.datacamp.com/community/blog/including-github-and-bioconductor-on-rdocumentation-technical-details"
  },
  {
    "title": "Combine R CMD build and junit",
    "href": "http://romainfrancois.blog.free.fr/index.php?post/2009/08/28/Combine-R-CMD-build-and-junit"
  },
  {
    "title": "A summer of books",
    "href": "https://xianblog.wordpress.com/2010/07/28/a-summer-of-books/"
  },
  {
    "title": "its the Gramma an punctuashun wot its’ about, Rgiht?",
    "href": "https://blog.ouseful.info/2012/10/05/its-the-gramma-an-punctuashun-wot-its-about-rgiht/"
  },
  {
    "title": "Replicating the Body Fat Example from \"Bayesian Model Averaging: A Tutorial\" (1999) with BMS in R",
    "href": "https://web.archive.org/web/http://bms.zeugner.eu/blog/2011-02-07/replicating-the-body-fat-example-from-bayesian-model-averaging-a"
  },
  {
    "title": "The Reorderable Data Matrix and the Promise of Pattern Discovery",
    "href": "http://joelcadwell.blogspot.com/2013/06/the-reorderable-data-matrix-and-promise.html"
  },
  {
    "title": "Anand versus Carlsen – Chennai 2013 – What can we expect in November?",
    "href": "http://datadoodlers.blogspot.com/2013/10/anand-versus-carlsen-chennai-2013-what.html"
  },
  {
    "title": "A Quick Look At Unemployment",
    "href": "http://dancingeconomist.blogspot.com/2011/07/quick-look-at-unemployment.html"
  },
  {
    "title": "Grid2Polygons",
    "href": "http://jfisher-usgs.github.io/r/2012/06/25/grid2polygons"
  },
  {
    "title": "StatEt in Ubuntu 10.04",
    "href": "https://web.archive.org/web/http://www.stat.cmu.edu/~nmv/2010/06/14/statet-in-ubuntu-10-04/"
  },
  {
    "title": "Another boring blog",
    "href": "http://quantitativeecology.blogspot.com/2010/12/another-boring-blog.html"
  },
  {
    "title": "Statistical Methods for the Chain Ladder Technique Revisited",
    "href": "https://web.archive.org/web/http://pr.cloudst.at/post/15888943778"
  },
  {
    "title": "Setting Up the Development Version of R",
    "href": "https://web.archive.org/web/http://ramhiser.com/blog/2012/08/28/setting-up-the-development-version-of-r/"
  },
  {
    "title": "No success yet, then more animations…",
    "href": "http://using-r-project.blogspot.com/2009/08/no-success-yet-then-more-animations.html"
  },
  {
    "title": "This is one of my favorite ggplot2 plots I’ve ever made, but it…",
    "href": "http://jeffreyhorner.tumblr.com/post/124664981668/this-is-one-of-my-favorite-ggplot2-plots-ive-ever"
  },
  {
    "title": "What is Tony talking about?",
    "href": "http://www.stubbornmule.net/2012/09/what-is-tony-talking-about/"
  },
  {
    "title": "Maximizing Return from Every Item in the Marketing Research Questionnaire",
    "href": "http://joelcadwell.blogspot.com/2013/12/maximizing-return-from-every-item-in.html"
  },
  {
    "title": "Pollution from the BP oil spill",
    "href": "http://blog.revolutionanalytics.com/2010/06/pollution-from-the-bp-oil-spill.html"
  },
  {
    "title": "Getting Started with R Markdown, knitr, and Rstudio 0.96",
    "href": "http://jeromyanglim.blogspot.com/2012/05/getting-started-with-r-markdown-knitr.html"
  },
  {
    "title": "“Introducing Monte Carlo Methods with R” is out!",
    "href": "https://xianblog.wordpress.com/2009/12/10/%e2%80%9cintroducing-monte-carlo-methods-with-r%e2%80%9d-is-out/"
  },
  {
    "title": "RStudio available at cloudnumbers.com",
    "href": "https://web.archive.org/web/http://cloudnumbers.com/rstudio-available-at-cloudnumbers-com"
  },
  {
    "title": "Practical Data Science with R, deal of the day Aug 1 2013",
    "href": "http://www.win-vector.com/blog/2013/07/practical-data-science-with-r-deal-of-the-day-aug-1-2013/?utm_source=rss&utm_medium=rss&utm_campaign=practical-data-science-with-r-deal-of-the-day-aug-1-2013"
  },
  {
    "title": "Short is the new Long with longurl for R (plus working with weblogs & URLs in R)",
    "href": "http://datadrivensecurity.info/blog/posts/2015/Jun/short-is-the-new-long-with-longurl-for-r/"
  },
  {
    "title": "Optimization for Finance with R",
    "href": "http://blog.revolutionanalytics.com/2012/01/optimization-for-finance-with-r.html"
  },
  {
    "title": "What does it say about r?",
    "href": "https://web.archive.org/web/http://jkunst.com/post/what-does-it-say-about-r/"
  },
  {
    "title": "The Statistical Sleuth (second edition) in R",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/wNNxPhwQNnQ/the-statistical-sleuth-second-edition.html"
  },
  {
    "title": "24 Days of R: Day 15",
    "href": "https://www.r-bloggers.com/24-days-of-r-day-15/"
  },
  {
    "title": "Commandeering a map from PDF or EPS, using Inkscape and R",
    "href": "http://civilstat.com/2012/08/commandeering-a-map-from-pdf-or-eps-using-inkscape-and-r/"
  },
  {
    "title": "One year as a Data Scientist at Stack Overflow",
    "href": "http://varianceexplained.org/r/year_data_scientist/"
  },
  {
    "title": "Your science links for the week of July 19th",
    "href": "http://paleocave.sciencesortof.com/2013/07/your-science-links-for-the-week-of-july-19th/"
  },
  {
    "title": "Running R through Stata on Mac OS",
    "href": "http://ww1.danielmarcelino.com/running-r-through-stata-on-mac-os/"
  },
  {
    "title": "Mapping Current Average Price Per Sqft for Rentals by Zip in San Fran",
    "href": "https://nerdsrule.co/2012/11/26/mapping-current-average-price-per-sqft-for-apartments-in-san-fran/"
  },
  {
    "title": "Genetic Algorithms with gaoptim package",
    "href": "http://random-miner.blogspot.com/2013/01/genetic-algorithms-with-gaoptim-package.html"
  },
  {
    "title": "Solving Sudoku with Simulated Annealing",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2010/02/solving-sudoku-with-simulated-annealing.html"
  },
  {
    "title": "useR 2013 was a blast!",
    "href": "http://www.sumsar.net/blog/2013/07/user-2013-was-a-blast/"
  },
  {
    "title": "Rendering LaTeX Math Equations in GitHub Markdown",
    "href": "https://hopstat.wordpress.com/2015/07/31/rendering-latex-math-equations-in-github-markdown/"
  },
  {
    "title": "rstats shiny app for tracking the next pope",
    "href": "https://web.archive.org/web/http://dataparadigms.com/posts/2013/03/shiny-app-for-tracking-the-next-pope"
  },
  {
    "title": "pander 0.3.8 is out",
    "href": "http://blog.rapporter.net/2013/09/pander-038-is-out.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+rapporter-r+%28R+stories+by+Rapporter%29"
  },
  {
    "title": "Pseudo-Random vs. Random Numbers in R",
    "href": "https://web.archive.org/web/http://ramhiser.com/blog/2011/11/25/pseudo-random-vs-random-numbers-in-r/"
  },
  {
    "title": "Syntax highlighting of R code at WordPress.com",
    "href": "https://nsaunders.wordpress.com/2011/05/20/syntax-highlighting-of-r-code-at-wordpress-com/"
  },
  {
    "title": "What is the optimal strategy to marry the best one ?",
    "href": "http://blog.free.fr/"
  }
]
