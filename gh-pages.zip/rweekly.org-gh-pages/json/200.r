[
  {
    "title": "highlight 0.1-5",
    "href": "http://romainfrancois.blog.free.fr/index.php?post/2010/02/13/highlight-0.1-5"
  },
  {
    "title": "A very quick introduction to ggplot2",
    "href": "https://feedproxy.google.com/~r/ChristopheLadroueR/~3/H2KPs804dz0/"
  },
  {
    "title": "BayesFactor version 0.9.12-2 released to CRAN",
    "href": "http://bayesfactor.blogspot.com/2015/09/bayesfactor-version-0912-2-released-to.html"
  },
  {
    "title": "Documentation of R source code for package developers",
    "href": "http://www.rexamine.com/2013/04/documentation-of-r-source-code-for-package-developers/"
  },
  {
    "title": "Did the Kigadi Ebola outbreak threaten to become an (inter)national epidemic?",
    "href": "http://www.scipirate.com/"
  },
  {
    "title": "Maths can be cool (to impress your kids)",
    "href": "http://blog.free.fr/"
  },
  {
    "title": "Mideast Graph 3: Slate Middle East Friendship",
    "href": "http://scweiss.blogspot.com/2014/07/mideast-graph-3-slate-middle-east.html"
  },
  {
    "title": "On Box-Cox transform in regression models",
    "href": "http://blog.free.fr/"
  },
  {
    "title": "Election analysis contest entry part 3 – interactive exploration of voting locations with leaflet and Shiny",
    "href": "http://ellisp.github.io/blog/2016/04/09/nzelect3"
  },
  {
    "title": "R installation notes for the occasional R user",
    "href": "https://web.archive.org/web/http://d8aism.com/2013/12/14/r-installation-notes-for-the-occasional-r-user/"
  },
  {
    "title": "Analyses of the Best Undergraduate (US-based) Business Schools of 2013",
    "href": "http://www.analyticsandvisualization.com/2013/06/analyses-of-best-undergraduate-us-based.html"
  },
  {
    "title": "R: Isarithmic Maps of Election Data (1/2)",
    "href": "https://web.archive.org/web/http://statistik-stuttgart.de/64/"
  },
  {
    "title": "New Features in ggplot2 version 0.8.5",
    "href": "https://learnr.wordpress.com/2010/01/07/new-features-in-ggplot2-version-0-8-5/"
  },
  {
    "title": "Two particular courses and other upcoming events",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/TTD60JfvJ_s/"
  },
  {
    "title": "On ranger respect.unordered.factors",
    "href": "http://www.win-vector.com/blog/2016/05/on-ranger-respect-unordered-factors/"
  },
  {
    "title": "Run remote R in Emacs with ESS",
    "href": "https://web.archive.org/web/http://ygc.name/2013/11/14/run-remote-r-in-emacs-with-ess/"
  },
  {
    "title": "Bayesian computational tools",
    "href": "https://xianblog.wordpress.com/2013/06/18/bayesian-computational-tools-2/"
  },
  {
    "title": "R101",
    "href": "http://civilstat.com/2012/03/r101/"
  },
  {
    "title": "Most Entertaining NBA Teams",
    "href": "http://www.moreorlessnumbers.com/2014/02/thunder-entertainment.html"
  },
  {
    "title": "ThinkNum – A new interactive public database and graphing tool!",
    "href": "http://www.econometricsbysimulation.com/2013/09/thinknum-new-interactive-public.html"
  },
  {
    "title": "Download Fantasy Football Projections from ESPN.com using R",
    "href": "http://fantasyfootballanalyticsr.blogspot.com/2013/03/download-fantasy-football-projections.html"
  },
  {
    "title": "The FourierDescriptors Package",
    "href": "http://www.johnmyleswhite.com/notebook/2010/09/04/the-fourierdescriptors-package/"
  },
  {
    "title": "Another look at autocorrelation in the S&P 500",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/Zf692tS1iAM/"
  },
  {
    "title": "Scraping Fantasy Football Projections from the Web",
    "href": "http://fantasyfootballanalytics.net/2014/06/scraping-fantasy-football-projections.html"
  },
  {
    "title": "Online R courses at Udemy for only $10 (today is the last day)",
    "href": "https://www.r-bloggers.com/online-r-courses-at-udemy-for-only-10-until-november-1st/"
  },
  {
    "title": "Design Flaws in R #2 — Dropped Dimensions",
    "href": "https://radfordneal.wordpress.com/2008/08/20/design-flaws-in-r-2-%E2%80%94-dropped-dimensions/"
  },
  {
    "title": "BlogAnalytics 2014-11-16 15:18:00",
    "href": "http://analytix-blog.blogspot.com/2014/11/hypothesis-testing-my-another-effort.html"
  },
  {
    "title": "Using Emacs and ESS to edit bash shell scripts",
    "href": "https://web.archive.org/web/http://adamwilson.us/node/791"
  },
  {
    "title": "Empirical Orthogonal Function (EOF) Analysis for gappy data",
    "href": "http://menugget.blogspot.com/2011/11/empirical-orthogonal-function-eof.html"
  },
  {
    "title": "Bayesian First Aid: Test of Proportions",
    "href": "http://www.sumsar.net/blog/2014/06/bayesian-first-aid-prop-test/"
  },
  {
    "title": "Hazardous and Benign Space Objects: Orbits in the Solar-Ecliptic Reference Frame",
    "href": "http://www.exegetic.biz/blog/2014/05/hazardous-and-benign-space-objects-orbits-in-the-solar-ecliptic-reference-frame/?utm_source=rss&utm_medium=rss&utm_campaign=hazardous-and-benign-space-objects-orbits-in-the-solar-ecliptic-reference-frame"
  },
  {
    "title": "Edward Tufte Keynote Presenter at Data Science Summit, Sep 26-27",
    "href": "http://blog.revolutionanalytics.com/2016/08/tufte-keynote.html"
  },
  {
    "title": "The Popularity of Statistical Packages",
    "href": "http://davegiles.blogspot.com/2012/04/popularity-of-statistical-packages.html"
  },
  {
    "title": "Less Drama, More Encoding",
    "href": "http://rud.is/b/2015/10/24/less-drama-more-encoding/"
  },
  {
    "title": "24 Days of R: Day 21",
    "href": "https://web.archive.org/web/http://pirategrunt.com/2013/12/21/24-days-of-r-day-21-2/"
  },
  {
    "title": "The R Packages of UseR! 2016",
    "href": "http://blog.revolutionanalytics.com/2016/06/the-r-packages-of-user-2016.html"
  },
  {
    "title": "Drafting the Best Starting Lineup in Fantasy Football by Taking into Account Uncertainty in the Projections: An Optimization Simulation",
    "href": "http://fantasyfootballanalyticsr.blogspot.com/2013/08/optimization-simulation.html"
  },
  {
    "title": "Happy World Statistics Day 2015!",
    "href": "http://www.mango-solutions.com/wp/2015/10/happy-world-statistics-day-2015/"
  },
  {
    "title": "Roll Your Own Stats and Geoms in ggplot2 (Part 1: Splines!)",
    "href": "http://rud.is/b/2015/09/08/roll-your-own-stats-and-geoms-in-ggplot2-part-1-splines/"
  },
  {
    "title": "Poisson regression fitted by glm(), maximum likelihood, and MCMC",
    "href": "http://www.petrkeil.com/?p=1709"
  },
  {
    "title": "My first ‘R’ plot",
    "href": "http://techno-realism.blogspot.com/2011/05/my-first-r-plot.html"
  },
  {
    "title": "Plotting Russian AiRstRikes in SyRia",
    "href": "http://r-datameister.blogspot.com/2015/11/plotting-russian-airstrikes-in-syria.html"
  },
  {
    "title": "Simulating a Weibull conditional on time-to-event is greater than a given time",
    "href": "http://realizationsinbiostatistics.blogspot.com/2016/05/simulating-weibull-conditional-on-time.html"
  },
  {
    "title": "ggplot Fit Line and Lattice Fit Line in R",
    "href": "http://blog.mollietaylor.com/2014/02/ggplot-fit-line-and-lattice-fit-line-in.html"
  },
  {
    "title": "Launching Data Science Africa Blog",
    "href": "http://datascience-africa.org/2016/01/launching-data-science-africa-blog/"
  },
  {
    "title": "Better handling of JSON data in R?",
    "href": "http://blog.rolffredheim.com/2014/03/better-handling-of-json-data-in-r.html"
  },
  {
    "title": "RPostgreSQL 0.1-5",
    "href": "http://dirk.eddelbuettel.com/blog/2009/10/13/"
  },
  {
    "title": "Using J48 Decision Tree Classifier to Dynamically Allocate Next Day Position in Stocks or Bonds",
    "href": "http://intelligenttradingtech.blogspot.com/2010/02/prior-introduction-using-simple-model.html"
  },
  {
    "title": "Moshtemp4.0",
    "href": "https://stevemosher.wordpress.com/2010/09/04/moshtemp4-0/"
  },
  {
    "title": "oro.nifti 0.2.1",
    "href": "http://rigorousanalytics.blogspot.com/2010/10/oronifti-021.html"
  }
]
