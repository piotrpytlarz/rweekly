[
  {
    "title": "R to GeoJSON",
    "href": "https://web.archive.org/web/http://schamberlain.github.io/2013/06/geojson/"
  },
  {
    "title": "Run production, one team at a time",
    "href": "http://bayesball.blogspot.com/2013/02/run-production-one-team-at-time.html"
  },
  {
    "title": "Mapping MA election results",
    "href": "http://offensivepolitics.net/blog/2010/01/mapping-ma-election-results/"
  },
  {
    "title": "The R Inferno revised",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/tuJ3ZfL_FZY/"
  },
  {
    "title": "Something is rotten in the state of Denmark",
    "href": "http://www.fromthebottomoftheheap.net/2015/06/02/something-rotten/"
  },
  {
    "title": "Progress bars in R (part II) – a wrapper for apply functions",
    "href": "https://ryouready.wordpress.com/2010/01/11/progress-bars-in-r-part-ii-a-wrapper-for-apply-functions/"
  },
  {
    "title": "Alternative to Grouped Bar Charts in R",
    "href": "http://rud.is/b/2013/10/27/alternative-to-grouped-bar-charts-in-r/"
  },
  {
    "title": "How to perform a Logistic Regression in R",
    "href": "http://datascienceplus.com/perform-logistic-regression-in-r/"
  },
  {
    "title": "Data Frames and Transactions",
    "href": "http://statistical-research.com/data-frames-and-transactions/?utm_source=rss&utm_medium=rss&utm_campaign=data-frames-and-transactions"
  },
  {
    "title": "What’s Warren Buffett’s $1 Billion Basketball Bet Worth?",
    "href": "https://bayesianbiologist.com/2014/01/22/whats-warren-buffetts-1-billion-basketball-bet-worth/"
  },
  {
    "title": "Syrian Refugee Informal Settlement Animation",
    "href": "http://www.moreorlessnumbers.com/2014/10/syrian-refugee-informal-settlement.html"
  },
  {
    "title": "R and Java – JRI Using Netbeans",
    "href": "http://www.studytrails.com/r/r-and-java-jri-using-netbeans/"
  },
  {
    "title": "Visualising stranded RNA-seq data with Gviz/Bioconductor",
    "href": "https://sidderb.wordpress.com/2014/11/06/visualising-stranded-rna-seq-data-with-gvizbioconductor/"
  },
  {
    "title": "Video: Using R in Academic Finance",
    "href": "http://blog.revolutionanalytics.com/2012/03/video-using-r-in-academic-finance.html"
  },
  {
    "title": "Using R: quickly calculating summary statistics from a data frame",
    "href": "https://martinsbioblogg.wordpress.com/2014/03/25/using-r-quickly-calculating-summary-statistics-from-a-data-frame/"
  },
  {
    "title": "R jobs (April 7th 2014)",
    "href": "https://www.r-bloggers.com/r-jobs-april-7th-2014/"
  },
  {
    "title": "Job advert",
    "href": "https://gianlubaio.blogspot.com/2013/03/job-advert.html"
  },
  {
    "title": "A Walk-Forward Attempt on FAA",
    "href": "https://quantstrattrader.wordpress.com/2014/10/29/a-walk-forward-attempt-on-faa/"
  },
  {
    "title": "analogue 0.14-0 released",
    "href": "http://www.fromthebottomoftheheap.net/2014/10/14/analogue-0.14-0-now-available-on-CRAN/"
  },
  {
    "title": "Empirical bias analysis of random effects predictions in linear and logistic mixed model regression",
    "href": "https://statmd.wordpress.com/2015/07/30/empirical-bias-analysis-of-random-effects-predictions-in-linear-and-logistic-mixed-model-regression/"
  },
  {
    "title": "Rock around the data clock",
    "href": "http://opiateforthemass.es/articles/data-clock/"
  },
  {
    "title": "mvabund – new R pkg for multivariate abundance data",
    "href": "https://web.archive.org/web/http://schamberlain.github.com/2012/03/mvabund/"
  },
  {
    "title": "Veterinary Epidemiologic Research: Linear Regression",
    "href": "https://denishaine.wordpress.com/2013/02/14/veterinary-epidemiologic-research-linear-regression/"
  },
  {
    "title": "Network analysis with igraph",
    "href": "http://ww1.danielmarcelino.com/1046/"
  },
  {
    "title": "Genetic Algorithm Systematic Trading Development– Part 2",
    "href": "http://intelligenttradingtech.blogspot.com/2010/02/genetic-algorithm-systematic-trading_17.html"
  },
  {
    "title": "Mango Solutions co-Founder announced as inaugural President of newly launched R Consortium",
    "href": "http://www.mango-solutions.com/wp/2015/08/mango-solutions-co-founder-announced-as-inaugural-president-of-newly-launched-r-consortium/"
  },
  {
    "title": "Factor Evaluation in Quantitative Portfolio Management",
    "href": "http://www.thertrader.com/2015/03/23/factor-evaluation-in-quantitative-portfolio-management/"
  },
  {
    "title": "R vs. SAS",
    "href": "http://www.theusrus.de/blog/r-vs-sas/"
  },
  {
    "title": "Book Review: Parallel R",
    "href": "http://blog.fosstrading.com/2012/06/book-review-parallel-r.html"
  },
  {
    "title": "WrightMap Tutorial 4 – More Flexibility\r\n\r\n\r\n\r\n\r\nUsing the person and item side…",
    "href": "http://wrightmap.org/post/143189138832/wrightmap-tutorial-4-more-flexibility-using"
  },
  {
    "title": "Creating a Presentation with LaTeX Beamer – Getting Started",
    "href": "http://www.wekaleamstudios.co.uk/posts/creating-a-presentation-with-latex-beamer-getting-started/"
  },
  {
    "title": "analyze the programme for the international assessment of adult competencies (piaac) with r",
    "href": "http://www.asdfree.com/2014/08/analyze-programme-for-international.html"
  },
  {
    "title": "R Commander – a good introductory GUI for R",
    "href": "http://www.wekaleamstudios.co.uk/posts/r-commander-a-good-introductory-gui-for-r/"
  },
  {
    "title": "Ooms Magical Polyglot World",
    "href": "http://timelyportfolio.blogspot.com/2016/07/ooms-magical-polyglot-world.html"
  },
  {
    "title": "Logo Contest Winner",
    "href": "http://simplystatistics.org/2012/11/16/logo-contest-winner/"
  },
  {
    "title": "I will survive!",
    "href": "https://gianlubaio.blogspot.com/2016/01/i-will-survive.html"
  },
  {
    "title": "… ridiculously photogenic factors (heatmap with p-values)",
    "href": "https://talesofr.wordpress.com/2013/05/05/ridiculously-photogenic-factors-heatmap-with-p-values/"
  },
  {
    "title": "New packages for reading data into R — fast",
    "href": "http://blog.revolutionanalytics.com/2015/04/new-packages-for-reading-data-into-r-fast.html"
  },
  {
    "title": "Working with multiple graphs in R",
    "href": "http://mikeksmith.posterous.com/working-with-multiple-graphs-in-r"
  },
  {
    "title": "Query Multiple Google Analytics View IDs with R",
    "href": "http://www.analyticsforfun.com/2015/05/query-multiple-google-analytics-view.html"
  },
  {
    "title": "Repel overlapping text labels in ggplot2",
    "href": "http://www.gettinggeneticsdone.com/2016/01/repel-overlapping-text-labels-in-ggplot2.html"
  },
  {
    "title": "Post 0: Getting Started with R",
    "href": "https://web.archive.org/web/http://mcmcinirt.stat.cmu.edu/archives/28?utm_source=rss&utm_medium=rss&utm_campaign=post-0-getting-started-with-r"
  },
  {
    "title": "Benchmarking R/RRO in OSX and Ubuntu on the cloud",
    "href": "http://www.numbrcrunch.com/blog/benchmarking-rrro-in-osx-and-ubuntu-on-the-cloud"
  },
  {
    "title": "Because it’s Friday: The inner life of a cell",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2009/12/because-its-friday-the-inner-life-of-a-cell.html"
  },
  {
    "title": "Taking the Next Step with Census Data",
    "href": "http://www.arilamstein.com/blog/2016/02/15/taking-next-step-census-data/"
  },
  {
    "title": "Linpe: make sending and receiving data analysis faster and easier",
    "href": "http://www.quantide.com/linpe-make-sending-receiving-data-analysis-faster-easier/"
  },
  {
    "title": "Weak Learners",
    "href": "http://statisticsinseattle.blogspot.com/2013/08/weak-learners.html"
  },
  {
    "title": "How Not To Draw a Probability Distribution",
    "href": "http://isomorphism.es/post/18913494015/probability-distributions"
  },
  {
    "title": "Additional tips for structuring an individual-based model in R",
    "href": "http://menugget.blogspot.com/2014/09/additional-tips-for-structuring.html"
  },
  {
    "title": "Alabama is a foreign country",
    "href": "http://blog.revolutionanalytics.com/2011/03/alabama-is-a-foreign-country.html"
  }
]
