[
  {
    "title": "ddply in action",
    "href": "http://decisionsandr.blogspot.com/2013/03/top-batting-averages-over-time-body-td.html"
  },
  {
    "title": "R Tutorial by DrivenData & DataCamp: Data Mining the Water Table",
    "href": "https://www.datacamp.com/community/blog/r-tutorial-by-drivendata-datacamp-data-mining-the-water-table"
  },
  {
    "title": "Structural Breaks (Bull or Bear?)",
    "href": "http://timelyportfolio.blogspot.com/2012/04/structural-breaks-bull-or-bear.html"
  },
  {
    "title": "How accurate is Next Bus II: wrangling data",
    "href": "http://brooksandrew.github.io/simpleblog/articles/nextbus2_wrangle/"
  },
  {
    "title": "More Flexible Approaches to Model Frequency",
    "href": "https://statcompute.wordpress.com/2016/05/13/more-flexible-approaches-to-model-frequency/"
  },
  {
    "title": "Using JAGS in R with the rjags Package",
    "href": "http://www.johnmyleswhite.com/notebook/2010/08/20/using-jags-in-r-with-the-rjags-package/"
  },
  {
    "title": "Classi-Compare of Raster Satellite Images – Before and After",
    "href": "http://freigeist.devmag.net/r/700-classi-compare-of-raster-satellite-images-before-and-after.html"
  },
  {
    "title": "R and Data Science Webinar",
    "href": "http://blog.revolutionanalytics.com/2014/09/r-and-data-science-webinar.html"
  },
  {
    "title": "DotCity: a game written in R? and other statistical computer games?",
    "href": "http://civilstat.com/2015/06/dotcity-a-game-written-in-r-and-other-statistical-computer-games/"
  },
  {
    "title": "GEE QIC update",
    "href": "https://danieljhocking.wordpress.com/2012/11/15/gee-qic-update/"
  },
  {
    "title": "GLMM revisted",
    "href": "http://sgsong.blogspot.com/2010/03/glmm-revisted.html"
  },
  {
    "title": "Example 9.32: Multiple testing simulation",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/9Kqd9zqKbeo/example-932-multiple-testing-simulation.html"
  },
  {
    "title": "The Environmental Performance Index, visualized with R",
    "href": "http://blog.revolutionanalytics.com/2012/07/the-environmental-performance-index-visualized-with-r.html"
  },
  {
    "title": "Poor, Poor Hillary",
    "href": "https://web.archive.org/web/http://notebookonthewebs.tumblr.com/post/14321316049"
  },
  {
    "title": "Data Analysis Steps",
    "href": "http://www.dataperspective.info/2014/02/data-analysis-steps.html"
  },
  {
    "title": "Clustering the Words of William Shakespeare",
    "href": "http://www.exegetic.biz/blog/2013/09/clustering-the-words-of-william-shakespeare/"
  },
  {
    "title": "Dark matter top 10, but an hour too late",
    "href": "https://bayesianbiologist.com/2012/12/16/dark-matter-top-10-but-an-hour-too-late/"
  },
  {
    "title": "Paper describing the weaver package published in Computational Statistics",
    "href": "http://userprimary.net/posts/2008/06/14/paper-describing-the-weaver-package-published-in-computational-statistics/"
  },
  {
    "title": "informative hypotheses (book review)",
    "href": "https://xianblog.wordpress.com/2013/09/19/informative-hypotheses-book-review/"
  },
  {
    "title": "Converting text files with sed",
    "href": "http://www.nomad.priv.at/researchblog/?p=448"
  },
  {
    "title": "R in Insurance – the November meetup of the Warsaw R User Group",
    "href": "http://smarterpoland.pl/index.php/2015/11/r-in-insurance-the-november-meetup-of-the-warsaw-r-user-group/"
  },
  {
    "title": "6 Machine Learning Visualizations made in Python and R",
    "href": "http://moderndata.plot.ly/machine-learning-visualizations-made-in-python-and-r/"
  },
  {
    "title": "What’s the smallest amount you can’t make with 5 coins ?",
    "href": "https://web.archive.org/web/http://www.paulhurley.co.uk/index.php/categories/computing-geek/27-r-stats/69-5-coins-test"
  },
  {
    "title": "Winning streaks in baseball",
    "href": "http://www.decisionsciencenews.com/2015/04/28/winning-streaks-in-baseball/"
  },
  {
    "title": "Simple Moving Average Strategy with a Volatility Filter: Follow-Up Part 2",
    "href": "https://rbresearch.wordpress.com/2012/04/30/simple-moving-average-strategy-with-a-volatility-filter-follow-up-part-2/"
  },
  {
    "title": "R co-creator Ross Ihaka wins Lifetime Achievement Award in Open Source",
    "href": "http://blog.revolutionanalytics.com/2010/11/r-co-creator-ross-ihaka-wins-lifetime-achievement-award-in-open-source.html"
  },
  {
    "title": "matlabr: a Package to Calling MATLAB from R with system",
    "href": "https://hopstat.wordpress.com/2015/04/08/matlabr-a-package-to-calling-matlab-from-r-with-system/"
  },
  {
    "title": "How to set axis options in googleVis",
    "href": "http://www.magesblog.com/2013/04/how-to-set-axis-options-in-googlevis.html"
  },
  {
    "title": "The quality of variance matrix estimation",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/4e_5BD2ckEA/"
  },
  {
    "title": "It’s not the p-values’ fault – reflections on the recent ASA statement (+relevant R resources)",
    "href": "https://www.r-statistics.com/2016/03/its-not-the-p-values-fault-reflections-on-the-recent-asa-statement/"
  },
  {
    "title": "Score with scoring rules",
    "href": "http://www.decisionsciencenews.com/2009/07/21/score-with-scoring-rules/"
  },
  {
    "title": "Blend what?",
    "href": "http://blenditbayes.blogspot.com/2013/03/blend-what.html"
  },
  {
    "title": "No Statistical Panacea, Hierarchical or Otherwise",
    "href": "https://danieljhocking.wordpress.com/2013/02/13/no-statistical-panacea/"
  },
  {
    "title": "R: Basic R Skills – Splitting and Plotting",
    "href": "http://www.compbiome.com/2010/12/r-basic-r-skills-splitting-and-plotting.html"
  },
  {
    "title": "Bivariate Densities with N(0,1) Margins",
    "href": "http://freakonometrics.hypotheses.org/12834"
  },
  {
    "title": "As.Date() Exercises",
    "href": "http://r-exercises.com/2016/07/14/as-date-exercises/"
  },
  {
    "title": "Splitting a Large CSV File into Separate Smaller Files Based on Values Within a Specific Column",
    "href": "https://blog.ouseful.info/2013/04/03/splitting-a-large-csv-file-into-separate-smaller-files-based-on-values-within-a-specific-column/"
  },
  {
    "title": "Comparing Flexible and Elastic Asset Allocation",
    "href": "https://quantstrattrader.wordpress.com/2015/01/30/comparing-flexible-and-elastic-asset-allocation/"
  },
  {
    "title": "Oracle R, Hash Table Results, And VIM To The Rescue",
    "href": "http://jeffreyhorner.tumblr.com/post/117525298483/oracle-r-hash-table-results-and-vim-to-the"
  },
  {
    "title": "Mastering Data Analysis with R",
    "href": "http://blog.rapporter.net/2015/10/mastering-data-analysis-with-r.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+rapporter-r+%28R+stories+by+Rapporter%29"
  },
  {
    "title": "Microarrays, scan dates and Bioconductor: it shouldn’t be this difficult",
    "href": "https://nsaunders.wordpress.com/2013/08/22/microarrays-scan-dates-and-bioconductor-it-shouldnt-be-this-difficult/"
  },
  {
    "title": "How to plot a graph in R",
    "href": "http://digitheadslabnotebook.blogspot.com/2009/06/how-to-plot-graph-in-r.html"
  },
  {
    "title": "Notes from 2nd Bayesian Mixer Meetup",
    "href": "http://www.magesblog.com/2016/04/notes-from-2nd-bayesian-mixer-meetup.html"
  },
  {
    "title": "Principal Component Analysis on Imaging",
    "href": "http://alstatr.blogspot.com/2014/12/principal-component-analysis-on-imaging.html"
  },
  {
    "title": "Creating 3D geographical plots in R using RGL",
    "href": "http://alexfarquhar.posterous.com/60394694"
  },
  {
    "title": "2nd round of call for chapter proposals for book Data Mining Applications with R: due by 31 May",
    "href": "https://rdatamining.wordpress.com/2012/05/02/2nd-round-of-call-for-chapter-proposals-for-book-data-mining-applications-with-r-due-by-31-may/"
  },
  {
    "title": "Going over the speed limit",
    "href": "http://ekonometrics.blogspot.com/2011/04/going-over-speed-limit.html"
  },
  {
    "title": "Generating a Markov chain vs. computing the transition matrix",
    "href": "http://freakonometrics.hypotheses.org/6803"
  },
  {
    "title": "Adjusted Momentum",
    "href": "https://systematicinvestor.wordpress.com/2014/08/01/adjusted-momentum/"
  },
  {
    "title": "Is it possible to get a causal smoothed filter ?",
    "href": "http://intelligenttradingtech.blogspot.com/2010/05/is-it-possible-to-get-causal-smoothed.html"
  }
]
