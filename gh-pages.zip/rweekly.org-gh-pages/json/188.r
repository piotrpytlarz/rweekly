[
  {
    "title": "Myown way to Data Science",
    "href": "http://rformining.blogspot.com/2013/10/myown-way-to-data-science.html"
  },
  {
    "title": "Absolutely great resource",
    "href": "http://worldofrcraft.blogspot.com/2009/02/absolutely-great-resource.html"
  },
  {
    "title": "Type II Error",
    "href": "http://www.r-tutor.com/elementary-statistics/type-2-errors"
  },
  {
    "title": "Who Survived on the Titanic? Predictive Classification with Parametric and Non-parametric Models",
    "href": "https://politicalmethodology.wordpress.com/2012/12/25/who-survived-on-the-titanic-predictive-classification-with-parametric-and-non-parametric-models/"
  },
  {
    "title": "Massive online data stream mining with R",
    "href": "http://www.bnosac.be/index.php/blog/26-massive-online-data-stream-mining-with-r"
  },
  {
    "title": "Efficiecy of Extracting Rows from A Data Frame in R",
    "href": "https://statcompute.wordpress.com/2013/01/01/efficiecy-of-extracting-rows-from-a-data-frame-in-r/"
  },
  {
    "title": "Revolution Analytics named a Visionary in the Gartner Magic Quadrant for Advanced Analytics Platforms",
    "href": "http://blog.revolutionanalytics.com/2014/02/gartner-aap-mq.html"
  },
  {
    "title": "A simple ANOVA",
    "href": "http://wiekvoet.blogspot.com/2016/01/a-simple-anova.html"
  },
  {
    "title": "Counting the Dead in Syria",
    "href": "http://blog.revolutionanalytics.com/2013/11/counting-the-dead.html"
  },
  {
    "title": "Mathematical annotations on R plots",
    "href": "http://robjhyndman.com/hyndsight/latex2exp/"
  },
  {
    "title": "Feedback on OTexts covers please",
    "href": "http://robjhyndman.com/hyndsight/fppcover/"
  },
  {
    "title": "Bayes factor t tests, part 1",
    "href": "http://bayesfactor.blogspot.com/2014/02/bayes-factor-t-tests-part-1.html"
  },
  {
    "title": "Dropbox & R Data",
    "href": "http://christophergandrud.blogspot.com/2013/04/dropbox-r-data.html"
  },
  {
    "title": "When will my papers appear as references (if they do…) ?",
    "href": "http://blog.free.fr/"
  },
  {
    "title": "Mapping products in a space",
    "href": "http://wiekvoet.blogspot.com/2014/09/mapping-products-in-space.html"
  },
  {
    "title": "Statistical Interests in Large Cities",
    "href": "http://freakonometrics.hypotheses.org/11617"
  },
  {
    "title": "QQ-plots in R vs. SPSS – A look at the differences",
    "href": "https://ryouready.wordpress.com/2014/12/15/qq-plots-in-r-vs-spss-a-look-at-the-differences/"
  },
  {
    "title": "New Course! A hands-on introduction to statistics with R by A. Conway (Princeton University)",
    "href": "https://www.datacamp.com/community/blog/new-course-a-hands-on-introduction-to-statistics-with-r-by-a-conway-princeton-university"
  },
  {
    "title": "BayesFactor update: 0.9.7.",
    "href": "http://bayesfactor.blogspot.com/2014/02/bayesfactor-version-0.html"
  },
  {
    "title": "2016 Prior Exposure Bayesian Data Analysis workshops for social scientists",
    "href": "http://psychologicalstatistics.blogspot.com/2016/01/2016-prior-exposure-bayesian-data.html"
  },
  {
    "title": "Exercise in grImport",
    "href": "http://rsnippets.blogspot.com/2012/01/exercise-in-grimport.html"
  },
  {
    "title": "Fastest Way to Add New Variables to A Large Data.Frame",
    "href": "https://statcompute.wordpress.com/2016/10/31/fastest-way-to-add-new-variables-to-a-large-data-frame/"
  },
  {
    "title": "Analyzing big data in R: two presentations from useR! 2011",
    "href": "http://blog.revolutionanalytics.com/2011/09/analyzing-big-data-in-r-two-presentations-from-user-2011.html"
  },
  {
    "title": "Analysis of ISMB coverage at FriendFeed: 2008 – 2011",
    "href": "https://nsaunders.wordpress.com/2011/07/28/analysis-of-ismb-coverage-at-friendfeed-2008-2011/"
  },
  {
    "title": "How can we improve R-exercises?",
    "href": "http://r-exercises.com/2016/10/09/your-weekly-update-from-us/"
  },
  {
    "title": "A chart for marathoners",
    "href": "http://blog.revolutionanalytics.com/2011/11/a-chart-for-marathoners.html"
  },
  {
    "title": "Cherry Picking to Generalize ~ retrospective meta-power analysis using Cohen’s f^2 of NASA temp + visualization",
    "href": "https://probabilitynotes.wordpress.com/2010/07/17/cherry-picking-to-generalize-retrospective-power-analysis-using-cohens-f2-of-nasa-temp-visualization/"
  },
  {
    "title": "Rudd, the last one standing?: Federal implications of QLD state election results",
    "href": "https://web.archive.org/web/http://jackman.stanford.edu/blog/?p=2437"
  },
  {
    "title": "Using old versions of R packages",
    "href": "http://robjhyndman.com/hyndsight/old-r-packages/"
  },
  {
    "title": "Gradient Descent in R",
    "href": "http://econometricsense.blogspot.com/2011/11/gradient-descent-in-r.html"
  },
  {
    "title": "CRAN Search",
    "href": "http://www.r-chart.com/2010/06/cran-search.html"
  },
  {
    "title": "Election tRends: An interactive US election tracker (using Shiny and Plotly)",
    "href": "https://www.r-statistics.com/2016/03/election-trends-an-interactive-us-election-tracker-using-shiny-and-plotly/"
  },
  {
    "title": "quantile functions: mileage may vary",
    "href": "https://xianblog.wordpress.com/2015/05/12/quantile-functions-mileage-may-vary/"
  },
  {
    "title": "Friday Function: nclass",
    "href": "https://4dpiecharts.com/2011/05/06/friday-function-nclass/"
  },
  {
    "title": "McElreath’s Statistical Rethinking: A Bayesian Course with Examples in R and Stan",
    "href": "http://andrewgelman.com/2016/01/15/mcelreaths-statistial-rethinking-a-bayesian-course-with-examples-in-r-and-stan/"
  },
  {
    "title": "Visualising the Metropolis-Hastings algorithm",
    "href": "https://bayesianbiologist.com/2012/02/10/visualising-the-metropolis-hastings-algorithm-2/"
  },
  {
    "title": "Visualizing Movies Gross Income",
    "href": "http://jkunst.com/r/viz-gross-income-movies/"
  },
  {
    "title": "Innumeracy, Statistics and R",
    "href": "https://matloff.wordpress.com/2016/03/01/innumeracy-statistics-and-r/"
  },
  {
    "title": "Bayesian regression with STAN: Part 1 normal regression",
    "href": "http://datascienceplus.com/bayesian-regression-with-stan-part-1-normal-regression/"
  },
  {
    "title": "devtools 1.9.1",
    "href": "https://blog.rstudio.org/2015/09/13/devtools-1-9-1/"
  },
  {
    "title": "Open PHACTS from R",
    "href": "http://chem-bla-ics.blogspot.com/2013/12/open-phacts-from-r.html"
  },
  {
    "title": "Data Journalism Awards Data Visualization of the Year, 2016",
    "href": "http://blog.revolutionanalytics.com/2016/06/data-journalism-awards-data-visualization-of-the-year-2016.html"
  },
  {
    "title": "Course: Financial Data Modeling and Analysis in R",
    "href": "http://blog.revolutionanalytics.com/2011/11/course-financial-data-modeling-and-analysis-in-r.html"
  },
  {
    "title": "NBA Playoff Predictions Update 4 (5-3)",
    "href": "http://viksalgorithms.blogspot.com/2012/06/nba-playoff-predictions-update-4-5-3.html"
  },
  {
    "title": "Updated: Why R is Hard to Learn",
    "href": "http://r4stats.com/2014/12/09/updated-why-r-is-hard-to-learn/"
  },
  {
    "title": "Hadley Wickham’s dplyr tutorial at useR! 2014, Part 1",
    "href": "http://datascience.la/hadley-wickhams-dplyr-tutorial-at-user-2014-part-1/"
  },
  {
    "title": "Sharing our R Programs — With Style",
    "href": "http://blog.revolutionanalytics.com/2016/10/sharing-r-code-with-style.html"
  },
  {
    "title": "Happy Birthday GGD! The 10 Most Popular Posts Since GGD’s Launch",
    "href": "http://www.gettinggeneticsdone.com/2010/02/happy-birthday-ggd-10-most-popular.html"
  },
  {
    "title": "Did you know? Source of ggplot2 in R",
    "href": "http://hack-r.com/did-you-know-source-of-ggplot2-in-r/"
  },
  {
    "title": "the batman equation",
    "href": "https://web.archive.org/web/http://ygc.name/2011/08/14/bat-man/"
  }
]
