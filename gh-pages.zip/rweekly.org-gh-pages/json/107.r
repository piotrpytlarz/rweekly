[
  {
    "title": "Spell Checker for R…qdap::check_spelling",
    "href": "https://trinkerrstuff.wordpress.com/2014/09/04/spell-checker-for-r-qdapcheck_spelling/"
  },
  {
    "title": "Interview with Boulder BI Brain Trust",
    "href": "http://blog.revolutionanalytics.com/2013/03/interview-with-boulder-bi-brain-trust.html"
  },
  {
    "title": "Multidimension bridge sampling (CoRe in CiRM [5])",
    "href": "https://xianblog.wordpress.com/2010/07/14/multidimension-bridge-sampling-core-in-cirm-5/"
  },
  {
    "title": "Juggling with fire",
    "href": "http://romainfrancois.blog.free.fr/index.php?post/2010/07/28/Juggling-with-fire"
  },
  {
    "title": "Using LaTeX for Math Formulas on the Web",
    "href": "http://www.gettinggeneticsdone.com/2011/04/using-latex-for-math-formulas-on-web.html"
  },
  {
    "title": "A new blogging workflow",
    "href": "http://rmnppt.com/introduction/rmarkdown/blog/workflow/2015/11/23/A-new-blog-workflow.html"
  },
  {
    "title": "Record Long Term Treasury Returns",
    "href": "http://timelyportfolio.blogspot.com/2011/12/record-long-term-treasury-returns.html"
  },
  {
    "title": "Popular Baby Names Walk-Through Part 2 – Graphing the fast movers",
    "href": "https://web.archive.org/web/http://notebookonthewebs.tumblr.com/post/13114811173"
  },
  {
    "title": "Ten Thousand Tweets",
    "href": "http://juliasilge.com/blog/Ten-Thousand-Tweets/"
  },
  {
    "title": "How Orbitz uses Hadoop and R to optimize hotel search",
    "href": "http://blog.revolutionanalytics.com/2010/12/how-orbitz-uses-hadoop-and-r-to-optimize-hotel-search.html"
  },
  {
    "title": "Review: Kölner R Meeting 19 July 2013",
    "href": "http://www.magesblog.com/2013/07/review-kolner-r-meeting-19-july-2013.html"
  },
  {
    "title": "Unobserved Effects With Panel Data",
    "href": "http://www.econometricsbysimulation.com/2013/12/unobserved-effects-with-panel-data.html"
  },
  {
    "title": "10 Reasons why you can’t miss this years EARL Conference in London",
    "href": "http://www.mango-solutions.com/wp/2016/08/10-reasons-why-you-cant-miss-this-years-earl-conference-in-london/"
  },
  {
    "title": "The R-Files: Dirk Eddelbuettel",
    "href": "http://blog.revolutionanalytics.com/2011/02/the-r-files-dirk-eddlebuettel.html"
  },
  {
    "title": "Clustering with selected Principal Components",
    "href": "https://systematicinvestor.wordpress.com/2012/12/29/clustering-with-selected-principal-components/"
  },
  {
    "title": "RcppArmadillo 0.4.600.0",
    "href": "http://dirk.eddelbuettel.com/blog/2014/12/28/"
  },
  {
    "title": "Millionaire’s advice",
    "href": "http://www.investuotojas.eu/?p=407"
  },
  {
    "title": "F1 2012 Mid-Season Review",
    "href": "https://blog.ouseful.info/2012/08/30/f1-2012-mid-season-review/"
  },
  {
    "title": "Warsaw R-Ladies",
    "href": "http://r-addict.com/2016/10/21/Warsaw-RLadies-01.html"
  },
  {
    "title": "Program of the european R users meeting [only 7 days to go]",
    "href": "http://smarterpoland.pl/index.php/2016/10/program-of-the-european-r-users-meeting-only-7-days-to-go/"
  },
  {
    "title": "ProbaPerception: Introduction",
    "href": "http://rsnippets.blogspot.com/2012/09/plotting-watts-strogatz-model.html"
  },
  {
    "title": "The world’s top seven airlines in the style of…",
    "href": "https://web.archive.org/web/http://blog.ggplot2.org/post/24676927349"
  },
  {
    "title": "The Power of ggplot2 in ArcGIS – The Plotting Toolbox",
    "href": "http://r-video-tutorial.blogspot.com/2016/07/the-power-of-ggplot2-in-arcgis-plotting.html"
  },
  {
    "title": "The New Irish House Price Index",
    "href": "https://web.archive.org/web/https://timeseriesireland.wordpress.com/2011/05/15/the-new-irish-house-price-index/"
  },
  {
    "title": "R, Python, MATLAB, & Excel Dashboards & Graphs with D3.js & WebGL",
    "href": "http://moderndata.plot.ly/r-python-matlab-dashboards-graphs-with-d3-js-webgl/"
  },
  {
    "title": "Use IUCN API with R & XPath",
    "href": "http://thebiobucket.blogspot.com/2012/06/use-iucn-data-with-r-xpath.html"
  },
  {
    "title": "Condorcet ranking and Rcpp",
    "href": "http://www.avrahamadler.com/2014/03/13/condorcetrcpp/"
  },
  {
    "title": "Comparing standard R with Revoutions for performance",
    "href": "http://www.cybaea.net/Blogs/Data/Comparing-standard-R-with-Revoutions-for-performance.html"
  },
  {
    "title": "May 2011 Guerrilla Classes: Light Bulb Moments",
    "href": "http://perfdynamics.blogspot.com/2011/05/may-2011-guerrilla-classes-light-bulb.html"
  },
  {
    "title": "RGolf: NGSL Scrabble",
    "href": "http://rsnippets.blogspot.com/2014/06/rgolf-ngsl-scrabble.html"
  },
  {
    "title": "Stata-like Marginal Effects for Logit and Probit Models in R",
    "href": "https://web.archive.org/web/https://timeseriesireland.wordpress.com/2011/05/18/stata-like-marginal-effects-for-logit-and-probit-models-in-r/"
  },
  {
    "title": "DataMarket",
    "href": "https://web.archive.org/web/http://rforcancer.drupalgardens.com/content/datamarket"
  },
  {
    "title": "reliable ABC model choice via random forests",
    "href": "https://xianblog.wordpress.com/2014/10/29/reliable-abc-model-choice-via-random-forests/"
  },
  {
    "title": "Sometimes, you just need to use a plyr",
    "href": "http://www.imachordata.com/sometimes-you-just-need-to-use-a-plyr/"
  },
  {
    "title": "The Coaster Maker by Shiny",
    "href": "https://aschinchon.wordpress.com/2016/04/04/the-coaster-maker-by-shiny/"
  },
  {
    "title": "Blogging with Rmarkdown, knitr, and Jekyll",
    "href": "https://brendanrocks.com/blogging-with-rmarkdown-knitr-jekyll/"
  },
  {
    "title": "Nine lightning talks on R",
    "href": "http://blog.revolutionanalytics.com/2012/10/nine-lightning-talks-on-r.html"
  },
  {
    "title": "[paper published] ChIPseeker: an R/Bioconductor package for ChIP peak annotation, comparison and visualization",
    "href": "https://web.archive.org/web/http://ygc.name/2015/07/13/paper-published-chipseeker-an-rbioconductor-package-for-chip-peak-annotation-comparison-and-visualization/"
  },
  {
    "title": "Debugging with",
    "href": "https://rmkrug.wordpress.com/2011/11/14/debugging-with/"
  },
  {
    "title": "SimilaR",
    "href": "http://www.rexamine.com/2015/03/similar/"
  },
  {
    "title": "Blegging for Data",
    "href": "http://www.johnmyleswhite.com/notebook/2010/08/28/blegging-for-data/"
  },
  {
    "title": "{stargazer} package for beautiful LaTeX tables from R statistical models output",
    "href": "https://www.r-statistics.com/2013/01/stargazer-package-for-beautiful-latex-tables-from-r-statistical-models-output/"
  },
  {
    "title": "ROC Curves in Two Lines of R Code",
    "href": "http://blog.revolutionanalytics.com/2016/08/roc-curves-in-two-lines-of-code.html"
  },
  {
    "title": "R and MongoDB",
    "href": "https://statcompute.wordpress.com/2013/06/08/r-and-mongodb/"
  },
  {
    "title": "Seriously … why don’t math classes use computers?…",
    "href": "https://web.archive.org/web/http://isomorphism.es//post/9632427134"
  },
  {
    "title": "Re: Sorry for the mix up regarding Data Science candidates",
    "href": "http://datascience.la/re-sorry-for-the-mix-up-regarding-data-science-candidates/"
  },
  {
    "title": "Interactive presentation with slidify and googleVis",
    "href": "http://www.magesblog.com/2013/05/interactive-presentation-with-slidify.html"
  },
  {
    "title": "Getting into R, RCommander, JGR and Deducer",
    "href": "https://web.archive.org/web/http://www.paulhurley.co.uk/index.php/categories/computing-geek/27-r-stats/66-getting-into-r-rcommander-jgr-and-deducer"
  },
  {
    "title": "Results from the R Shapefile Contest!",
    "href": "http://www.arilamstein.com/blog/2016/08/01/results-r-shapefile-contest/"
  },
  {
    "title": "Making GUIs using C# and R with the help of R.NET",
    "href": "https://psychwire.wordpress.com/2011/06/19/making-guis-using-c-and-r-with-the-help-of-r-net/"
  }
]
