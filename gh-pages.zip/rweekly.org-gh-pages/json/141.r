[
  {
    "title": "Analytics for Marketing online training 25 – 28 September 2012",
    "href": "https://web.archive.org/web/http://www.cybaea.net/Blogs/Analytics-for-Marketing-25-28-September-2012.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+CybaeaData+%28CYBAEA+Data+and+Analysis%29"
  },
  {
    "title": "Making it easy to use RHadoop on HDInsight Hadoop clusters",
    "href": "http://blog.revolutionanalytics.com/2015/09/install-and-use-r-on-hdinsight-hadoop-clusters.html"
  },
  {
    "title": "NESSIS 2013: The future of sports statistics is here!",
    "href": "http://blog.revolutionanalytics.com/2013/10/nessis-2013-the-future-of-sports-statistics-is-here.html"
  },
  {
    "title": "Practical introduction to Shiny – workshop write-up",
    "href": "http://robinlovelace.net/r/2015/01/22/practical-introduction-shiny.html"
  },
  {
    "title": "Ninth Torino R net meeting and free modelling areal data tutorial",
    "href": "http://torinor.net/2015/05/12/ninth-torino-r-net-meeting-and-free-modelling-areal-data-tutorial/"
  },
  {
    "title": "Supervised Machine Learning with R Workshop on April 30th",
    "href": "http://www.datacommunitydc.org/blog/2016/4/supervised-machine-learning-with-r-workshop-on-april-30th"
  },
  {
    "title": "Tick data retrieval",
    "href": "http://www.investuotojas.eu/?p=461"
  },
  {
    "title": "The R Journal Volume 4/1",
    "href": "https://feedproxy.google.com/~r/OneRTipADay/~3/fMVFHPRBSaQ/the-r-journal-volume-41.html"
  },
  {
    "title": "Kickstarter facilitates $50M in indie game funding",
    "href": "http://blog.revolutionanalytics.com/2012/09/kickstarter-facilitates-50m-in-indie-game-funding.html"
  },
  {
    "title": "useR! 2011 – Wolfgang Huber: Genomes and phenotypes",
    "href": "https://feedproxy.google.com/~r/RUserGroups/~3/MWAs3RJQrQQ/"
  },
  {
    "title": "Binomial Pricing Trees in R",
    "href": "http://www.theresearchkitchen.com/archives/738"
  },
  {
    "title": "R in India: The Hindu",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2009/12/r-in-india-the-hindu.html"
  },
  {
    "title": "What’s my daughter listening to? HTML chart gen in R",
    "href": "http://www.statisticsblog.com/2013/02/whats-my-daughter-listening-to-html-chart-gen-in-r/"
  },
  {
    "title": "Using MKL-Linked R in Eclipse",
    "href": "http://psyccomputing.blogspot.com/2010/04/using-mkl-linked-r-in-eclipse.html"
  },
  {
    "title": "Sales Dashboard in R with qplot and ggplot2 – Part 3",
    "href": "http://www.milanor.net/blog/sales-dashboard-in-r-with-qplot-and-ggplot2-part-3/"
  },
  {
    "title": "Structural Arb Analysis and Portfolio Management Functionality in R",
    "href": "https://quantstrattrader.wordpress.com/2014/09/30/structural-arb-analysis-and-portfolio-management-functionality-in-r/"
  },
  {
    "title": "Graphs from tables",
    "href": "http://andrewgelman.com/2007/08/31/graphs_from_tab/"
  },
  {
    "title": "Look! It’s your data!",
    "href": "https://jehrlinger.wordpress.com/2014/12/10/look-its-your-data/"
  },
  {
    "title": "character handling: mean() vs sd()",
    "href": "http://oddhypothesis.blogspot.com/2013/10/character-handling-mean-vs-sd.html"
  },
  {
    "title": "Quick scatterplot with associated histograms",
    "href": "https://gossetsstudent.wordpress.com/2010/07/22/quick-scatterplot-with-associated-histograms/"
  },
  {
    "title": "Getting Started: Adobe Analytics Clickstream Data Feed",
    "href": "http://randyzwitch.com/adobe-analytics-clickstream-raw-data-feed/"
  },
  {
    "title": "Efficient Variable Selection in R",
    "href": "http://jeromyanglim.blogspot.com/2009/10/efficient-variable-selection-in-r.html"
  },
  {
    "title": "Giving back with code",
    "href": "https://itsalocke.com/giving-back-code/"
  },
  {
    "title": "yorkr crashes the IPL party! – Part 2",
    "href": "https://gigadom.wordpress.com/2016/04/20/yorkr-crashes-the-ipl-party-part-2/"
  },
  {
    "title": "Chromosome bias in R, my notebook",
    "href": "http://jermdemo.blogspot.com/2010/12/chromosome-bias-in-r-my-notebook.html"
  },
  {
    "title": "validate version 1.5 is out",
    "href": "http://www.markvanderloo.eu/yaRb/2016/06/24/validate-version-1-5-is-out/"
  },
  {
    "title": "Converting a list to a data frame",
    "href": "http://jason.bryer.org/posts/2013-01-30/Converting_a_list_to_a_data_frame.html"
  },
  {
    "title": "What is wrong with lift curves",
    "href": "http://www.cybaea.net/journal/2016/10/31/What-is-wrong-with-lift-curves/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+CybaeaOnR+%28CYBAEA+on+R%29"
  },
  {
    "title": "Example 8.4: Including subsetting conditions in output",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/0oWUbq_w3QI/example-84-including-subsetting.html"
  },
  {
    "title": "How well can you scale your strategy?",
    "href": "https://quantstrattrader.wordpress.com/2015/10/21/how-well-can-you-scale-your-strategy/"
  },
  {
    "title": "CausalImpact: A new open-source package for estimating causal effects in time series",
    "href": "https://opensource.googleblog.com/2014/09/causalimpact-new-open-source-package.html"
  },
  {
    "title": "Explore Kaggle Competition Data with R",
    "href": "https://notesofdabbler.wordpress.com/2014/12/23/explore-kaggle-competition-data-with-r/"
  },
  {
    "title": "using clusterProfiler for MeSH Enrichment Analysis",
    "href": "https://web.archive.org/web/https://guangchuangyu.github.io/2016/08/using-clusterprofiler-for-mesh-enrichment-analysis"
  },
  {
    "title": "OpenCPU Release 1.5",
    "href": "https://www.opencpu.org/posts/opencpu-1-5/"
  },
  {
    "title": "RStudio 0.94.92 visited",
    "href": "https://statbandit.wordpress.com/2011/07/30/rstudio-0-94-92-visited/"
  },
  {
    "title": "Data Science Tweet Analysis – What tools are people talking about?",
    "href": "http://www.mango-solutions.com/wp/2015/05/data-science-tweet-analysis-what-tools-are-people-talking-about/"
  },
  {
    "title": "Last and final on Richter’s painting",
    "href": "https://statisfaction.wordpress.com/2011/08/22/richter/"
  },
  {
    "title": "HOW TO HOST YOUR SHINY APP ON AMAZON EC2 FOR MAC OSX",
    "href": "http://www.numbrcrunch.com/blog/how-to-host-your-shiny-app-on-amazon-ec2-for-mac-osx"
  },
  {
    "title": "More typos in Chapter 5",
    "href": "https://xianblog.wordpress.com/2010/12/29/more-typos-in-chapter-5/"
  },
  {
    "title": "Airline Performance Comparison with R/Shiny",
    "href": "http://nycdatascience.com/airline-performance-comparison-with-rshiny/"
  },
  {
    "title": "How to read an excel file (dot xls and dot xlsx) into a data frame with r",
    "href": "http://www.twotorials.com/2012/03/how-to-read-excel-file-dot-xls-and-dot.html"
  },
  {
    "title": "Scheduled Parallel Computing with R: R + Rmpi + OpenMPI + Sun Grid Engine (SGE)",
    "href": "http://blog.nguyenvq.com/2010/01/20/scheduled-parallel-computing-with-r-r-rmpi-openmpi-sun-grid-engine-sge/"
  },
  {
    "title": "Having a problem with R-2.12.2 64-bit and \"gam’ package!",
    "href": "http://princeofslides.blogspot.com/2011/03/having-problem-with-r-2122-64-bit-and.html"
  },
  {
    "title": "spider: an R package for species identity and evolution",
    "href": "http://the-praise-of-insects.blogspot.com/2011/12/spider-r-package-for-species-identity.html"
  },
  {
    "title": "NASDAQ 100 Couples",
    "href": "https://aschinchon.wordpress.com/2015/03/25/nasdaq-100-couples/"
  },
  {
    "title": "Free online data mining and machine learning courses by Stanford University",
    "href": "https://rdatamining.wordpress.com/2015/02/05/free-online-data-mining-and-machine-learning-courses-by-stanford-university/"
  },
  {
    "title": "New edition of “R Companion to Applied Regression” – by John Fox and Sandy Weisberg",
    "href": "https://www.r-statistics.com/2010/12/new-edition-of-r-companion-to-applied-regression-by-john-fox-and-sandy-weisberg/"
  },
  {
    "title": "STEM forums",
    "href": "https://xianblog.wordpress.com/2014/08/15/stem-forums/"
  },
  {
    "title": "Three ways of visualizing the growth of Walmart",
    "href": "http://blog.revolutionanalytics.com/2012/08/three-ways-of-visualizing-the-growth-of-walmart.html"
  },
  {
    "title": "Example 7.16: assess robustness of permutation test to violations of exchangeability assumption",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/ZYYS_S6PYFs/example-716-assess-robustness-of.html"
  }
]
