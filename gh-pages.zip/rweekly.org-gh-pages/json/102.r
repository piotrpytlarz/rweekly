[
  {
    "title": "Boundary conditions Dominate",
    "href": "https://web.archive.org/web/https://stevemosher.wordpress.com/2010/10/17/boundary-conditions-dominate/"
  },
  {
    "title": "Soccer is all about money (?) – Part 3: More plots & analyses",
    "href": "http://rcrastinate.blogspot.com/2012/10/soccer-is-all-about-money-part-3-more.html"
  },
  {
    "title": "Announcing: Introduction to Data Science video course",
    "href": "http://www.win-vector.com/blog/2015/02/announcing-introduction-to-data-science-video-course/"
  },
  {
    "title": "Japan Trade More Specifically with Korea",
    "href": "http://timelyportfolio.blogspot.com/2012/03/japan-trade-more-specifically-with.html"
  },
  {
    "title": "Building a DGA Classifier: Part 1, Data Preparation",
    "href": "http://datadrivensecurity.info/blog/posts/2014/Sep/dga-part1/"
  },
  {
    "title": "Using transparency for data count intuition",
    "href": "https://bridgewater.wordpress.com/2011/09/27/using-transparency-for-data-count-intuition/"
  },
  {
    "title": "New Open Course: Statistical Inference with swirl",
    "href": "https://www.datacamp.com/community/blog/new-open-course-statistical-inference-with-swirl"
  },
  {
    "title": "Webinar: Revolution R is 100% R and More",
    "href": "http://blog.revolutionanalytics.com/2010/12/webinar-revolution-r-is-100-r-and-more.html"
  },
  {
    "title": "The housing bubble by city",
    "href": "http://www.decisionsciencenews.com/2011/03/17/the-housing-bubble-by-city/"
  },
  {
    "title": "What I need to know…",
    "href": "https://web.archive.org/web/http://statsravingmad.com/infos/what-i-need-to-know/?utm_source=rss&utm_medium=rss&utm_campaign=what-i-need-to-know"
  },
  {
    "title": "Reaching escape velocity",
    "href": "http://www.statisticsblog.com/2010/06/reaching-escape-velocity/"
  },
  {
    "title": "Row names in data frames: beware of 1:nrow",
    "href": "https://kbroman.wordpress.com/2012/03/21/row-names-in-data-frames-beware-of-1nrow/"
  },
  {
    "title": "EARL Conference 2016 – London Dates announced.",
    "href": "http://www.mango-solutions.com/wp/2016/01/earl-conference-2016-london-dates-announced/"
  },
  {
    "title": "R vs QGIS for sustainable transport planning",
    "href": "http://robinlovelace.net/r/2015/04/20/r-vs-qgis-for-transport.html"
  },
  {
    "title": "Understanding the data analytics project life cycle",
    "href": "http://pingax.com/understanding-data-analytics-project-life-cycle/?utm_source=rss&utm_medium=rss&utm_campaign=understanding-data-analytics-project-life-cycle"
  },
  {
    "title": "Extra! Extra! Get Your gridExtra!",
    "href": "http://www.imachordata.com/extra-extra-get-your-gridextra/"
  },
  {
    "title": "Update to Introduction to programming econometrics with R",
    "href": "http://www.brodrigues.co/2015/05/03/update-introduction-r-programming"
  },
  {
    "title": "Search and draw cities on a map using OpenStreetMap and R",
    "href": "http://tuxette.nathalievilla.org/?p=1493&lang=en"
  },
  {
    "title": "Manipulation of the legend in ggplot2 (R)",
    "href": "https://biologyforfun.wordpress.com/2013/10/25/manipulation-of-the-legend-in-ggplot2-r/"
  },
  {
    "title": "In case you missed it: June 2015 roundup",
    "href": "http://blog.revolutionanalytics.com/2015/07/in-case-you-missed-it-june-2015-roundup.html"
  },
  {
    "title": "Great Circles, Black Holes, and Community Events Part 3 of 3",
    "href": "http://0utlier.blogspot.com/2012/09/great-circles-black-holes-and-community_14.html"
  },
  {
    "title": "Chart makeover – Unisys Security Insights Survey",
    "href": "http://datadrivensecurity.info/blog/posts/2015/Jul/makeover-fixing-a-survey-response-chart/"
  },
  {
    "title": "Forecasting within limits",
    "href": "http://robjhyndman.com/hyndsight/forecasting-within-limits/"
  },
  {
    "title": "Donor analysis in R – Smith for Congress",
    "href": "http://offensivepolitics.net/blog/2011/06/donor-analysis-in-r-smith-for-congress/"
  },
  {
    "title": "On R, bloggers, politics, sex, alcohol and rock & roll",
    "href": "http://www.quantumforest.com/2011/10/on-r-bloggers-politics-sex-alcohol-and-rock-roll/"
  },
  {
    "title": "Central and Non-Central Distributions",
    "href": "http://davegiles.blogspot.com/2014/11/central-and-non-central-distributions.html"
  },
  {
    "title": "Top 6 reasons you need to be using RStudio",
    "href": "http://www.ancienteco.com/2013/02/top-6-reasons-you-need-to-be-using.html"
  },
  {
    "title": "Exploring Networks with Sankey",
    "href": "http://timelyportfolio.blogspot.com/2013/07/exploring-networks-with-sankey.html"
  },
  {
    "title": "Great Circles, Black Holes, and Community Events Part 2 of 3",
    "href": "http://0utlier.blogspot.com/2012/09/great-circles-black-holes-and-community_12.html"
  },
  {
    "title": "Stan 1.3.0 and RStan 1.3.0 Ready for Action",
    "href": "http://andrewgelman.com/2013/04/12/stan-1-3-0-and-rstan-1-3-0-ready-for-action/"
  },
  {
    "title": "Stupid R tricks: using outer to create many data.frame subsets",
    "href": "https://bridgewater.wordpress.com/2012/02/11/stupid-r-tricks-using-outer-to-create-many-data-frame-subsets/"
  },
  {
    "title": "Short course on Statistical Methods for the Value of Information Analysis",
    "href": "https://gianlubaio.blogspot.com/2016/03/short-course-on-statistical-methods-for.html"
  },
  {
    "title": "Visualizing droughts with R",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2010/03/visualizing-droughts-with-r.html"
  },
  {
    "title": "10 reasons why a grad student should use R",
    "href": "http://blog.revolutionanalytics.com/2011/07/10-reasons-why-a-grad-student-should-use-r.html"
  },
  {
    "title": "analyze the pesquisa de orcamentos familiares (pof) with r",
    "href": "http://www.asdfree.com/2013/06/analyze-pesquisa-de-orcamentos.html"
  },
  {
    "title": "Creating a matrix from a long data.frame",
    "href": "http://www.magesblog.com/2013/10/creating-matrix-from-long-dataframe.html"
  },
  {
    "title": "RStudio, BibTex, and LaTeX",
    "href": "http://jaredknowles.com/journal/2012/1/27/rstudio-bibtex-and-latex.html"
  },
  {
    "title": "bibtex 0.2-1",
    "href": "http://romainfrancois.blog.free.fr/index.php?post/2010/07/10/bibtex-0.2-1"
  },
  {
    "title": "rgl: R and OpenGL",
    "href": "https://web.archive.org/web/http://pineda-krch.com/2007/08/11/rgl-r-and-opengl/"
  },
  {
    "title": "R/Finance 2012 Registration Open",
    "href": "http://blog.fosstrading.com/2012/03/rfinance-2012-registration-open.html"
  },
  {
    "title": "Notes from the Kölner R meeting, 23 May 2014",
    "href": "http://www.magesblog.com/2014/05/notes-from-kolner-r-meeting-23-may-2014.html"
  },
  {
    "title": "Data from last post",
    "href": "https://feedproxy.google.com/~r/CoffeeAndEconometricsInTheMorning/~3/9MRPJcbOmuQ/data-from-last-post.html"
  },
  {
    "title": "Gibbs Sampler in C++",
    "href": "http://gallery.rcpp.org/articles/gibbs-sampler/"
  },
  {
    "title": "Loops revisited: How to rethink macros when using R",
    "href": "http://rforpublichealth.blogspot.com/2013/10/loops-revisited-how-to-rethink-macros.html"
  },
  {
    "title": "The Setup (Part 1)",
    "href": "https://hilaryparker.com/2012/08/16/the-setup-part-1/"
  },
  {
    "title": "Need any more reason to love R-Shiny? Here: you can even use Shiny to create simple games!",
    "href": "http://deanattali.com/blog/shiny-game-lightsout/"
  },
  {
    "title": "Some quibbles about “The R Book” by Michael Crawley",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/Cfp1fsRqaY4/"
  },
  {
    "title": "Extending RevoScaleR for Mining Big Data – Naive Bayes",
    "href": "http://blog.revolutionanalytics.com/2013/05/extending-revoscaler-for-mining-big-data-naive-bayes.html"
  },
  {
    "title": "Polyploidy in sugarcane",
    "href": "http://ggorjan.blogspot.com/2011/09/polyploidy-in-sugarcane.html"
  },
  {
    "title": "Statistics project ideas for students",
    "href": "http://simplystatistics.tumblr.com/post/18493330661/statistics-project-ideas-for-students"
  }
]
