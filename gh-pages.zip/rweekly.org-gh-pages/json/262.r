[
  {
    "title": "Public and Public plus Private debt to GDP",
    "href": "http://plausibel.blogspot.com/2013/01/public-and-public-plus-private-debt-to.html"
  },
  {
    "title": "Data visualization videos",
    "href": "http://robjhyndman.com/hyndsight/data-visualization-videos/?utm_source=rss&utm_medium=rss&utm_campaign=data-visualization-videos"
  },
  {
    "title": "Which functions in R base call internal code?",
    "href": "https://4dpiecharts.com/2010/09/14/which-functions-in-r-base-call-internal-code/"
  },
  {
    "title": "The Uncertainty of Predictions",
    "href": "http://statistical-research.com/the-uncertainty-of-predictions/?utm_source=rss&utm_medium=rss&utm_campaign=the-uncertainty-of-predictions"
  },
  {
    "title": "Let pacman Eat Up library and require",
    "href": "http://data-steve.github.io/let-pacman-eat-up-library-and-require/"
  },
  {
    "title": "Performance of the divide-and-conquer SVD algorithm",
    "href": "http://gallery.rcpp.org/articles/divide-and-concquer-svd/"
  },
  {
    "title": "2012 Summer Olympics: Home Court Advantage – How Will the Brits Perform?",
    "href": "https://feedproxy.google.com/~r/graphoftheweek/fzVA/~3/Tln2O_3Hbz4/summer-olympics-home-court-advantage.html"
  },
  {
    "title": "project euler — problem 68",
    "href": "https://web.archive.org/web/http://ygc.name/2012/12/12/problem-68/"
  },
  {
    "title": "Reflections on John Chambers’ UserR! 2014 Keynote Address",
    "href": "http://blog.revolutionanalytics.com/2014/07/reflections-on-john-chambers-userr-2014-keynote-address.html"
  },
  {
    "title": "Oracle R Distribution for R 2.15.2 available on public-yum",
    "href": "https://blogs.oracle.com/R/entry/oracle_r_distribution_for_r"
  },
  {
    "title": "Bill Veanables Workshop (Augsburg University, Germany :: 2-3 July 2012)",
    "href": "https://www.r-bloggers.com/bill-veanables-workshop-augsburg-university-germany-2-3-july-2012/"
  },
  {
    "title": "Mortgage Refinance Calculator",
    "href": "http://biostatmatt.com/archives/1908"
  },
  {
    "title": "Comparing two-dimensional data sets in R; take II",
    "href": "http://blog.mckuhn.de/2011/03/comparing-two-dimensional-data-sets-in_10.html"
  },
  {
    "title": "Propensity Modeling, Causal Inference, and Discovering Drivers of Growth",
    "href": "http://blog.echen.me/2014/08/15/propensity-modeling-causal-inference-and-discovering-drivers-of-growth/"
  },
  {
    "title": "The Golden Section Search Method: Modifying the Bisection Method with the Golden Ratio for Numerical Optimization",
    "href": "https://chemicalstatistician.wordpress.com/2013/04/22/using-the-bisection-method-with-the-golden-ratio-for-numerical-optimization/"
  },
  {
    "title": "Everything you need to make R Commander locally (packages, dependencies, zip files)",
    "href": "https://robertgrantstats.wordpress.com/2015/10/22/everything-you-need-to-make-r-commander-locally-packages-dependencies-zip-files/"
  },
  {
    "title": "Another Way to Look at Vanguard and Pimco",
    "href": "http://timelyportfolio.blogspot.com/2013/02/another-way-to-look-at-vanguard-and.html"
  },
  {
    "title": "Forecasting with Neural Network (using SAP HANA and R)",
    "href": "http://blagrants.blogspot.com/2013/08/forecasting-with-neural-network-using.html"
  },
  {
    "title": "Adding watermarks to plots",
    "href": "https://web.archive.org/web/http://blog.ggplot2.org/post/23537012922"
  },
  {
    "title": "Because it’s Friday: Foxes on a Trampoline",
    "href": "http://blog.revolutionanalytics.com/2010/08/because-its-friday-foxes-on-a-trampoline.html"
  },
  {
    "title": "Bitsanity",
    "href": "http://www.econometricsbysimulation.com/2014/04/bitsanity.html"
  },
  {
    "title": "ggplot2 themes examples",
    "href": "http://datascienceplus.com/ggplot2-themes-examples/"
  },
  {
    "title": "RODM Article on the Oracle Technology Network",
    "href": "http://www.r-chart.com/2010/08/rodm-article-on-oracle-technology.html"
  },
  {
    "title": "Who are Turkopticon’s Top Contributors?",
    "href": "http://www.econometricsbysimulation.com/2016/01/who-are-turkopticons-top-contributors.html"
  },
  {
    "title": "Using TeXmacs as an interface for R (part 1)",
    "href": "https://mltthinks.wordpress.com/2012/12/03/15/"
  },
  {
    "title": "Free e-book: Data Science with SQL Server 2016",
    "href": "http://blog.revolutionanalytics.com/2016/10/data-science-with-sql-server-2016.html"
  },
  {
    "title": "knitr: nice alternative for Sweave",
    "href": "http://zvfak.blogspot.com/2011/12/knitr-nice-alternative-for-sweave.html"
  },
  {
    "title": "Random matrix theory and APT’s daily global model",
    "href": "https://cartesianfaith.com/2012/01/25/random-matrix-theory-and-apts-daily-global-model/"
  },
  {
    "title": "Wilcoxon Champagne test",
    "href": "https://statisfaction.wordpress.com/2011/06/14/wilcoxon/"
  },
  {
    "title": "Zurich, June 24/25, 2011 – Modern Portfolio Design with Rmetrics",
    "href": "https://web.archive.org/web/https://www.rmetrics.org/zurich2011"
  },
  {
    "title": "R / Finance 2016 Call for Papers",
    "href": "http://dirk.eddelbuettel.com/blog/2015/10/15/"
  },
  {
    "title": "Introducing pipeR 0.4",
    "href": "https://renkun.me/blog/2014/08/04/introducing-pipeR-0.4.html"
  },
  {
    "title": "Shiny for Interactive Application Development using R",
    "href": "http://www.analyticsandvisualization.com/2015/02/shiny-for-interactive-application.html"
  },
  {
    "title": "Martin Maechler Invited Talk at useR! 2014 – Good Practices in R Programming",
    "href": "http://datascience.la/martin-maechler-invited-talk-at-user-2014-good-practices-in-r-programming/"
  },
  {
    "title": "Matlab goes deep [learning]",
    "href": "https://xianblog.wordpress.com/2016/09/05/matlab-goes-deep-learning/"
  },
  {
    "title": "R from source",
    "href": "http://blog.nguyenvq.com/blog/2011/07/11/r-from-source/"
  },
  {
    "title": "i Before e Except After c",
    "href": "http://jason.bryer.org/posts/2013-03-26/i_Before_e_Except_After_c.html"
  },
  {
    "title": "New housedata release 20100923",
    "href": "http://offensivepolitics.net/blog/2010/09/new-housedata-release-20100923/"
  },
  {
    "title": "Analyzing the first Presidential Debate",
    "href": "http://datascienceplus.com/analyzing-the-first-presidential-debate/"
  },
  {
    "title": "knitr, Slideshows, and Dropbox",
    "href": "http://christophergandrud.blogspot.com/2012/05/knitr-slideshows-and-dropbox.html"
  },
  {
    "title": "Evaluating term popularity with twitteR",
    "href": "http://is-r.tumblr.com/post/37468761327/evaluating-term-popularity-with-twitter"
  },
  {
    "title": "R twitteR Analysis: How HOT is the Lynas Rare Earths Mining Malaysia?",
    "href": "https://web.archive.org/web/http://blog.cloudstat.org/post/18296357801"
  },
  {
    "title": "Bio7 2.4 for Windows and Mac Released",
    "href": "http://bio7.org/?p=2737"
  },
  {
    "title": "First meeting of Toronto R User Group this Friday",
    "href": "http://blog.revolutionanalytics.com/2011/01/first-meeting-of-toronto-r-user-group-this-friday.html"
  },
  {
    "title": "Statistics meets rhetoric: A text analysis of \"I Have a Dream\" in R",
    "href": "http://anythingbutrbitrary.blogspot.com/2014/01/statistics-meets-rhetoric-text-analysis.html"
  },
  {
    "title": "Functional programming with lambda.r",
    "href": "https://cartesianfaith.com/2012/11/20/functional-programming-with-lambda-r/"
  },
  {
    "title": "R in a 64 bit world",
    "href": "http://www.win-vector.com/blog/2015/06/r-in-a-64-bit-world/"
  },
  {
    "title": "Using Data Tools to Find Data Tools, the Yo Dawg of Data Hacking",
    "href": "http://www.dataists.com/2010/10/using-data-tools-to-find-data-tools-the-yo-dawg-of-data-hacking/"
  },
  {
    "title": "plot.xts is wonderful",
    "href": "http://timelyportfolio.blogspot.com/2012/08/plotxts-is-wonderful.html"
  },
  {
    "title": "ggplot2: Creating a custom plot with two different geoms",
    "href": "https://rforwork.info/2012/06/10/ggplot2-creating-a-custom-plot-with-two-different-geoms/"
  }
]
