[
  {
    "title": "Uh!",
    "href": "https://web.archive.org/web/http://statsravingmad.com/statistics/uh/"
  },
  {
    "title": "Interestingness comparisons",
    "href": "http://exploringdatablog.blogspot.com/2012/05/interestingness-comparisons.html"
  },
  {
    "title": "Heatmap tables done better, in Sweave and latex",
    "href": "http://stevepowell.blot.im/heatmap-tables-done-better-in-sweave-and-late"
  },
  {
    "title": "In case you missed it: Septemer 2016 roundup",
    "href": "http://blog.revolutionanalytics.com/2016/10/in-case-you-missed-it-septemer-2016-roundup.html"
  },
  {
    "title": "Merging Data Video Tutorial",
    "href": "https://feedproxy.google.com/~r/CoffeeAndEconometricsInTheMorning/~3/StBE7CL3EZc/merging-data-video-tutorial.html"
  },
  {
    "title": "rjags 2.2.0 for  Mac OS X",
    "href": "https://martynplummer.wordpress.com/2011/02/08/rjags-220-for-mac-os-x/"
  },
  {
    "title": "Using ggplot2",
    "href": "https://coolstatsblog.com/2013/10/12/using-ggplot2/"
  },
  {
    "title": "Course Profiles in ggplot2",
    "href": "http://jeffreyhorner.tumblr.com/post/117189974693/course-profiles-in-ggplot2"
  },
  {
    "title": "On the Public Understanding of – and Public Engagement With – Statistics: Reflections on the OU Statistics Group Conference on “Visualisation and Presentation in Statistics”",
    "href": "https://blog.ouseful.info/2011/05/24/reflections-on-the-ou-statistics-group-conference-on-visualisation-and-presentation-in-statistics/"
  },
  {
    "title": "How long is the average dissertation?",
    "href": "https://beckmw.wordpress.com/2013/04/15/how-long-is-the-average-dissertation/"
  },
  {
    "title": "The Unravelling of Structured Investment Vehicles or Birthdays",
    "href": "https://web.archive.org/web/http://kevinldavenport.info/the-unravelling-of-structured-investment-vehicles/"
  },
  {
    "title": "The Mad Hatter Explains Support Vector Machines",
    "href": "http://joelcadwell.blogspot.com/2016/05/the-mad-hatter-explains-support-vector.html"
  },
  {
    "title": "Learning from Learning Curves",
    "href": "http://blog.revolutionanalytics.com/2016/03/learning-from-learning-curves.html"
  },
  {
    "title": "A shortcut function for install.packages() and library()",
    "href": "https://ctszkin.com/2011/09/11/a-shortcut-function-for-install-packages-and-library/"
  },
  {
    "title": "Getting Your Colleagues Hooked on R",
    "href": "https://www.datacamp.com/community/blog/getting-your-colleagues-hooked-on-r"
  },
  {
    "title": "Seminar: Reproducible Research with R, LaTeX, & Sweave",
    "href": "http://www.gettinggeneticsdone.com/2009/11/seminar-reproducible-research-with-r.html"
  },
  {
    "title": "My first Bioconductor conference (2013)",
    "href": "http://yihui.name/en/2013/07/bioconductor-2013/"
  },
  {
    "title": "analyze the world values survey (wvs) with r",
    "href": "http://www.asdfree.com/2014/09/analyze-world-values-survey-wvs-with-r.html"
  },
  {
    "title": "New R package for Eyelink eye-trackers",
    "href": "https://dahtah.wordpress.com/2016/02/23/new-r-package-for-eyelink-eye-trackers/"
  },
  {
    "title": "Simulation of an Oxford (Undergrad) Interview Question",
    "href": "http://decisionsandr.blogspot.com/2013/10/simulation-of-oxford-undergrad.html"
  },
  {
    "title": "Mapping Paris bikes stands",
    "href": "http://sharpsightlabs.com/blog/2015/03/03/mapping-paris-bike-stands/"
  },
  {
    "title": "Popularity bigdata / large data packages in R and ffbase useR presentation",
    "href": "http://www.bnosac.be/index.php/blog/28-popularity-bigdata-large-data-packages-in-r-and-ffbase-user-presentation"
  },
  {
    "title": "Another comparison of heuristic optimizers",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/warvd-O_vmw/"
  },
  {
    "title": "Why is my OS X Yosemite install taking so long?: an analysis",
    "href": "http://www.onthelambda.com/2014/10/23/why-is-my-os-x-yosemite-install-taking-so-long-an-analysis/"
  },
  {
    "title": "Interactive Cobb-Douglas Web App with R",
    "href": "https://stablemarkets.wordpress.com/2014/11/05/interactive-cobb-douglas-web-app-with-r/"
  },
  {
    "title": "PDQ 7.0 Dev is Underway",
    "href": "http://perfdynamics.blogspot.com/2016/05/pdq-70-dev-is-underway.html"
  },
  {
    "title": "Linear model with time series random component",
    "href": "http://ellisp.github.io/blog/2015/11/15/linear-model-timeseries"
  },
  {
    "title": "Steve Jobs’ 2005 Stanford Commencement Address",
    "href": "https://web.archive.org/web/http://ramhiser.com/blog/2011/12/04/steve-jobs-2005-stanford-commencement-address/"
  },
  {
    "title": "What it means to be a US Veteran Today",
    "href": "http://www.econometricsbysimulation.com/2015/11/the-changing-profile-of-us-veteran-today.html"
  },
  {
    "title": "Stratigraphic diagrams using analogue",
    "href": "http://www.fromthebottomoftheheap.net/2011/06/08/stratigraphic-diagrams-using-analogue/"
  },
  {
    "title": "M-O-M vs Y-O-Y inflation rates in India",
    "href": "http://programming-r-pro-bro.blogspot.com/2012/04/m-o-m-vs-y-o-y-inflation-rates-in-india.html"
  },
  {
    "title": "Windows 10 anniversary updates includes a whole Linux layer – this is good news for data scientists",
    "href": "http://realizationsinbiostatistics.blogspot.com/2016/09/windows-10-anniversary-updates-includes.html"
  },
  {
    "title": "Quick View on Correlations of Different Instruments",
    "href": "https://rbresearch.wordpress.com/2012/05/24/quick-view-on-correlations-of-different-asset-classes/"
  },
  {
    "title": "The Pay-for-Performance Myth",
    "href": "http://freakonometrics.hypotheses.org/15999"
  },
  {
    "title": "Dining in San Francisco – Let R Guide You",
    "href": "https://rollingyours.wordpress.com/2014/05/06/dining-in-san-francisco-let-r-guide-you/"
  },
  {
    "title": "Reshaping Horse Import/Export Data to Fit a Sankey Diagram",
    "href": "https://blog.ouseful.info/2013/02/18/reshaping-horse-importexport-data-to-fit-a-sankey-diagram/"
  },
  {
    "title": "Pivot Tables and Medians in R",
    "href": "http://www.psychwire.co.uk/2011/04/pivot-tables-and-medians-in-r/"
  },
  {
    "title": "“Introduction to Data Science” video course contest is closed",
    "href": "http://www.win-vector.com/blog/2016/02/introduction-to-data-science-video-course-contest-is-closed/"
  },
  {
    "title": "Keynotes announced for EARL 2016",
    "href": "http://www.mango-solutions.com/wp/2016/03/keynotes-announced-for-earl-2016/"
  },
  {
    "title": "MySQL and R",
    "href": "http://digitheadslabnotebook.blogspot.com/2011/08/mysql-and-r.html"
  },
  {
    "title": "Faster files in R",
    "href": "http://mlt-thinks.blogspot.com/2011/08/faster-files-in-r.html"
  },
  {
    "title": "A scalable data science platform with Microsoft R Server and Spark",
    "href": "http://blog.revolutionanalytics.com/2016/04/scalable-ds-platform.html"
  },
  {
    "title": "Meetup: DataVis with Plotly on December 16th",
    "href": "http://datascience.la/meetup-datavis-with-plotly-on-december-16th/"
  },
  {
    "title": "Custom Labels for Ordination Diagram",
    "href": "http://thebiobucket.blogspot.com/2011/04/assigning-labels-to-points-in.html"
  },
  {
    "title": "Loading up your custom toolkits at startup – R",
    "href": "http://www.econometricsbysimulation.com/2013/07/loading-up-your-custom-toolkits-at.html"
  },
  {
    "title": "When is a Backtest Too Good to be True?",
    "href": "http://www.quintuitive.com/2015/09/09/when-is-a-backtest-too-good-to-be-true/"
  },
  {
    "title": "Coming of Age: R and Spatial Data Visualisation",
    "href": "http://spatial.ly/2012/01/coming-age-spatial-data-visualisation/"
  },
  {
    "title": "News from archivist 2.0 on eRum2016 conference",
    "href": "http://r-addict.com/2016/10/26/archivist-on-eRum2016.html"
  },
  {
    "title": "Jobs at Amazon",
    "href": "http://robjhyndman.com/hyndsight/jobs-at-amazon/"
  },
  {
    "title": "Generation of E-Learning Exams in R for Moodle, OLAT, etc.",
    "href": "https://www.r-statistics.com/2012/12/generation-of-e-learning-exams-in-r-for-moodle-olat-etc/"
  }
]
