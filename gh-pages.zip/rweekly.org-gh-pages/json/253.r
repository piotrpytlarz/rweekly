[
  {
    "title": "R/Finance 2012 program announced, registration open",
    "href": "http://blog.revolutionanalytics.com/2012/03/rfinance-2012-registration-open.html"
  },
  {
    "title": "project euler-Problem 43",
    "href": "https://web.archive.org/web/http://ygc.name/2011/11/08/project-euler-problem-43/"
  },
  {
    "title": "“LaF”-ing about fixed width formats",
    "href": "https://statbandit.wordpress.com/2014/11/10/laf-ing-about-fixed-width-formats/"
  },
  {
    "title": "Le Monde puzzle [48: resolution]",
    "href": "https://xianblog.wordpress.com/2010/12/04/le-monde-puzzle-48-resolution/"
  },
  {
    "title": "A simple ggplot2 scatterplot",
    "href": "http://lukemiller.org/index.php/2011/06/a-simple-ggplot2-scatterplot/"
  },
  {
    "title": "RStudio Addin Code-Helpers for Plotting",
    "href": "http://statistics.rainandrhino.org/2016/01/21/rstudio-addin-code-helpers-for-plotting.html"
  },
  {
    "title": "An adverse consequence of fitting \"maximal\" linear mixed models",
    "href": "http://vasishth-statistics.blogspot.com/2014/08/an-adverse-consequence-of-fitting.html"
  },
  {
    "title": "New R User Group in Argentina",
    "href": "http://blog.revolutionanalytics.com/2011/07/new-r-user-group-in-argentina.html"
  },
  {
    "title": "7 new R jobs (2015-02-23)",
    "href": "https://www.r-bloggers.com/7-new-r-jobs-2015-02-23/"
  },
  {
    "title": "The infamous apply function",
    "href": "http://rforpublichealth.blogspot.com/2012/09/the-infamous-apply-function.html"
  },
  {
    "title": "Re-mapping Massachusetts Special election results",
    "href": "http://offensivepolitics.net/blog/2010/01/re-mapping-massachusetts-special-election-results/"
  },
  {
    "title": "Pricing Reinsurance Contracts",
    "href": "http://freakonometrics.hypotheses.org/9646"
  },
  {
    "title": "Coursera’s free R courses are running again soon",
    "href": "http://blog.revolutionanalytics.com/2013/09/courseras-free-r-courses-are-running-again-soon.html"
  },
  {
    "title": "OpenCPU Server Release 1.5.4",
    "href": "https://www.opencpu.org/posts/opencpu-1-5-4/"
  },
  {
    "title": "Using caret to compare models",
    "href": "http://blog.revolutionanalytics.com/2016/05/using-caret-to-compare-models.html"
  },
  {
    "title": "Home Runs heating up?",
    "href": "https://swordofcrom.wordpress.com/2011/11/12/home-runs-heating-up/"
  },
  {
    "title": "2013-4 Generating Structured and Labelled SVG",
    "href": "http://stattech.wordpress.fos.auckland.ac.nz/2013-4-generating-structured-and-labelled-svg/"
  },
  {
    "title": "MCMC chain analysis and convergence diagnostics with coda in R",
    "href": "https://theoreticalecology.wordpress.com/2011/12/09/mcmc-chain-analysis-and-convergence-diagnostics-with-coda-in-r/"
  },
  {
    "title": "RcppZiggurat 0.1.3: Faster Random Normal Draws",
    "href": "http://dirk.eddelbuettel.com/blog/2015/07/26/"
  },
  {
    "title": "simulation by inverse cdf",
    "href": "https://xianblog.wordpress.com/2015/01/14/simulation-by-inverse-cdf/"
  },
  {
    "title": "Construire un moteur de reco simple avec R (1/2)",
    "href": "http://rformining.blogspot.com/2013/09/construire-un-moteur-de-reco-simple.html"
  },
  {
    "title": "SQL Server, Power BI, and R",
    "href": "http://blog.revolutionanalytics.com/2016/06/sql-server-power-bi-and-r.html"
  },
  {
    "title": "Reproducible research, training wheels, and knitr",
    "href": "http://civilstat.com/2014/02/reproducible-research-training-wheels-and-knitr/"
  },
  {
    "title": "At what sample size do correlations stabilize?",
    "href": "http://www.nicebread.de/at-what-sample-size-do-correlations-stabilize/"
  },
  {
    "title": "Adding lines or points to an existing barplot",
    "href": "https://danganothererror.wordpress.com/2011/01/15/adding-lines-or-points-to-an-existing-barplot/"
  },
  {
    "title": "Two-minute tutorials for R beginners",
    "href": "http://blog.revolutionanalytics.com/2012/03/two-minute-tutorials-for-r-beginners.html"
  },
  {
    "title": "R as a general-purpose language for creating DSLs",
    "href": "http://blog.revolutionanalytics.com/2014/10/r-as-a-general-purpose-language-for-creating-dsls.html"
  },
  {
    "title": "Introducing Rocker: Docker for R",
    "href": "http://dirk.eddelbuettel.com/blog/2014/10/23/"
  },
  {
    "title": "Szkolenie z analizy sieciowej",
    "href": "http://bc.bojanorama.pl/2015/11/szkolenie-z-analizy-sieciowej/"
  },
  {
    "title": "GIBBS us a break",
    "href": "https://web.archive.org/web/http://empty-moon-9726.heroku.com//blog/2012/01/19/gibbs-in-the-cloud/"
  },
  {
    "title": "ChainLadder 0.2.2 is out with improved glmReserve function",
    "href": "http://www.magesblog.com/2015/09/chainladder-022-is-out-with-improved.html"
  },
  {
    "title": "Unsupervised Google Maps image classification",
    "href": "https://metvurst.wordpress.com/2015/05/19/unsupervised-google-maps-image-classification-16/"
  },
  {
    "title": "Next Level Web Scraping",
    "href": "http://thebiobucket.blogspot.com/2011/11/next-level-web-scraping.html"
  },
  {
    "title": "Simulating p curves and detecting dodgy stats",
    "href": "http://psychologicalstatistics.blogspot.com/2012/02/simulating-p-curves-and-detecting-dodgy.html"
  },
  {
    "title": "Difficulty with mcsm?",
    "href": "https://xianblog.wordpress.com/2010/05/05/difficulty-with%c2%a0mcsm/"
  },
  {
    "title": "Paper on the Gillespie Stochastic Simulation Algorithm in press",
    "href": "https://web.archive.org/web/http://pineda-krch.com/2008/02/01/paper-on-the-gillespie-stochastic-simulation-algorithm-in-press/"
  },
  {
    "title": "R Cheat Sheets and more",
    "href": "https://feedproxy.google.com/~r/OneRTipADay/~3/nrwR7Yv5p0k/r-cheat-sheets-and-more.html"
  },
  {
    "title": "Mike’s CNC 2010-08-27 18:36:00",
    "href": "http://mikescnc.blogspot.com/2010/08/support-opengov-idea-to-create-platform.html"
  },
  {
    "title": "Zurich, Oct 2013 – R Crash Course",
    "href": "https://www.rmetrics.org/node/150"
  },
  {
    "title": "piecewise regression",
    "href": "http://eranraviv.com/piecewise-regression/?utm_source=rss&utm_medium=rss&utm_campaign=piecewise-regression"
  },
  {
    "title": "Scenario analysis for option strategies.",
    "href": "http://quant-day.blogspot.com/2013/05/scenario-analysis-for-option-strategies_30.html"
  },
  {
    "title": "Player timelines with ggplot",
    "href": "http://www.premiersoccerstats.com/wordpress/?p=1124&utm_source=rss&utm_medium=rss&utm_campaign=player-timelines-with-ggplot"
  },
  {
    "title": "R tips: Determine if function is called from specific package",
    "href": "https://web.archive.org/web/http://www.cybaea.net/Blogs/Data/R-tips-Determine-if-function-is-called-from-specific-package.html"
  },
  {
    "title": "Global Economic Maps",
    "href": "http://r-video-tutorial.blogspot.com/2015/05/global-economic-maps.html"
  },
  {
    "title": "GUIs for R",
    "href": "http://ekonometrics.blogspot.com/2011/03/guis-for-r.html"
  },
  {
    "title": "(Manually) making letters with geom_path() – fun example",
    "href": "https://mcfromnz.wordpress.com/2012/08/15/making-letters-with-geom_path-fun-example-4/"
  },
  {
    "title": "Archival and analysis of #GI2013 Tweets",
    "href": "http://www.gettinggeneticsdone.com/2013/11/archival-and-analysis-of-gi2013-tweets.html"
  },
  {
    "title": "Bringing a Revolution to Microsoft",
    "href": "http://www.mango-solutions.com/wp/2015/01/bring-a-revolution-to-microsoft/"
  },
  {
    "title": "Pie Charts. Are they worth the Fight?",
    "href": "http://citizen-statistician.org/2014/07/28/pie-charts-are-they-worth-the-fight/"
  },
  {
    "title": "taxize v0.3.0 update – a new data source, taxonomy in writing, and uBio examples",
    "href": "http://ropensci.org/blog/2014/05/20/taxize_v03/"
  }
]
