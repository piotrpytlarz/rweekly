[
  {
    "title": "More variables, spinoff projects, and RuPaul’s Drag Race season 5 predictions: episode 10",
    "href": "http://badhessian.org/2013/04/more-variables-spinoff-projects-and-rupauls-drag-race-season-5-predictions-episode-10/"
  },
  {
    "title": "GEE using Stata vs. R",
    "href": "http://sgsong.blogspot.com/2011/10/gee-using-stata-vs-r.html"
  },
  {
    "title": "ggplot graphs in publications?",
    "href": "https://mcfromnz.wordpress.com/2012/11/06/ggplot-graphs-in-publications/"
  },
  {
    "title": "R, RStudio, and release and dev Bioconductor",
    "href": "http://rmflight.github.io/posts/2013/09/bioconductorDevLibs.html"
  },
  {
    "title": "Revolution Newsletter: March 2012",
    "href": "http://blog.revolutionanalytics.com/2012/03/revolution-newsletter-march-2012.html"
  },
  {
    "title": "R and Data Mining – Examples and Case Studies now in Chinese",
    "href": "https://rdatamining.wordpress.com/2014/12/02/r-and-data-mining-examples-and-case-studies-now-in-chinese/"
  },
  {
    "title": "Extending RCy3 Vignettes (Google Summer of Code Project)",
    "href": "http://feedproxy.google.com/~r/rlunean/~3/PQ2fOhqcjLk/"
  },
  {
    "title": "Workflow Articles in “The Political Methodologist”",
    "href": "https://kieranhealy.org/blog/archives/2011/04/01/workflow-articles-in-the-political-methodologist/"
  },
  {
    "title": "Efficient Accumulation in R",
    "href": "http://blog.revolutionanalytics.com/2015/07/efficient-accumulation-in-r.html"
  },
  {
    "title": "Opinions Not Backed by Money Updated Again",
    "href": "http://timelyportfolio.blogspot.com/2012/03/opinions-not-backed-by-money-updated.html"
  },
  {
    "title": "Filtering Data with L2 Regularisation",
    "href": "http://www.exegetic.biz/blog/2014/03/filtering-data-with-l2-regularisation/?utm_source=rss&utm_medium=rss&utm_campaign=filtering-data-with-l2-regularisation"
  },
  {
    "title": "R-Project: Translation Status",
    "href": "http://www.fernandohrosa.com.br/en/P/r-project-translation-status/?utm_source=rss&utm_medium=rss&utm_campaign=r-project-translation-status"
  },
  {
    "title": "Mapping US Religion Adherence by County in R",
    "href": "http://www.arilamstein.com/blog/2016/01/25/mapping-us-religion-adherence-county-r/"
  },
  {
    "title": "Analyzing the DVI Indicator",
    "href": "http://www.quintuitive.com/2013/11/30/analyzing-the-dvi-indicator/"
  },
  {
    "title": "Method of Simulated Moments with R",
    "href": "http://www.brodrigues.co/2013/01/29/method-of-simulated-moments-with-r"
  },
  {
    "title": "Some detail on the last plot",
    "href": "http://learningrbasic.blogspot.com/2009/07/some-detail-on-last-plot.html"
  },
  {
    "title": "Big data in ranching and animal husbandry",
    "href": "https://cartesianfaith.com/2016/01/20/big-data-in-ranching-and-animal-husbandry/"
  },
  {
    "title": "Fully customizable legends for rleafmap",
    "href": "http://www.pieceofk.fr/?p=376"
  },
  {
    "title": "googleVis 0.5.6 released on CRAN",
    "href": "http://www.magesblog.com/2014/10/googlevis-056-released-on-cran.html"
  },
  {
    "title": "Fun with .Rprofile and customizing R startup",
    "href": "http://www.onthelambda.com/2014/09/17/fun-with-rprofile-and-customizing-r-startup/"
  },
  {
    "title": "Cross Pollination from Systematic Investor",
    "href": "http://timelyportfolio.blogspot.com/2011/11/after-reading-fine-article-style.html"
  },
  {
    "title": "Line plots of longitudinal summary data in R using ggplot2",
    "href": "https://hopstat.wordpress.com/2015/07/09/line-plots-of-longitudinal-summary-data-in-r-using-ggplot2-2/"
  },
  {
    "title": "Congressional ideology by state",
    "href": "http://is-r.tumblr.com/post/34288940225/congressional-ideology-by-state"
  },
  {
    "title": "Announcing the caretEnsemble R package",
    "href": "http://jaredknowles.com/journal/2015/1/20/announcing-the-caretensemble-package-for-r"
  },
  {
    "title": "RForcecom Demo VVideo",
    "href": "https://hiratake55.wordpress.com/2015/08/16/rforcecom-demo-vvideo/"
  },
  {
    "title": "Long XLU Short SPY",
    "href": "http://timelyportfolio.blogspot.com/2011/05/long-xlu-short-spy.html"
  },
  {
    "title": "Customising vegan’s ordination plots",
    "href": "http://www.fromthebottomoftheheap.net/2012/04/11/customising-vegans-ordination-plots/"
  },
  {
    "title": "how to use the ifelse function in r",
    "href": "http://www.twotorials.com/2012/04/how-to-use-ifelse-function-in-r.html"
  },
  {
    "title": "Cricket analytics with cricketr in paperback and Kindle versions",
    "href": "https://gigadom.wordpress.com/2016/02/05/cricket-analytics-with-cricketr-in-paperback-and-kindle-versions/"
  },
  {
    "title": "Voronoi Diagrams in Plotly and R",
    "href": "http://moderndata.plot.ly/voronoi-diagrams-in-plotly-and-r/"
  },
  {
    "title": "Converting an R HClust object into a D3.js Dendrogram",
    "href": "http://www.coppelia.io/2014/07/converting-an-r-hclust-object-into-a-d3-js-dendrogram/"
  },
  {
    "title": "Subsetting in readOGR",
    "href": "http://geospatial.commons.gc.cuny.edu/2013/12/31/subsetting-in-readogr/"
  },
  {
    "title": "Bon Appetit: A restaurant recommender for tourists visiting the Netherlands",
    "href": "https://web.archive.org/web/https://longhowlam.wordpress.com/2015/12/04/bon-appetit-a-restaurant-recommender-for-tourists-visiting-the-netherlands-2/"
  },
  {
    "title": "Goodbye static graphs, hello shiny, ggvis, rmarkdown (vs JS solutions)",
    "href": "https://web.archive.org/web/http://jackman.stanford.edu/blog/?p=2892"
  },
  {
    "title": "Shading overlapping area of curves in R",
    "href": "http://yusung.blogspot.com/2008/01/shading-overlapping-area-of-curves-in-r.html"
  },
  {
    "title": "Science at the speed of ligth",
    "href": "https://bartomeuslab.com/2013/10/15/science-at-the-speed-of-light/"
  },
  {
    "title": "Google, The Brew’s On Me",
    "href": "http://jeffreyhorner.tumblr.com/post/2082461519/google-the-brews-on-me"
  },
  {
    "title": "Sequential testing in a triangle test setting",
    "href": "http://wiekvoet.blogspot.com/2013/01/sequential-testing-in-triangle-test.html"
  },
  {
    "title": "Should I be nice?",
    "href": "https://kbroman.wordpress.com/2012/05/18/should-i-be-nice/"
  },
  {
    "title": "R in Production – Opening Talk by Yasmin Lucero – LA R meetup @ useR! 2014",
    "href": "http://datascience.la/r-in-production-opening-talk-by-yasmin-lucero-la-r-meetup-user-2014/"
  },
  {
    "title": "The Collatz Fractal",
    "href": "https://aschinchon.wordpress.com/2014/04/04/the-collatz-fractal/"
  },
  {
    "title": "Case Study: Animation and Others Vizs",
    "href": "http://jkunst.com/r/case-study-animation-and-others-vizs/"
  },
  {
    "title": "STL Transform",
    "href": "http://gallery.rcpp.org/articles/stl-transform/"
  },
  {
    "title": "Example 8.37: Read sheets from an excel file",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/dwA_2CvdYmE/example-837-read-sheets-from-excel-file.html"
  },
  {
    "title": "Backtesting a Simple Stock Trading Strategy",
    "href": "https://feedproxy.google.com/~r/ModernToolMaking/~3/lFRwskrIp34/backtesting-simple-stock-trading.html"
  },
  {
    "title": "Parallel computation [revised]",
    "href": "https://xianblog.wordpress.com/2011/03/15/parallel-computation-revised/"
  },
  {
    "title": "What $480M of Gross Revenue Looks Like to Groupon",
    "href": "http://www.paulbutler.org/"
  },
  {
    "title": "Describing Data: Frequently Used Commands",
    "href": "https://feedproxy.google.com/~r/CoffeeAndEconometricsInTheMorning/~3/NSP1kgKLrow/describing-data-frequently-used.html"
  },
  {
    "title": "STL random_shuffle for permutations",
    "href": "http://gallery.rcpp.org/articles/stl-random-shuffle/"
  },
  {
    "title": "Canonical Correlation Analysis on Imaging",
    "href": "http://alstatr.blogspot.com/2015/01/canonical-correlation-analysis-on.html"
  }
]
