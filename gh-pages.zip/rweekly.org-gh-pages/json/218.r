[
  {
    "title": "Statistics:  Losing Ground to CS, Losing Image Among Students",
    "href": "https://matloff.wordpress.com/2014/08/26/statistics-losing-ground-to-cs-losing-image-among-students/"
  },
  {
    "title": "Revolution Newsletter: October 2011",
    "href": "http://blog.revolutionanalytics.com/2011/10/revolution-newsletter-october-2011.html"
  },
  {
    "title": "In case you missed it: May 2012 Roundup",
    "href": "http://blog.revolutionanalytics.com/2012/06/in-case-you-missed-it-may-2012-roundup.html"
  },
  {
    "title": "Two tips: adding title for graph with multiple plots; add significance asterix onto a boxplot",
    "href": "http://onetipperday.sterding.com/2012/06/two-tips-adding-title-for-graph-with.html"
  },
  {
    "title": "Create Word documents from R with R2DOCX",
    "href": "http://blog.revolutionanalytics.com/2013/06/create-word-documents-from-r-with-r2docx.html"
  },
  {
    "title": "Computing on the Language",
    "href": "http://simplystatistics.tumblr.com/post/11988685443/computing-on-the-language"
  },
  {
    "title": "Messy matters explores the probability of winning of basketball…",
    "href": "https://web.archive.org/web/http://blog.ggplot2.org/post/24401184979"
  },
  {
    "title": "Lots of data != \"Big Data\"",
    "href": "http://blog.revolutionanalytics.com/2013/03/lots-of-data-big-data.html"
  },
  {
    "title": "News about speeding R up",
    "href": "https://xianblog.wordpress.com/2011/05/24/news-about-speeding-r-up/"
  },
  {
    "title": "Review: Kölner R Meeting 26 Feburary 2014",
    "href": "http://www.magesblog.com/2014/03/review-kolner-r-meeting-26-feburary-2014.html"
  },
  {
    "title": "Update for Backtesting Asset Allocation Portfolios post",
    "href": "https://systematicinvestor.wordpress.com/2013/10/24/update-for-backtesting-asset-allocation-portfolios-post/"
  },
  {
    "title": "taskscheduleR: R package to schedule R scripts with the Windows task manager",
    "href": "http://www.bnosac.be/index.php/blog/56-taskscheduler-r-package-to-schedule-r-scripts-with-the-windows-task-manager"
  },
  {
    "title": "R progress indicators",
    "href": "https://binfalse.de/2011/06/19/r-progress-indicators/"
  },
  {
    "title": "A million ? what are the odds…",
    "href": "http://blog.free.fr/"
  },
  {
    "title": "Merging Multiple Data Files into One Data Frame",
    "href": "https://feedproxy.google.com/~r/CoffeeAndEconometricsInTheMorning/~3/T9s9bnTAAmw/merging-multiple-data-files-into-one.html"
  },
  {
    "title": "Giving a Damn About Statistics: Baseball, Shark Attacks, and Green M&M’s",
    "href": "http://spatioanalytics.com/2015/03/13/giving-a-damn-about-statistics-baseball-shark-attacks-and-green-mms/"
  },
  {
    "title": "R 3.0 released; ggplot2 stat_summary bug fixed!",
    "href": "http://mindingthebrain.blogspot.com/2013/04/r-30-released-ggplot2-statsummary-bug.html"
  },
  {
    "title": "Stats in the Court Room Hands on Tutorial",
    "href": "http://plausibel.blogspot.com/2013/04/stats-in-court-room-hands-on-tutorial.html"
  },
  {
    "title": "Reverse Engineering with Correlated Features",
    "href": "http://freakonometrics.hypotheses.org/47979"
  },
  {
    "title": "how to download and install r",
    "href": "http://www.twotorials.com/2012/03/how-to-download-and-install-r.html"
  },
  {
    "title": "Timer progress bar added to pbapply package",
    "href": "http://peter.solymos.org/code/2016/03/04/timer-progress-bar-added-to-pbapply-package.html"
  },
  {
    "title": "How to make a rough check to see if your data is normally distributed",
    "href": "http://firsttimeprogrammer.blogspot.com/2015/07/how-to-make-rough-check-to-see-if-your.html"
  },
  {
    "title": "With Size, Does Risk–>Return?",
    "href": "http://timelyportfolio.blogspot.com/2011/12/with-size-does-risk.html"
  },
  {
    "title": "ROracle support for TimesTen In-Memory Database",
    "href": "https://blogs.oracle.com/R/entry/roracle_support_times_ten_in"
  },
  {
    "title": "R and SAS in the curriculum: getting students to \"think with data\"",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/dhaUlhF7kTQ/r-and-sas-in-curriculum-getting.html"
  },
  {
    "title": "Who are the pollinators? (with R plot)",
    "href": "https://bartomeuslab.com/2012/12/17/who-are-the-pollinators/"
  },
  {
    "title": "covr: A Victory for Open Source",
    "href": "http://www.mango-solutions.com/wp/2016/07/covr-a-victory-for-open-source/"
  },
  {
    "title": "FastCompany on telling stories with data",
    "href": "http://blog.revolutionanalytics.com/2011/08/fastcompany-on-telling-stories-with-data.html"
  },
  {
    "title": "Revised market prediction distributions",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/il93MmFLb8I/"
  },
  {
    "title": "Software tools for data analysis – an overview",
    "href": "https://feedproxy.google.com/~r/RUserGroups/~3/U-fUeqHqeRM/"
  },
  {
    "title": "Using neural networks for credit scoring: a simple example",
    "href": "https://web.archive.org/web/http://fishyoperations.com/tag_feeds/fishyoperations.com/fishyoperations.com/neural-network-for-credit-scoring.html"
  },
  {
    "title": "Shiny cheat sheet",
    "href": "https://blog.rstudio.org/2014/06/30/shiny-cheat-sheet/"
  },
  {
    "title": "Key Driver vs. Network Analysis in R",
    "href": "http://joelcadwell.blogspot.com/2013/11/key-driver-vs-network-analysis-in-r.html"
  },
  {
    "title": "How to make a scientific result disappear",
    "href": "https://politicalmethodology.wordpress.com/2013/02/27/how-to-make-a-scientific-result-disappear/"
  },
  {
    "title": "Creating inset maps using spatial objects",
    "href": "https://jannesm.wordpress.com/2016/07/05/inset-maps-using-spatial-objects/"
  },
  {
    "title": "The New Microsoft Data Science User Group Program",
    "href": "http://blog.revolutionanalytics.com/2015/09/the-new-microsoft-data-science-user-group-program.html"
  },
  {
    "title": "High incidence in Measles Data in Project Tycho",
    "href": "http://wiekvoet.blogspot.com/2014/04/high-incidence-in-measles-data-in.html"
  },
  {
    "title": "The avalanche of publications mentioning GO",
    "href": "https://web.archive.org/web/http://www.cwcity.de/fehler/404.php"
  },
  {
    "title": "Bootstrap, strap-on, anal-yzing… statistics is getting weirder by the moment",
    "href": "https://danganothererror.wordpress.com/2010/07/29/bootstrap-strap-on-anal-yzing-statistics-is-getting-weirder-by-the-moment/"
  },
  {
    "title": "Where have all the Hacker News old-timers gone?",
    "href": "http://blog.revolutionanalytics.com/2010/08/where-have-all-the-hacker-news-oldtimers-gone.html"
  },
  {
    "title": "Gauge Chart in R",
    "href": "https://gastonsanchez.wordpress.com/2013/01/10/gauge-chart-in-r/"
  },
  {
    "title": "Evolve your own beats — automatically generating music via algorithms",
    "href": "https://web.archive.org/web/http://www.vikparuchuri.com/blog/categories/r/www.vikparuchuri.com/blog/evolve-your-own-beats-automatically-generating-music/"
  },
  {
    "title": "A central hub for R bloggers",
    "href": "https://feedproxy.google.com/~r/OneRTipADay/~3/vVXUXc-hRvU/central-hub-for-r-bloggers.html"
  },
  {
    "title": "Profile Likelihood",
    "href": "http://freakonometrics.hypotheses.org/20573"
  },
  {
    "title": "Simple template for scientific manuscripts in R markdown",
    "href": "http://www.petrkeil.com/?p=2401"
  },
  {
    "title": "Call for Presentations – EARL Conference, London",
    "href": "https://www.r-users.com/jobs/call-for-presentations-earl-conference-london/"
  },
  {
    "title": "Introduction to R: Installation, Using R as a Calculator, Operators",
    "href": "https://r-norberg.blogspot.com/2012/10/introduction-to-r-installation-using-r.html"
  },
  {
    "title": "Because it’s Friday: Asteroids",
    "href": "http://blog.revolutionanalytics.com/2010/11/because-its-friday-asteroids.html"
  },
  {
    "title": "NIPS 2010: Monte Carlo workshop",
    "href": "https://xianblog.wordpress.com/2010/09/03/nips-2010-monte-carlo-workshop/"
  },
  {
    "title": "analyze the national survey on drug use and health (nsduh) with r",
    "href": "http://www.asdfree.com/2012/11/analyze-national-survey-on-drug-use-and.html"
  }
]
