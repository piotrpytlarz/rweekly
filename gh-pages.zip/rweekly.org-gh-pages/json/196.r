[
  {
    "title": "A prediction for the Olympic men’s 100m sprint",
    "href": "http://blog.revolutionanalytics.com/2012/07/a-prediction-for-the-olympic-mens-100m-sprint.html"
  },
  {
    "title": "RPostgreSQL 0.1-6",
    "href": "http://dirk.eddelbuettel.com/blog/2009/10/19/"
  },
  {
    "title": "Revolution Newsletter: February 2013",
    "href": "http://blog.revolutionanalytics.com/2013/02/revolution-newsletter-february-2013.html"
  },
  {
    "title": "The Evolution of LondonR",
    "href": "http://www.mango-solutions.com/wp/2015/02/the-evolution-of-londonr/"
  },
  {
    "title": "Election analysis contest entry part 1 – introducing the nzelect R package",
    "href": "http://ellisp.github.io/blog/2016/04/03/nzelect1"
  },
  {
    "title": "Portfolio diversity",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/mqGcn01GJLQ/"
  },
  {
    "title": "Revolution Analytics at JSM 2012",
    "href": "http://blog.revolutionanalytics.com/2012/07/revolution-analytics-at-jsm-2012.html"
  },
  {
    "title": "Inspirational Stack Overflow Dendrogram Applied to Currencies",
    "href": "http://timelyportfolio.blogspot.com/2012/07/inspirational-stack-overflow-dendrogram.html"
  },
  {
    "title": "Statistics on Microsoft Excel",
    "href": "http://agrarianresearch.org/blog/?p=68"
  },
  {
    "title": "Life Is Short, Use Python",
    "href": "http://www.mathfinance.cn/life-is-short-use-python/"
  },
  {
    "title": "R in genomics @ SciLifeLab, Solna",
    "href": "https://martinsbioblogg.wordpress.com/2015/03/24/r-in-genomics-scilifelab-solna/"
  },
  {
    "title": "R is fun",
    "href": "http://optimallog.blogspot.com/2012/06/r-is-fun.html"
  },
  {
    "title": "Ever wonder how popular your favorite R functions are?",
    "href": "http://www.econometricsbysimulation.com/2014/03/ever-wonder-how-popular-your-favorite-r.html"
  },
  {
    "title": "Making random, equally-sized partitions",
    "href": "http://is-r.tumblr.com/post/32661033774/making-random-equally-sized-partitions"
  },
  {
    "title": "Strategy 1 Extended (Part 1)",
    "href": "https://tradingposts.wordpress.com/2013/06/26/strategy-1-extended-part-1/"
  },
  {
    "title": "More Beautiful Growth of $1 Chart",
    "href": "http://timelyportfolio.blogspot.com/2012/02/more-beautiful-growth-of-1-chart.html"
  },
  {
    "title": "Merging Data — SAS, R, and Python",
    "href": "http://statsadventure.blogspot.com/2013/06/merging-data-sas-r-and-python.html"
  },
  {
    "title": "Data Transformations – from R to PMML – The pmmlTransformations Package",
    "href": "http://www.predictive-analytics.info/2013/08/data-transformations-from-r-to-pmml.html"
  },
  {
    "title": "Building DataMind: FREE Online Interactive Learning Plaftorm for R",
    "href": "https://web.archive.org/web/http://blog.datacamp.com/2013/07/11/building-datamind-free-online-interactive-learning-plaftorm-for-r/"
  },
  {
    "title": "Multiple Sclerosis Tweet-Chat: Review",
    "href": "http://blog.revolutionanalytics.com/2012/05/multiple-sclerosis-tweet-chat-review.html"
  },
  {
    "title": "Dave Giles on \"MCMC for Econometrics Students\"",
    "href": "http://www.econometricsbysimulation.com/2014/04/dave-giles-on-mcmc-for-econometrics.html"
  },
  {
    "title": "Why has R, despite quirks, been so successful?",
    "href": "http://blog.revolutionanalytics.com/2015/06/why-has-r-been-so-successful.html"
  },
  {
    "title": "Welcome to our Weblog",
    "href": "https://blog.rstudio.org/2011/02/27/welcome-to-our-weblog/"
  },
  {
    "title": "Stata 12 embraces structural equation models",
    "href": "http://ekonometrics.blogspot.com/2011/06/stata-12-revives-structural-equation.html"
  },
  {
    "title": "Veterinary Epidemiologic Research: Count and Rate Data – Zero Counts",
    "href": "https://denishaine.wordpress.com/2013/05/06/veterinary-epidemiologic-research-count-and-rate-data-zero-counts/"
  },
  {
    "title": "Measuring Randomness in Capital Markets",
    "href": "https://www.klittlepage.com/2013/09/29/measuring-randomness-in-capital-markets/"
  },
  {
    "title": "mlr loves OpenML",
    "href": "https://mlr-org.github.io/mlr-loves-OpenML/"
  },
  {
    "title": "In data scientist survey, R is the most-used tool (other than databases)",
    "href": "http://blog.revolutionanalytics.com/2014/01/in-data-scientist-survey-r-is-the-most-used-tool-other-than-databases.html"
  },
  {
    "title": "Multithreading in R (or other types of non-sequencial programming)",
    "href": "https://xmphforex.wordpress.com/2011/02/21/multithreading-in-r-or-other-types-of-non-sequencial-programming/"
  },
  {
    "title": "R Election Analysis Contest Results",
    "href": "http://www.arilamstein.com/blog/2016/04/18/r-election-analysis-contest-results/"
  },
  {
    "title": "Maximum Loss and Mean-Absolute Deviation risk measures",
    "href": "https://systematicinvestor.wordpress.com/2011/10/14/maximum-loss-and-mean-absolute-deviation-risk-measures/"
  },
  {
    "title": "ggplot2 0.9.0 released",
    "href": "https://www.r-bloggers.com/ggplot2-0-9-0-released/"
  },
  {
    "title": "Looking for Preference in All the Wrong Places: Neuroscience Suggests Choice Model Misspecification",
    "href": "http://joelcadwell.blogspot.com/2015/06/looking-for-preference-in-all-wrong.html"
  },
  {
    "title": "Row Search in Parallel",
    "href": "https://statcompute.wordpress.com/2014/09/28/1106/"
  },
  {
    "title": "project euler – problem 47",
    "href": "https://web.archive.org/web/http://ygc.name/2011/11/08/project-euler-problem-47/"
  },
  {
    "title": "Downloading NFL.com Fantasy Football Projections using R",
    "href": "http://fantasyfootballanalyticsr.blogspot.com/2013/03/downloading-nflcom-fantasy-football.html"
  },
  {
    "title": "Etymology",
    "href": "http://is-r.tumblr.com/post/31713579725/etymology"
  },
  {
    "title": "Introduction to ORE Embedded R Script Execution",
    "href": "https://blogs.oracle.com/R/entry/analyzing_big_data_using_the1"
  },
  {
    "title": "Installing RStudio & additional R packages in Oracle Big Data Lite VM 4.2.1",
    "href": "http://www.nodalpoint.com/installing-rstudio-additional-r-packages-in-oracle-big-data-lite-vm-4-2-1/"
  },
  {
    "title": "R: choose file dialog box",
    "href": "http://www.statisticsblog.com/2010/05/r-choose-file-dialog-box/"
  },
  {
    "title": "New R Package: rmote",
    "href": "http://ryanhafen.com/blog/rmote"
  },
  {
    "title": "The grammar of graphics (L. Wilkinson)",
    "href": "http://zoonek.free.fr/blosxom/2006/10/21/"
  },
  {
    "title": "In case you missed it: April 2015 roundup",
    "href": "http://blog.revolutionanalytics.com/2015/05/in-case-you-missed-it-april-2015-roundup.html"
  },
  {
    "title": "Wald’s graphical sequential inspection procedure",
    "href": "http://blog.revolutionanalytics.com/2015/12/walds-graphical-sequential-inspection-procedure.html"
  },
  {
    "title": "R: Analyisis of a Sport Event",
    "href": "https://web.archive.org/web/http://statistik-stuttgart.de/statistical-analysis-of-the-lac-degerloch-volkslauf-2010/"
  },
  {
    "title": "Classification of the Hyper-Spectral and LiDAR Imagery using R (mostly). Part 1: Result Evaluation",
    "href": "http://ssrebelious.blogspot.com/2013/07/classification-of-hyper-spectral-and.html"
  },
  {
    "title": "testthat 0.8 (and 0.8.1)",
    "href": "https://blog.rstudio.org/2014/02/25/testthat-0-8/"
  },
  {
    "title": "Exploring NYC Taxi Data with Microsoft R Server and HDInsight",
    "href": "http://blog.revolutionanalytics.com/2016/04/mrs-nyc-taxi.html"
  },
  {
    "title": "Easy way of determining number of lines/records in a given large file using R",
    "href": "http://costaleconomist.blogspot.com/2010/02/easy-way-of-determining-number-of.html"
  },
  {
    "title": "Introduction to Kaggle Algorithmic Trading Challenge",
    "href": "http://viksalgorithms.blogspot.com/2012/01/introduction-to-kaggle-algorithmic.html"
  }
]
