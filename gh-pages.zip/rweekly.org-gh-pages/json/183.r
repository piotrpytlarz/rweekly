[
  {
    "title": "USDA Textural Soil Classification",
    "href": "http://www.ggtern.com/2014/01/15/usda-textural-soil-classification/"
  },
  {
    "title": "MCMSki IV, Jan. 6-8, 2014, Chamonix (news #10)",
    "href": "https://xianblog.wordpress.com/2013/10/14/mcmski-iv-jan-6-8-2014-chamonix-news-10/"
  },
  {
    "title": "Practical Implementation of Neural Network based time series (stock) prediction  -PART 4",
    "href": "http://intelligenttradingtech.blogspot.com/2010/02/practical-implementation-of-neural_04.html"
  },
  {
    "title": "Free e-book: Effective Graphs with Microsoft R Open",
    "href": "http://blog.revolutionanalytics.com/2016/05/e-book-effective-graphs.html"
  },
  {
    "title": "The Joy of R: A Feline Guide",
    "href": "https://web.archive.org/web/http://pineda-krch.com/2011/11/05/the-joy-of-r-a-feline-guide/"
  },
  {
    "title": "Gulf Stream centre detection",
    "href": "http://dankelley.github.io/r/2014/06/22/gulf-stream-center.html"
  },
  {
    "title": "RStudio v0.99 Preview: Data Viewer Improvements",
    "href": "https://blog.rstudio.org/2015/02/24/rstudio-v0-99-preview-data-viewer-improvements/"
  },
  {
    "title": "Combining ggplot Images",
    "href": "https://diffuseprior.wordpress.com/2012/07/03/417/"
  },
  {
    "title": "Coursera’s free online R course starts today",
    "href": "http://blog.revolutionanalytics.com/2012/09/courseras-free-online-r-course-starts-today.html"
  },
  {
    "title": "Storing a Function in a Separate File in R",
    "href": "http://blog.mollietaylor.com/2013/01/storing-function-in-separate-file-in-r.html"
  },
  {
    "title": "Obama recruiting analysts and R is one preferred skill",
    "href": "https://rdatamining.wordpress.com/2011/09/27/obama-recruiting-analysts-and-r-is-one-preferred-skill/"
  },
  {
    "title": "Analemma graphs",
    "href": "http://dankelley.github.io//r/2013/12/27/analemma.html"
  },
  {
    "title": "The new R compiler package in R 2.13.0: Some first experiments",
    "href": "http://dirk.eddelbuettel.com/blog/2011/04/12/"
  },
  {
    "title": "Online index of plots and corresponding R scripts",
    "href": "https://chemicalstatistician.wordpress.com/2014/10/27/2457/"
  },
  {
    "title": "Example 8.6: Changing the reference category for categorical variables",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/MWpV6dXIA9w/example-86-changing-reference-category.html"
  },
  {
    "title": "R and Docker",
    "href": "http://dirk.eddelbuettel.com/blog/2014/09/25/"
  },
  {
    "title": "Calender Heatmap with Google Analytics Data",
    "href": "http://www.tatvic.com/blog/calender-heatmap-with-google-analytics-data/"
  },
  {
    "title": "New cheat-sheet for the dplyrXdf package",
    "href": "http://blog.revolutionanalytics.com/2016/08/new-cheat-sheet-for-the-dplyrxdf-package.html"
  },
  {
    "title": "Disaggregating Annual Losses into Each Quarter",
    "href": "https://statcompute.wordpress.com/2013/04/23/disaggregating-annual-losses-into-each-quarter/"
  },
  {
    "title": "A new open journal on Data Science",
    "href": "http://blog.revolutionanalytics.com/2012/07/a-new-open-journal-on-data-science.html"
  },
  {
    "title": "iptools 0.3.0 (“Violet Packet”) Now on CRAN with Windows Support!",
    "href": "http://rud.is/b/2016/01/08/iptools-0-3-0-violet-packet-now-on-cran-with-windows-support/"
  },
  {
    "title": "From Lavaan to OpenMx",
    "href": "http://industrialcodeworkshop.blogspot.com/2012/10/from-lavaan-to-openmx.html"
  },
  {
    "title": "Julia, I Love You",
    "href": "http://www.johnmyleswhite.com/notebook/2012/03/31/julia-i-love-you/"
  },
  {
    "title": "June Reading List",
    "href": "http://davegiles.blogspot.com/2014/05/june-reading-list.html"
  },
  {
    "title": "R Function Usage Frequencies",
    "href": "http://www.johnmyleswhite.com/notebook/2009/12/07/r-function-usage-frequencies/"
  },
  {
    "title": "Hy-phen-ate All The Things! (in R)",
    "href": "http://rud.is/b/2016/03/18/hy-phen-ate-all-the-things-in-r/"
  },
  {
    "title": "Book Review: R for Business Analytics",
    "href": "http://www.exegetic.biz/blog/2015/01/book-review-r-for-business-analytics/?utm_source=rss&utm_medium=rss&utm_campaign=book-review-r-for-business-analytics"
  },
  {
    "title": "Eight New Ideas From Data Visualization Experts",
    "href": "http://blog.plot.ly/post/110830563382/eight-new-ideas-from-data-visualization-experts"
  },
  {
    "title": "Color:  The Cinderella of dataviz",
    "href": "https://web.archive.org/web/http://www.dataspora.com/2009/03/how-to-color-multivariate-data/"
  },
  {
    "title": "Age Comparison Results for Individual Fish",
    "href": "http://derekogle.com/fishR/2015-09-05-Age-Comparison-Results-for-Individual-Fish"
  },
  {
    "title": "Linguistic Notation Inside of R Plots!",
    "href": "http://val-systems.blogspot.com/2012/04/linguistic-notation-inside-of-r-plots.html"
  },
  {
    "title": "Intermission: A Quick Thought on Robust Kurtosis",
    "href": "https://quantstrattrader.wordpress.com/2014/09/10/intermission-a-quick-thought-on-robust-kurtosis/"
  },
  {
    "title": "Introducing Revolution R Open and Revolution R Plus",
    "href": "http://blog.revolutionanalytics.com/2014/10/introducing-revolution-r-open-and-revolution-r-plus.html"
  },
  {
    "title": "List of useful RStudio addins made by useRs (a github repo)",
    "href": "https://www.r-bloggers.com/list-of-useful-rstudio-addins-made-by-users-a-github-repo/"
  },
  {
    "title": "Intro R training from RStudio: NYC May 13-14, SF May 20-21 (and discounts)",
    "href": "https://www.r-bloggers.com/intro-r-training-from-rstudio-nyc-may-13-14-sf-may-20-21-and-discounts/"
  },
  {
    "title": "Calculate RMSE and MAE in R and SAS",
    "href": "https://heuristically.wordpress.com/2013/07/12/calculate-rmse-and-mae-in-r-and-sas/"
  },
  {
    "title": "Short R tutorial: Scraping Javascript Generated Data with R",
    "href": "https://www.datacamp.com/community/tutorials/scraping-javascript-generated-data-with-r"
  },
  {
    "title": "Exploratory Data Analysis: Conceptual Foundations of Histograms – Illustrated with New York’s Ozone Pollution Data",
    "href": "https://chemicalstatistician.wordpress.com/2013/07/09/exploratory-data-analysis-conceptual-foundations-of-histograms-illustrated-with-new-yorks-ozone-pollution-data/"
  },
  {
    "title": "Revolution R Enterprise in the Amazon Cloud",
    "href": "http://blog.revolutionanalytics.com/2014/02/revolution-r-enterprise-in-the-amazon-cloud.html"
  },
  {
    "title": "STL transform + remove_copy for subsetting",
    "href": "http://gallery.rcpp.org/articles/stl-transform-for-subsetting/"
  },
  {
    "title": "Bio7 2.0 for Windows 32 bit Release",
    "href": "http://bio7.org/?p=2484"
  },
  {
    "title": "Merci taxi!",
    "href": "https://xianblog.wordpress.com/2011/02/09/merci-taxi/"
  },
  {
    "title": "R vs Spreadsheets",
    "href": "http://datadrivensecurity.info/blog/posts/2014/Jan/r-vs-spreadsheets/"
  },
  {
    "title": "subset vectors in Rcpp11",
    "href": "https://web.archive.org/web/http://blog.r-enthusiasts.com/2014/06/07/subset-vectors-in-rcpp11/"
  },
  {
    "title": "A Fast Intro to PLYR for R",
    "href": "http://www.cerebralmastication.com/2009/08/a-fast-intro-to-plyr-for-r/"
  },
  {
    "title": "6 new jobs for R users – from around the world (2016-10-19)",
    "href": "https://www.r-users.com/jobs/data-engineer-2/"
  },
  {
    "title": "Updating R (on Windows) through a menu-bar: installr 0.9 released on CRAN",
    "href": "https://www.r-statistics.com/2013/04/updating-r-on-windows-through-a-menu-bar-installr-0-9-released-on-cran/"
  },
  {
    "title": "New package tokenizers joins rOpenSci",
    "href": "http://ropensci.org/blog/2016/08/23/tokenizers-joins-ropensci"
  },
  {
    "title": "A function to find the “Penultimax”",
    "href": "https://rforwork.info/2012/09/14/a-function-to-find-the-penultimax/"
  },
  {
    "title": "Visualing High Dimensions as DNA Strands",
    "href": "http://suehpro.blogspot.com/2016/01/visualing-high-dimensions-as-dna-strands.html"
  }
]
