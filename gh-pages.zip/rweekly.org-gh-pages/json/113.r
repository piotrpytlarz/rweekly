[
  {
    "title": "Double Box Plot package boxplotdbl 1.2.0 released",
    "href": "https://tomizonor.wordpress.com/2013/11/24/double-box-plot-1-2/"
  },
  {
    "title": "Google Earth and ocean depth contours",
    "href": "http://fishvice.blogspot.com/2012/05/google-earth-and-ocean-depth-contours.html"
  },
  {
    "title": "Example 2014.11: Contrasts the basic way for R",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/7oNL6TYLKyA/example-201411-contrasts-basic-way-for-r.html"
  },
  {
    "title": "GillespieSSA 0.3-1 released",
    "href": "https://web.archive.org/web/http://pineda-krch.com/2007/10/04/gillespiessa-03-1-released/"
  },
  {
    "title": "Scary Derivatives and Scary XML in R",
    "href": "http://timelyportfolio.blogspot.com/2011/07/scary-derivatives-and-scary-xml-in-r.html"
  },
  {
    "title": "googleVis — NASA’s exploration of Mars",
    "href": "https://web.archive.org/web/http://ec2-184-73-106-109.compute-1.amazonaws.com/wordpress/?p=429&utm_source=rss&utm_medium=rss&utm_campaign=googlevis-nasas-exploration-of-mars"
  },
  {
    "title": "Day #18 Error in Knime node R-Plot",
    "href": "https://web.archive.org/web/http://flyordie.sin.khk.be/2011/04/06/day-18-error-in-knime-node-r-plot/"
  },
  {
    "title": "Analyzing “Twitter faces” in R with Microsoft Project Oxford",
    "href": "https://longhowlam.wordpress.com/2015/12/21/analyzing-twitter-faces-in-r-with-microsoft-project-oxford/"
  },
  {
    "title": "R: The Dummies Package",
    "href": "https://web.archive.org/web/http://www.opendatagroup.com/2009/09/30/r-the-dummies-package/"
  },
  {
    "title": "Rcpp at LondonR, oct 5th",
    "href": "http://romainfrancois.blog.free.fr/index.php?post/2010/08/13/Rcpp-at-LondonR"
  },
  {
    "title": "Le Monde puzzle [#737]",
    "href": "https://xianblog.wordpress.com/2011/08/26/le-monde-puzzle-737/"
  },
  {
    "title": "Network of trade",
    "href": "http://mkao006.blogspot.com/2012/09/network-of-trade.html"
  },
  {
    "title": "Big Data Insights – IT Support Log Analysis",
    "href": "http://costaleconomist.blogspot.com/2015/12/big-data-insights-it-support-log.html"
  },
  {
    "title": "On radical manuscript openness",
    "href": "http://bayesfactor.blogspot.com/2015/08/on-radical-manuscript-openness.html"
  },
  {
    "title": "postdoctoral positions in Paris",
    "href": "https://xianblog.wordpress.com/2011/10/20/postdoctoral-positions-in-paris/"
  },
  {
    "title": "RStudio Beta 2 (v0.93)",
    "href": "https://blog.rstudio.org/2011/04/11/rstudio-beta2/"
  },
  {
    "title": "Use meaningful color schemes in your figures",
    "href": "http://www.gettinggeneticsdone.com/2009/06/use-meaningful-color-schemes-in-your.html"
  },
  {
    "title": "The Simpsons as a Chart",
    "href": "http://suehpro.blogspot.com/2016/03/the-simpsons-as-chart.html"
  },
  {
    "title": "Because it’s Friday: Kittens, beware Tufte",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2010/03/because-its-friday-kittens-beware-tufte.html"
  },
  {
    "title": "Analytics with SAP and R (Windows version)",
    "href": "http://blagrants.blogspot.com/2012/06/analytics-with-sap-and-r-windows.html"
  },
  {
    "title": "Clustering Lightning Discharges to Identify Storms",
    "href": "http://www.exegetic.biz/blog/2013/09/clustering-lightning-discharges-to-identify-storms/"
  },
  {
    "title": "Export Trade Clusters",
    "href": "https://benmazzotta.wordpress.com/2009/11/24/export-trade-clusters/"
  },
  {
    "title": "Registration now open for Master R Developer workshop in San Francisco",
    "href": "https://blog.rstudio.org/2014/09/29/registration-now-open-for-master-r-developer-workshop-in-san-francisco/"
  },
  {
    "title": "Estimating Ages from First Names Part 2 – Using Some Morbid Test Data",
    "href": "https://rforwork.info/2013/07/31/estimating-ages-from-first-names-part-2-using-some-morbid-test-data/"
  },
  {
    "title": "Science link fest for the week of the 27th",
    "href": "http://paleocave.sciencesortof.com/2013/07/science-link-fest-for-the-week-of-the-27th/"
  },
  {
    "title": "pre-generate pictures of your knitting",
    "href": "http://blog.davidchudzicki.com/2011/04/pre-generate-pictures-of-your-knitting.html"
  },
  {
    "title": "R Layout command.",
    "href": "http://www.r-chart.com/2010/06/r-layout-command.html"
  },
  {
    "title": "A taste of functional programmming in Rcpp11",
    "href": "https://web.archive.org/web/http://blog.r-enthusiasts.com/2014/05/23/a-taste-of-functional-programmming-in-rcpp11/"
  },
  {
    "title": "Regular Expressions Exercises – Part 1",
    "href": "http://r-exercises.com/2016/10/30/regular-expressions-part-1/"
  },
  {
    "title": "Risk-Opportunity Analysis",
    "href": "https://feedproxy.google.com/~r/FossTrading/~3/wyc1UEIMdjY/risk-opportunity-analysis.html"
  },
  {
    "title": "MCqMC 2016",
    "href": "https://xianblog.wordpress.com/2016/01/18/mcqmc-2016/"
  },
  {
    "title": "cumsum ( rnorm(50), lend=\"butt\", lwd=12, type=\"h\" )\r\nCumulative…",
    "href": "https://web.archive.org/web/http://isomorphism.es//post/2145437787"
  },
  {
    "title": "Response Time Percentiles for Multi-server Applications",
    "href": "http://perfdynamics.blogspot.com/2013/12/response-time-percentiles-for-multi.html"
  },
  {
    "title": "BCEs0 version 1.1 on CRAN",
    "href": "https://gianlubaio.blogspot.com/2013/11/bces0-version-11-on-cran.html"
  },
  {
    "title": "Installing R packages in SQL Server using only T-SQL",
    "href": "https://tomaztsql.wordpress.com/2016/08/02/installing-r-packages-in-sql-server-using-only-t-sql/"
  },
  {
    "title": "Basic ideas on aggregate, plyr and crosstables!",
    "href": "https://fibosworld.wordpress.com/2012/10/17/another-one-on-aggregate-plyr-and-crosstables/"
  },
  {
    "title": "Survival Analysis With Generalized Models: Part II (time discretization, hazard rate integration and calculation of hazard ratios)",
    "href": "https://statmd.wordpress.com/2015/05/02/survival-analysis-with-generalized-models-part-ii-time-discretization-hazard-rate-integration-and-calculation-of-hazard-ratios/"
  },
  {
    "title": "Get The Best R Books For Just $5",
    "href": "http://thinktostart.com/get-best-r-books-just-5/"
  },
  {
    "title": "Visualizing ROC Curves in R using Plotly",
    "href": "http://moderndata.plot.ly/visualizing-roc-curves-in-r-using-plotly/"
  },
  {
    "title": "Homicides in Mexico 2006-2009",
    "href": "https://blog.diegovalle.net/2011/01/homicides-in-mexico-2006-2009.html"
  },
  {
    "title": "Building DataMind: FREE Online Interactive Learning Platform for R",
    "href": "https://www.datacamp.com/community/blog/building-datamind-free-online-interactive-learning-plaftorm-for-r"
  },
  {
    "title": "Some Python Nooks and Crannies",
    "href": "http://www.bytemining.com/2010/01/some-python-nooks-and-crannies/"
  },
  {
    "title": "Geometric Random graphs",
    "href": "http://random-miner.blogspot.com/2013/03/geometric-random-graphs.html"
  },
  {
    "title": "The ‘rsvg’ Package: High Quality Image Rendering in R",
    "href": "https://www.opencpu.org/posts/svg-release/"
  },
  {
    "title": "R exams",
    "href": "https://xianblog.wordpress.com/2010/01/11/r-exams/"
  },
  {
    "title": "Analyzing birth rates from census data from RevoScaleR",
    "href": "http://blog.revolutionanalytics.com/2011/11/analyzing-birth-rates-from-census-data-from-revoscaler.html"
  },
  {
    "title": "R 2.12.2 scheduled for February 25",
    "href": "http://blog.revolutionanalytics.com/2011/02/r-2122-scheduled-for-february-25.html"
  },
  {
    "title": "R-NOLD 2012-05-23 05:48:00",
    "href": "http://r-nold.blogspot.com/2012/05/mapping-global-earthquake-using-xml-and.html"
  },
  {
    "title": "Design Flaws in R #3 — Zero Subscripts",
    "href": "https://radfordneal.wordpress.com/2008/09/21/design-flaws-in-r-3-%E2%80%94-zero-subscripts/"
  },
  {
    "title": "Code: LaTeX tables for lme4 models",
    "href": "http://leftcensored.skepsi.net/2011/03/13/code-latex-tables-for-lme4-models/"
  }
]
