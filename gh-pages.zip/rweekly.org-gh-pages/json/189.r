[
  {
    "title": "Down-Sampling Using Random Forests",
    "href": "http://appliedpredictivemodeling.com/blog/2013/12/8/28rmc2lv96h8fw8700zm4nl50busep"
  },
  {
    "title": "Boolean 3 (finally) on CRAN",
    "href": "http://leftcensored.skepsi.net/2014/06/25/boolean-3-finally-on-cran/"
  },
  {
    "title": "Guest Blogger Recap",
    "href": "http://blog.revolutionanalytics.com/2014/01/guest-blogger-recap.html"
  },
  {
    "title": "useR! 2014 is underway with 16 tutorials",
    "href": "http://blog.revolutionanalytics.com/2014/06/user-2014-is-underway.html"
  },
  {
    "title": "analyze the fda adverse event reporting system (faers) with r",
    "href": "http://www.asdfree.com/2014/07/analyze-fda-adverse-event-reporting.html"
  },
  {
    "title": "The optimal way to do sweave",
    "href": "http://sgsong.blogspot.com/2009/10/optimal-way-to-do-sweave.html"
  },
  {
    "title": "Recology has moved",
    "href": "https://r-ecology.blogspot.com/2012/01/recology-has-moved.html"
  },
  {
    "title": "Tips & Tricks 8: Examining Replicate Error",
    "href": "http://ww1.geomorph.net/2015/04/tips-tricks-8-examining-replicate-error.html"
  },
  {
    "title": "Using JavaScript visualization libraries with R",
    "href": "http://zvfak.blogspot.com/2013/08/using-javascript-visualization.html"
  },
  {
    "title": "functions exercises",
    "href": "http://r-exercises.com/2016/02/07/functions-exercises/"
  },
  {
    "title": "DataMind & The R Service Bus @ RBelgium",
    "href": "https://web.archive.org/web/http://www.bnosac.be/index.php/blog/27-datamind-a-the-r-service-bus-rbelgium"
  },
  {
    "title": "New R User Group in Orange County, CA",
    "href": "http://blog.revolutionanalytics.com/2011/03/new-r-user-group-in-orange-county-ca.html"
  },
  {
    "title": "Train neural network in R, predict in SAS",
    "href": "https://heuristically.wordpress.com/2011/11/11/train-neural-network-in-r-predict-in-sas/"
  },
  {
    "title": "Comparing Symmetric Eigenvalue Performance",
    "href": "https://wrathematics.github.io/2016/10/28/comparing-symmetric-eigenvalue-performance/"
  },
  {
    "title": "Survey on R and education",
    "href": "https://web.archive.org/web/http://blog.datacamp.com/2013/06/12/survey-on-r-and-education/"
  },
  {
    "title": "Candy branching process",
    "href": "https://xianblog.wordpress.com/2010/05/06/candy-branching%c2%a0process/"
  },
  {
    "title": "Snowdoop/partools Update",
    "href": "https://matloff.wordpress.com/2014/12/26/snowdooppartools-update/"
  },
  {
    "title": "Improve The Efficiency in Joining Data with Index",
    "href": "https://statcompute.wordpress.com/2013/06/09/improve-the-efficiency-in-joining-data-with-index/"
  },
  {
    "title": "A gentle introduction to parallel computing in R",
    "href": "http://blog.revolutionanalytics.com/2016/01/a-gentle-introduction-to-parallel-computing-in-r.html"
  },
  {
    "title": "Live Rolling Correlation Plot",
    "href": "http://eranraviv.com/live-rolling-correlation-plot/?utm_source=rss&utm_medium=rss&utm_campaign=live-rolling-correlation-plot"
  },
  {
    "title": "Monthly patterns in Scottish snow (1946-2006)",
    "href": "https://scottishsnow.wordpress.com/2016/04/24/monthly-snow/"
  },
  {
    "title": "A plot of ‘Who works at home’",
    "href": "http://wiekvoet.blogspot.com/2016/01/a-plot-of-who-works-at-home.html"
  },
  {
    "title": "Sequence of shopping carts analysis with R – Sankey diagram",
    "href": "http://analyzecore.com/2014/10/31/sequence-carts-analysis-sankey/"
  },
  {
    "title": "Grexit stage left: visualizing the online discussion around Greece’s possible Euro exit",
    "href": "http://michaelbommarito.com/2012/05/24/grexit-stage-left-visualizing-the-online-discussion-around-greeces-possible-euro-exit/?utm_source=rss&utm_medium=rss&utm_campaign=grexit-stage-left-visualizing-the-online-discussion-around-greeces-possible-euro-exit"
  },
  {
    "title": "A book about some important bits of R",
    "href": "http://shape-of-code.coding-guidelines.com/2014/09/27/a-book-about-some-important-bits-of-r/"
  },
  {
    "title": "Why I love open source!",
    "href": "http://www.fromthebottomoftheheap.net/2010/12/03/why-i-love-open-source/"
  },
  {
    "title": "Conservatism of Congressional delegation and %Bush vote",
    "href": "http://learningrbasic.blogspot.com/2009/06/conservatism-of-congressional.html"
  },
  {
    "title": "Memory limit management in R",
    "href": "http://ggorjan.blogspot.com/2008/12/memory-limit-management-in-r.html"
  },
  {
    "title": "TreeBASE in R: a first tutorial",
    "href": "https://web.archive.org/web/http://www.carlboettiger.info/wordpress/archives/1702"
  },
  {
    "title": "7 new R jobs (2015-05-11)",
    "href": "https://www.r-users.com/jobs/research-analytics-manager/"
  },
  {
    "title": "New d3.js visualization: Understanding Significance Testing and Statistical Power",
    "href": "http://rpsychologist.com/new-d3-js-visualization-understanding-significance-testing-and-statistical-power"
  },
  {
    "title": "analyze the national health interview survey (nhis) with r",
    "href": "http://www.asdfree.com/2012/10/analyzing-national-health-interview.html"
  },
  {
    "title": "osmar – Don’t Miss this New R-Geo-Package!",
    "href": "http://thebiobucket.blogspot.com/2012/01/dont-miss-this-new-r-geo-package-osmar.html"
  },
  {
    "title": "Upcoming events",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/8iPmmzh30nk/"
  },
  {
    "title": "Sentiment Analysis on Twitter with Datumbox API",
    "href": "http://thinktostart.com/sentiment-analysis-on-twitter-with-datumbox-api/"
  },
  {
    "title": "Introducing stackr: An R package for querying the Stack Exchange API",
    "href": "http://varianceexplained.org/r/introducing-stackr/"
  },
  {
    "title": "R and (Software) Relatives",
    "href": "http://www.r-chart.com/2014/02/r-and-software-relatives-oreilly.html"
  },
  {
    "title": "Bayesian regression with STAN Part 2: Beyond normality",
    "href": "http://datascienceplus.com/bayesian-regression-with-stan-beyond-normality/"
  },
  {
    "title": "Have my old job!",
    "href": "https://4dpiecharts.com/2012/11/14/have-my-old-job/"
  },
  {
    "title": "MAT8886 Extremes and sums (of i.i.d. random variables)",
    "href": "http://blog.free.fr/"
  },
  {
    "title": "My First (R) Shiny App: An Annotated Tutorial",
    "href": "https://qualityandinnovation.com/2015/12/06/my-first-shiny-app-an-annotated-tutorial/"
  },
  {
    "title": "The R Journal, Volume 3/1",
    "href": "http://blog.fosstrading.com/2011/06/r-journal-volume-31.html"
  },
  {
    "title": "Bayesian adaptive sampling",
    "href": "https://xianblog.wordpress.com/2010/12/06/bayesian-adaptive-sampling/"
  },
  {
    "title": "Splitting a Dataset Revisited: Keeping Covariates Balanced Between Splits",
    "href": "http://www.gettinggeneticsdone.com/2011/03/splitting-dataset-revisited-keeping.html"
  },
  {
    "title": "Web Development with R (video)",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2010/01/web-development-with-r-video.html"
  },
  {
    "title": "Balancing the Load | What’s New in RStudio Server Pro?",
    "href": "https://blog.rstudio.org/2015/01/13/balancing-the-load-whats-new-in-rstudio-server-pro/"
  },
  {
    "title": "Summarize content of a vector or data.frame every n entries",
    "href": "https://fabiomarroni.wordpress.com/2013/08/08/summarize-content-of-a-vector-or-data-frame-every-n-entries/"
  },
  {
    "title": "Exploring the Half-Life Property of K",
    "href": "http://derekogle.com/fishR/2016-06-12-Halflife-of-K"
  },
  {
    "title": "Inside-R.org, a new community site for R",
    "href": "http://blog.revolutionanalytics.com/2010/07/insiderorg-a-new-community-site-for-r.html"
  },
  {
    "title": "R package for effect size calculations for psychology researchers",
    "href": "http://andrewgelman.com/2013/10/19/r-package-for-effect-size-calculations-for-psychology-researchers/"
  }
]
