[
  {
    "title": "Example 9.27: Baseball and shrinkage",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/wk0c0s72_UM/example-927-baseball-and-shrinkage.html"
  },
  {
    "title": "Winners of Mozilla Open Data Competition announced",
    "href": "http://blog.revolutionanalytics.com/2011/01/winners-of-mozilla-open-data-competition-announced.html"
  },
  {
    "title": "Flip a fair coin 4x. Probability of H following H is 40%???",
    "href": "http://www.econometricsbysimulation.com/2015/10/flip-fair-coin-4x-probability-of-h.html"
  },
  {
    "title": "New version of assertive and answers to tutorial exercises",
    "href": "https://4dpiecharts.com/2015/07/16/new-version-of-assertive-and-answers-to-tutorial-exercises/"
  },
  {
    "title": "NCEAS Codefest Follow-up",
    "href": "http://ropensci.org/blog/2014/09/23/nceas-codefest-follow-up/"
  },
  {
    "title": "Quick thoughts on “R-Powered Web Apps”",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2010/01/quick-thoughts-on-rpowered-web-apps.html"
  },
  {
    "title": "Why Backtesting On Individual Legs In A Spread Is A BAD Idea",
    "href": "https://quantstrattrader.wordpress.com/2014/12/31/why-backtesting-on-individual-legs-in-a-spread-is-a-bad-idea/"
  },
  {
    "title": "Boston R User Group Talk [UPDATE]",
    "href": "http://appliedpredictivemodeling.com/blog/2016/3/4/boston-r-user-group-talk"
  },
  {
    "title": "Turnovers are poison",
    "href": "https://web.archive.org/web/http://pirategrunt.com/2012/12/20/turnovers-are-poison/"
  },
  {
    "title": "2013 was a good year for R User Group Meetings",
    "href": "http://blog.revolutionanalytics.com/2013/12/2013-a-good-year-for-r-user-group-meetings.html"
  },
  {
    "title": "RcppArmadillo 0.2.0 (and 0.2.1)",
    "href": "http://dirk.eddelbuettel.com/blog/2010/05/20/"
  },
  {
    "title": "Calculating confidence intervals for proportions",
    "href": "https://aghaynes.wordpress.com/2014/04/09/calculating-confidence-intervals-for-proportions/"
  },
  {
    "title": "Some Thoughts On Shiny Open Source: Render Multiple Pages",
    "href": "https://web.archive.org/web/http://blog.anomdev.com/2016/06/27/some-thoughts-on-shiny-open-source-render-multiple-pages/"
  },
  {
    "title": "Revolution Newsletter: November 2011",
    "href": "http://blog.revolutionanalytics.com/2011/11/revolution-newsletter-november-2011.html"
  },
  {
    "title": "Evaluating model performance – A practical example of the effects of overfitting and data size on prediction",
    "href": "http://menugget.blogspot.com/2014/05/evaluating-model-performance-practical.html"
  },
  {
    "title": "littler is faster at doing nothing!",
    "href": "http://dirk.eddelbuettel.com/blog/2014/09/02/"
  },
  {
    "title": "Welcome to Data Science LA!",
    "href": "http://datascience.la/welcome-to-data-science-la/"
  },
  {
    "title": "Paris, June 2014 – Portfolio Design Tutorial",
    "href": "https://www.rmetrics.org/node/173"
  },
  {
    "title": "Getting rasters into shape from R",
    "href": "https://johnbaumgartner.wordpress.com/2012/07/26/getting-rasters-into-shape-from-r/"
  },
  {
    "title": "Visualizing Unemployment in Mexico",
    "href": "https://blog.diegovalle.net/2009/12/visualizing-unemployment-in-mexico.html"
  },
  {
    "title": "Running RStudio via Docker in the Cloud",
    "href": "http://www.magesblog.com/2014/09/running-rstudio-via-docker-in-cloud.html"
  },
  {
    "title": "Hillary 1993: Largest Drop in Girl Names EVER; Chelsea Distant Second",
    "href": "http://www.econometricsbysimulation.com/2016/02/Hillary-Drop.html"
  },
  {
    "title": "2010 March Madness Half Marathon in Cary",
    "href": "http://dirk.eddelbuettel.com/blog/2010/03/21/"
  },
  {
    "title": "Who will win the World Cup and which prediction model?",
    "href": "http://www.magesblog.com/2014/06/who-will-win-world-cup-and-which.html"
  },
  {
    "title": "Couch, apis and all that",
    "href": "https://web.archive.org/web/http://schamberlain.github.io/2013/05/couch/"
  },
  {
    "title": "Sequential Analysis",
    "href": "http://www.win-vector.com/blog/2015/12/sequential-analysis/"
  },
  {
    "title": "Slaying CIDR Orcs with Triebeard (a.k.a. fast trie-based ‘IPv4-in-CIDR’ lookups in R)",
    "href": "http://rud.is/b/2016/07/12/slaying-cidr-orcs-with-triebeard-a-k-a-fast-trie-based-ipv4-in-cidr-lookups-in-r/"
  },
  {
    "title": "Continuous or Discrete Latent Structure? Correspondence Analysis vs. Nonnegative Matrix Factorization",
    "href": "http://joelcadwell.blogspot.com/2014/08/continuous-or-discrete-latent-structure.html"
  },
  {
    "title": "Free Webinar: Intro to SparkR",
    "href": "http://r4stats.com/2015/06/18/sparkr/"
  },
  {
    "title": "Distribution of uptimes for high-performance computing systems",
    "href": "http://shape-of-code.coding-guidelines.com/2012/11/28/distribution-of-uptimes-for-high-performance-computing-systems/"
  },
  {
    "title": "Simplicity Explained by The Author",
    "href": "http://timelyportfolio.blogspot.com/2013/10/brilliance-explained-by-author.html"
  },
  {
    "title": "Just another way to make a R flavored blog",
    "href": "https://web.archive.org/web/http://jkunst.com/blog/category/r/rss/jkunst.com/jkunst.com/r/just-another-way-to-make-a-r-flavored-blog/"
  },
  {
    "title": "Mumbai, Nov 2011, IGIDR – Financial Market Studies by Stress and Stability metrics",
    "href": "https://www.rmetrics.org/mumbai2011Nov"
  },
  {
    "title": "Webinar Recap: Shapefiles for R Programmers",
    "href": "http://www.arilamstein.com/blog/2016/05/09/webinar-recap-shapefiles-r-programmers/"
  },
  {
    "title": "R 2.13.2 released",
    "href": "http://blog.revolutionanalytics.com/2011/09/r-2132-released.html"
  },
  {
    "title": "Crayon colors in R",
    "href": "https://kbroman.wordpress.com/2014/05/07/crayon-colors-in-r/"
  },
  {
    "title": "First step on GIS with R",
    "href": "https://tomizonor.wordpress.com/2016/01/17/first-step-gis/"
  },
  {
    "title": "Bring Your Data to Life with googleVis and R – Tutorial",
    "href": "https://www.datacamp.com/community/blog/bring-your-data-to-life-with-googlevis-and-r-tutorial"
  },
  {
    "title": "Assertive R programming in dplyr/magrittr pipelines",
    "href": "http://www.onthelambda.com/2015/01/23/assertive-r-programming-in-dplyrmagrittr-pipelines/"
  },
  {
    "title": "An R function to analyze your Google Scholar Citations page",
    "href": "http://simplystatistics.tumblr.com/post/13203811645/an-r-function-to-analyze-your-google-scholar"
  },
  {
    "title": "Kalman filter example visualised with R",
    "href": "http://www.magesblog.com/2015/01/kalman-filter-example-visualised-with-r.html"
  },
  {
    "title": "Bayesian Mixer on Meetup",
    "href": "http://www.magesblog.com/2016/02/bayesian-mixer-on-meetup.html"
  },
  {
    "title": "A first go at ‘manipulate’ in RStudio",
    "href": "http://chrisladroue.com/2011/08/a-first-go-at-manipulate-in-rstudio/"
  },
  {
    "title": "When did “How I Met Your Mother” become less legen.. wait for it…",
    "href": "https://rforwork.info/2013/10/21/when-did-how-i-met-your-mother-become-less-legen-wait-for-it/"
  },
  {
    "title": "Julia and SQLite",
    "href": "https://statcompute.wordpress.com/2014/02/08/julia-and-sqlite/"
  },
  {
    "title": "Computing Maritime Routes in R",
    "href": "http://freigeist.devmag.net/economics/683-computing-maritime-routes-in-r.html"
  },
  {
    "title": "A Hammer Trading System — Demonstrating Custom Indicator-Based Limit Orders in Quantstrat",
    "href": "https://quantstrattrader.wordpress.com/2014/08/18/a-hammer-trading-system-demonstrating-custom-indicator-based-limit-orders-in-quantstrat/"
  },
  {
    "title": "R 3.0.0 is released! (what’s new, and how to upgrade)",
    "href": "https://www.r-statistics.com/2013/04/r-3-0-0-is-released-whats-new-and-how-to-upgrade/"
  },
  {
    "title": "Intro to Text Analysis with R",
    "href": "https://www.r-bloggers.com/intro-to-text-analysis-with-r/"
  },
  {
    "title": "Using MonetDB[Lite] with real-world CSV files",
    "href": "http://rud.is/b/2015/11/11/using-monetdblite-with-real-world-csv-files/"
  }
]
