[
  {
    "title": "A Way To Model Execution On Individual Legs Of A Spread In Quantstrat",
    "href": "https://quantstrattrader.wordpress.com/2014/12/23/a-way-to-model-execution-on-individual-legs-of-a-spread-in-quantstrat/"
  },
  {
    "title": "Wetbulb Temperature",
    "href": "https://stevemosher.wordpress.com/2010/11/08/wetbulb-temperature/"
  },
  {
    "title": "The Power to … What did you say?",
    "href": "http://www.theusrus.de/blog/the-power-to-what-did-you-say/"
  },
  {
    "title": "rxDTree(): a new type of tree algorithm for big data",
    "href": "http://blog.revolutionanalytics.com/2013/07/rxdtree-a-new-type-of-tree-algorithm.html"
  },
  {
    "title": "R tips: Installing Rmpi on Fedora Linux",
    "href": "http://www.cybaea.net/Blogs/Data/R-tips-Installing-Rmpi-on-Fedora-Linux.html"
  },
  {
    "title": "Trends in the Analytics Job Market",
    "href": "http://r4stats.com/2013/08/07/trends-in-the-analytics-job-market/"
  },
  {
    "title": "R-Function to Read Data from Google Docs Spreadsheets",
    "href": "http://thebiobucket.blogspot.com/2012/03/r-function-to-read-data-from-google.html"
  },
  {
    "title": "CDK Literature #8",
    "href": "http://chem-bla-ics.blogspot.com/2015/07/cdk-literature-8.html"
  },
  {
    "title": "Riemann, Langevin & Hamilton [reply]",
    "href": "https://xianblog.wordpress.com/2010/09/27/riemann-langevin-hamilton-reply/"
  },
  {
    "title": "Fast-track publishing using knitr: intro (part I)",
    "href": "http://gforge.se/2013/12/fast-track-publishing-using-knitr-part-i/"
  },
  {
    "title": "Quick-R Gets a Blog",
    "href": "https://statmethods.wordpress.com/2011/11/21/quick-r-gets-a-blog/"
  },
  {
    "title": "iPhone geo-tracking database",
    "href": "https://web.archive.org/web/http://jackman.stanford.edu/blog/?p=2025"
  },
  {
    "title": "Predict Bounce Rate based on Page Load Time in Google Analytics",
    "href": "http://www.tatvic.com/blog/predict-bounce-rate-based-on-page-load-time-in-google-analytics/"
  },
  {
    "title": "On Nested Models",
    "href": "http://www.win-vector.com/blog/2016/04/on-nested-models/"
  },
  {
    "title": "At Least Tim Thomas Won…….",
    "href": "http://www.brocktibert.com/blog/2011/06/22/at-least-tim-thomas-won/"
  },
  {
    "title": "Improving Monitor statistics with the \"UECLs\"",
    "href": "http://nir-quimiometria.blogspot.com/2012/06/improving-monitor-statistics-with-uecls.html"
  },
  {
    "title": "R, Stan and Bayesian Statistics",
    "href": "http://blog.revolutionanalytics.com/2016/06/r-stan-bayesian-stats.html"
  },
  {
    "title": "Rentrez 1.0 released",
    "href": "http://ropensci.org/blog/2015/09/24/rentrez-1_0-release/"
  },
  {
    "title": "Binomial confidence intervals: exact vs. approximate",
    "href": "https://heuristically.wordpress.com/2013/10/30/binomial-confidence-intervals-exact-vs-approximate/"
  },
  {
    "title": "Gaussian Processes with RStan",
    "href": "http://www.jameskeirstead.ca/blog/gaussian-processes-with-rstan/"
  },
  {
    "title": "tolower() – error catching unmappable characters",
    "href": "https://web.archive.org/web/http://minimalr.com/2013/01/06/tolower-error-catching-unmappable-characters/?utm_source=rss&utm_medium=rss&utm_campaign=tolower-error-catching-unmappable-characters"
  },
  {
    "title": "Connecting to a DB2 database from R",
    "href": "https://theaverageinvestor.wordpress.com/2010/01/16/connecting-to-a-db2-database-from-r-2/"
  },
  {
    "title": "Wind in Netherlands II",
    "href": "http://wiekvoet.blogspot.com/2015/11/wind-in-netherlands-ii.html"
  },
  {
    "title": "Scraping table from any web page with R or CloudStat",
    "href": "https://web.archive.org/web/http://pr.cloudst.at/post/15903712245"
  },
  {
    "title": "R and PostgreSQL – using RPostgreSQL and sqldf",
    "href": "https://web.archive.org/web/http://analytikdat.cz/index.php/entry/r-and-postgresql-using-rpostgresql-and-sqldf"
  },
  {
    "title": "Sync Your Rprofile Across Multiple R Installations",
    "href": "http://www.gettinggeneticsdone.com/2011/08/sync-your-rprofile-across-multiple-r.html"
  },
  {
    "title": "embed images in Rd documents",
    "href": "http://romainfrancois.blog.free.fr/index.php?post/2010/04/03/embed-images-in-Rd-documents"
  },
  {
    "title": "New banxicoR package",
    "href": "http://enelmargen.org/banxicoR/vignette-v09/"
  },
  {
    "title": "Building Scalable Data Pipelines with Microsoft R Server and Azure Data Factory",
    "href": "http://blog.revolutionanalytics.com/2016/10/r-server-data-factory.html"
  },
  {
    "title": "Upload plots as PNG file to your wordpress",
    "href": "http://www.networkx.nl/programming/upload-plots-png-wordpress/"
  },
  {
    "title": "Using miniCRAN on site in Iran",
    "href": "https://www.r-bloggers.com/using-minicran-on-site-in-iran/"
  },
  {
    "title": "R 2.14.1 is released",
    "href": "https://www.r-bloggers.com/r-2-14-1-is-released-2/"
  },
  {
    "title": "R: Eliminating observed values with zero variance",
    "href": "http://www.cybaea.net/Blogs/Data/R-Eliminating-observed-values-with-zero-variance.html"
  },
  {
    "title": "R combined gps-track plot of spatial intensity",
    "href": "https://geolabs.wordpress.com/2011/08/30/r-combined-gps-track-plot-of-spatial-intensity/"
  },
  {
    "title": "CrimeMap, LondonR and a Book Review",
    "href": "http://blenditbayes.blogspot.com/2014/01/crimemap-londonr-and-book-review.html"
  },
  {
    "title": "Launching iButton Thermochrons with the help of R",
    "href": "http://lukemiller.org/index.php/2012/03/launching-ibutton-thermochrons-with-the-help-of-r/"
  },
  {
    "title": "Rolling Sharpe Ratios",
    "href": "https://quantstrattrader.wordpress.com/2015/03/20/rolling-sharpe-ratios/"
  },
  {
    "title": "Shiny 0.11, themes, and dashboard",
    "href": "https://blog.rstudio.org/2015/01/23/shiny-0-11-themes-and-dashboard/"
  },
  {
    "title": "The importance of being unoriginal (and befriending google)",
    "href": "http://helmingstay.blogspot.com/2011/06/importance-of-being-unoriginal-and.html"
  },
  {
    "title": "Mean Value from Grouped Data",
    "href": "http://statistical-research.com/mean-value-from-grouped-data/?utm_source=rss&utm_medium=rss&utm_campaign=mean-value-from-grouped-data"
  },
  {
    "title": "Spatial segregation in cities – An explanation by a neural network model (Demographics & neural network)",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/TTD60JfvJ_s/"
  },
  {
    "title": "Faster calculation",
    "href": "http://wiekvoet.blogspot.com/2013/06/faster-calculation.html"
  },
  {
    "title": "Bio7 R Documentation and  Plot Examples",
    "href": "http://bio7.org/?p=2353"
  },
  {
    "title": "Making Your Code Citable",
    "href": "http://computationalproteomic.blogspot.com/2014/08/making-your-code-citable.html"
  },
  {
    "title": "Two Presentations about Joint Models",
    "href": "http://iprogn.blogspot.com/2015/08/two-presentations-about-joint-models.html"
  },
  {
    "title": "Sketches Around Twitter Followers",
    "href": "https://blog.ouseful.info/2013/02/19/sketches-around-twitter-followers/"
  },
  {
    "title": "Announcing Revolution R Enterprise 6.2",
    "href": "http://blog.revolutionanalytics.com/2013/04/rre62-now-available.html"
  },
  {
    "title": "Two courses in R programming by Ken Rice and Thomas Lumley",
    "href": "https://www.r-bloggers.com/two-courses-in-r-programming-by-ken-rice-and-thomas-lumley/"
  },
  {
    "title": "R Training at Nicholls State University",
    "href": "http://r4stats.com/2016/06/06/nicholls-state/"
  },
  {
    "title": "BLAS, BLASter, BLAStest: Some benchmark results, and a benchmarking framework",
    "href": "http://dirk.eddelbuettel.com/blog/2010/09/15/"
  }
]
