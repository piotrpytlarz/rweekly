[
  {
    "title": "Shoutout for Atlassian",
    "href": "http://www.econinfo.de/2014/01/25/shoutout-for-atlassian/"
  },
  {
    "title": "Ensemble Methods, part 1",
    "href": "http://r-datameister.blogspot.com/2013/11/ensemble-methods-part-1.html"
  },
  {
    "title": "ShareLaTeX now supports knitr",
    "href": "http://www.rexamine.com/2014/01/sharelatex-now-supports-knitr/"
  },
  {
    "title": "How to peg 7 cores with doSMP",
    "href": "http://blog.revolutionanalytics.com/2010/06/pegging-7-cores-with-dosmp.html"
  },
  {
    "title": "Geomorph Version 2.0 Now Available!",
    "href": "http://ww1.geomorph.net/2014/04/geomorph-version-20-now-available.html"
  },
  {
    "title": "The Team Data Science Process",
    "href": "http://blog.revolutionanalytics.com/2016/10/the-team-data-science-process.html"
  },
  {
    "title": "Building Affine Transformation Fractals With R",
    "href": "https://aschinchon.wordpress.com/2014/01/05/building-affine-transformation-fractals-with-r/"
  },
  {
    "title": "Again with variability of long-short decile tests",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/uJ6qkrdrvS4/"
  },
  {
    "title": "Average Annual Population Growth Rate of Tawi-Tawi",
    "href": "http://alstatr.blogspot.com/2012/05/average-annual-population-growth-rate.html"
  },
  {
    "title": "Sharing R code in a workgroup of Mac/Windows/Linux users",
    "href": "https://web.archive.org/web/http://derekyves.github.io/blog//blog/r/2016/05/10/Sharing_R_code_in_a_group.html"
  },
  {
    "title": "Heaviside Signal Detection Part 1: Informed non-parametric testing",
    "href": "https://geokook.wordpress.com/2012/07/25/heaviside-signal-detection-part-1-informed-non-parametric-testing/"
  },
  {
    "title": "Analysis of Iran absentee votes",
    "href": "http://mlt-thinks.blogspot.com/2009/06/analysis-of-iran-absentee-votes.html"
  },
  {
    "title": "Day #38-39 Data-manipulation",
    "href": "https://web.archive.org/web/http://flyordie.sin.khk.be/2011/05/08/day-38-data-manipulation/"
  },
  {
    "title": "Tell Forbes how you use R",
    "href": "http://blog.revolutionanalytics.com/2010/11/tell-forbes-how-you-use-r.html"
  },
  {
    "title": "Forget talk like a pirate… Code like a pirate!",
    "href": "http://blog.revolutionanalytics.com/2013/09/forget-talk-like-a-pirate-code-like-a-pirate.html"
  },
  {
    "title": "Floating table of contents for your html reports using knitr",
    "href": "http://stevepowell.blot.im/floating-table-of-contents-for-your-html-reports-using-knitr/"
  },
  {
    "title": "Auto-completion in Notepad++ for R Script",
    "href": "http://yihui.name/en/2010/08/auto-completion-in-notepad-for-r-script/"
  },
  {
    "title": "Daily casualties in Syria",
    "href": "https://statisfaction.wordpress.com/2012/02/09/daily-casualties-in-syria/"
  },
  {
    "title": "Building Packages at Scale",
    "href": "https://www.joyent.com/blog/building-packages-at-scale"
  },
  {
    "title": "user2013: The caret tutorial",
    "href": "https://4dpiecharts.com/2013/07/09/user2013-the-caret-tutorial/"
  },
  {
    "title": "R Workshop: Reading in Large Data Frames",
    "href": "http://simplystatistics.tumblr.com/post/11142408176/r-workshop-reading-in-large-data-frames"
  },
  {
    "title": "Video: SimpleR tricks and tools: Help, debugging, git, LaTeX, and workflow with R by Prof Rob Hyndman",
    "href": "https://feedproxy.google.com/~r/RUserGroups/~3/Z636gMYQa7Y/"
  },
  {
    "title": "Software Carpentry at UVA, Redux",
    "href": "http://www.gettinggeneticsdone.com/2014/03/software-carpentry-at-uva-redux.html"
  },
  {
    "title": "The R-Podcast Episode 7: Best Practices for Workflow Management",
    "href": "http://www.r-podcast.org/the-r-podcast-episode-7-best-practices-for-workflow-management/?utm_source=rss&utm_medium=rss&utm_campaign=the-r-podcast-episode-7-best-practices-for-workflow-management"
  },
  {
    "title": "Rforecastio – Simple R Package To Access forecast.io Weather Data",
    "href": "http://rud.is/b/2013/09/08/rforecastio-simple-r-package-to-access-forecast-io-weather-data/"
  },
  {
    "title": "represtools is on CRAN",
    "href": "https://web.archive.org/web/http://pirategrunt.com/PirateGrunt.com/r/2016/06/21/ReprestoolsOnCran/"
  },
  {
    "title": "How to Conditionally Remove Character of a Vector Element in R",
    "href": "http://hack-r.com/how-to-conditionally-remove-character-of-a-vector-element-in-r/"
  },
  {
    "title": "Open to Non-Conference Attendees – R Workshops at EARL 2016",
    "href": "http://www.mango-solutions.com/wp/2016/06/open-to-non-conference-attendees-r-workshops-at-earl-2016/"
  },
  {
    "title": "Package Version Increment Pre- and Post-commit Hooks",
    "href": "http://rmflight.github.io/posts/2014/02/incrementalVersionCommitHooks.html"
  },
  {
    "title": "Sentiment Analysis of Uganda Presidential Debate – Using R and Twitter data",
    "href": "http://datascience-africa.org/2016/02/sentiment-analysis-of-uganda-presidential-debate-using-r-and-twitter-data/"
  },
  {
    "title": "Practical Implementation of Neural Network based time series (stock) prediction  -PART 5",
    "href": "http://intelligenttradingtech.blogspot.com/2010/02/practical-implementation-of-neual.html"
  },
  {
    "title": "MCMSki IV, Jan. 6-8, 2014, Chamonix (news #4)",
    "href": "https://xianblog.wordpress.com/2013/03/10/mcmski-iv-jan-6-8-2014-chamonix-news-4/"
  },
  {
    "title": "Example 7.40: Nelson-Aalen plotting",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/AbWsyaHiR-s/example-740-nelson-aalen-plotting.html"
  },
  {
    "title": "Waterfall plots – what and how?",
    "href": "https://designdatadecisions.wordpress.com/2015/07/23/waterfall-plots-what-and-how/"
  },
  {
    "title": "Runoff in Uruguay: FA is expected to win a third mandate",
    "href": "http://ww1.danielmarcelino.com/runoff-in-uruguay-fa-is-expected-to-win-a-third-mandate/"
  },
  {
    "title": "Using the pipe operator in R with Plotly",
    "href": "http://moderndata.plot.ly/using-the-pipe-operator-in-r-with-plotly/"
  },
  {
    "title": "Introducing rleafmap. An R package for interactive maps with Leaflet.",
    "href": "http://www.pieceofk.fr/?p=304"
  },
  {
    "title": "Basic documentation for soilDB package (R) now available",
    "href": "https://casoilresource.lawr.ucdavis.edu/"
  },
  {
    "title": "Eight Advantages of Python Over Matlab",
    "href": "http://moderndata.plot.ly/eight-advantages-of-python-over-matlab/"
  },
  {
    "title": "Are career motivations changing?",
    "href": "https://feedproxy.google.com/~r/blogspot/rKuKM/~3/uZ1DKmJFKIA/are-career-motivations-changing.html"
  },
  {
    "title": "EmEditor R code macro – Almost interactive R development for Emeditor",
    "href": "http://datadebrief.blogspot.com/2011/01/emeditor-r-code-macro-almost.html"
  },
  {
    "title": "Pricing interest rate swaps with lambda.r",
    "href": "https://cartesianfaith.com/2013/07/19/pricing-interest-rate-swaps-with-lambda-r/"
  },
  {
    "title": "vectorplot in rasterVis",
    "href": "https://procomun.wordpress.com/2011/10/02/vectorplot-in-rastervis/"
  },
  {
    "title": "Russian elections",
    "href": "http://wiekvoet.blogspot.com/2012/03/russian-elections.html"
  },
  {
    "title": "Animated Images of Arctic Sea Ice Extent Decline",
    "href": "https://web.archive.org/web/https://chartsgraphs.wordpress.com/2012/09/05/animated-images-of-arctic-sea-ice-extent-decline/"
  },
  {
    "title": "GWAS Manhattan plots and QQ plots using ggplot2 in R",
    "href": "http://www.gettinggeneticsdone.com/2010/01/gwas-manhattan-plots-and-qq-plots-using.html"
  },
  {
    "title": "Bootstrap and cross-validation for evaluating modelling strategies",
    "href": "http://ellisp.github.io/blog/2016/06/05/bootstrap-cv-strategies"
  },
  {
    "title": "A Rough Guide to Data Science",
    "href": "https://blog.pivotal.io/pivotal/p-o-v/a-rough-guide-to-data-science?utm_source=rss&utm_medium=rss&utm_campaign=a-rough-guide-to-data-science"
  },
  {
    "title": "New Zealand Data & APIs on GitHub",
    "href": "http://ellisp.github.io/blog/2015/08/01/new-zealand-data-on-github"
  },
  {
    "title": "STAN trailer [PG+53]",
    "href": "https://xianblog.wordpress.com/2015/08/14/stan-trailer-pg53/"
  }
]
