[
  {
    "title": "Going Bananas With Hilbert",
    "href": "https://aschinchon.wordpress.com/2016/02/01/going-bananas-with-hilbert/"
  },
  {
    "title": "Real Pirate Attacks, Charted with R",
    "href": "http://blog.revolutionanalytics.com/2013/09/real-pirate-attacks-charted-with-r.html"
  },
  {
    "title": "Veterinary Epidemiologic Research: Count and Rate Data – Poisson Regression and Risk Ratios",
    "href": "https://denishaine.wordpress.com/2013/05/10/veterinary-epidemiologic-research-count-and-rate-data-poisson-regression-and-risk-ratios/"
  },
  {
    "title": "Sector Rotation Back Test Shiny web application",
    "href": "https://systematicinvestor.wordpress.com/2013/02/18/sector-rotation-back-test-shiny-web-application/"
  },
  {
    "title": "Forecasting weekly data",
    "href": "http://robjhyndman.com/hyndsight/forecasting-weekly-data/"
  },
  {
    "title": "First post, and its a doozy!",
    "href": "https://landeco2point0.wordpress.com/2013/09/07/first-post-and-its-a-doozy/"
  },
  {
    "title": "Using closures as objects in R",
    "href": "http://www.win-vector.com/blog/2015/03/using-closures-as-objects-in-r/"
  },
  {
    "title": "Numerical analysis for statisticians",
    "href": "https://xianblog.wordpress.com/2011/08/26/numerical-analysis-for-statisticians/"
  },
  {
    "title": "Gallery of Images from Boston EARL Conference",
    "href": "http://www.mango-solutions.com/wp/2015/09/gallery-of-images-from-boston-earl-conference/"
  },
  {
    "title": "Natural language processing: What would Shakespeare say?",
    "href": "https://gigadom.wordpress.com/2015/10/02/natural-language-processing-what-would-shakespeare-say/"
  },
  {
    "title": "The Big Analytics Revolution starts with R",
    "href": "http://blog.revolutionanalytics.com/2011/06/the-big-analytics-revolution-starts-with-r.html"
  },
  {
    "title": "merge with solaR",
    "href": "https://web.archive.org/web/https://procomun.wordpress.com/2011/03/25/merge-with-solar/"
  },
  {
    "title": "analyze the social security administration public use microdata files (ssapumf) with r",
    "href": "http://www.asdfree.com/2013/05/analyze-social-security-administration.html"
  },
  {
    "title": "Entering the field as a data scientist with certification",
    "href": "http://blog.revolutionanalytics.com/2014/08/entering-the-field-as-a-data-scientist-with-certification.html"
  },
  {
    "title": "Because it’s Friday: The 4th Amendment X-ray T-shirt",
    "href": "http://blog.revolutionanalytics.com/2010/12/because-its-friday-the-4th-amendment-x-ray-t-shirt.html"
  },
  {
    "title": "GARCH estimation using maximum likelihood",
    "href": "http://programming-r-pro-bro.blogspot.com/2012/02/garch-estimation-using-maximum.html"
  },
  {
    "title": "Clarifying difference between Ratio and Interval Scale of Measurement",
    "href": "http://sumanmathmedicine.blogspot.com/2014/08/clarifying-difference-between-ratio-and.html"
  },
  {
    "title": "Fixing Up smoothScatter Heat Maps",
    "href": "http://princeofslides.blogspot.com/2011/02/fixing-up-smoothscatter-heat-maps.html"
  },
  {
    "title": "The Unavoidable Instability of Brand Image",
    "href": "http://joelcadwell.blogspot.com/2014/06/the-unavoidable-instability-of-brand.html"
  },
  {
    "title": "Celebrating one year of blogging with a word cloud",
    "href": "https://designdatadecisions.wordpress.com/2015/11/20/celebrating-one-year-of-blogging-with-a-word-cloud/"
  },
  {
    "title": "Revisiting package dependencies",
    "href": "http://blog.revolutionanalytics.com/2014/07/revisiting-package-dependencies.html"
  },
  {
    "title": "simulation, an ubiquitous tool",
    "href": "https://xianblog.wordpress.com/2012/07/10/simulation-an-ubiquitous-tool/"
  },
  {
    "title": "Looking to the PCA scores with GGobi",
    "href": "http://nir-quimiometria.blogspot.com/2012/10/looking-to-pca-scores-with-ggobi.html"
  },
  {
    "title": "yorkr ranks T20 batsmen and bowlers",
    "href": "https://gigadom.wordpress.com/2016/04/26/yorkr-ranks-t20-batsmen-and-bowlers/"
  },
  {
    "title": "Extracting data from Salesforce",
    "href": "http://rmnppt.com/2015/12/07/SalesForce-DataGrab.html"
  },
  {
    "title": "Use foursquare to locate a twitter user using R",
    "href": "http://blog.corynissen.com/2013/04/ive-been-doing-some-work-with-twitter.html"
  },
  {
    "title": "Multiplicative effects in sensory panel data",
    "href": "http://wiekvoet.blogspot.com/2012/05/multiplicative-effects-in-sensory-panel.html"
  },
  {
    "title": "Introduction to R and Biostatistics (2012 version): presentation",
    "href": "https://feedproxy.google.com/~r/FellgernonBit-rstats/~3/IBeArrjLvrE/introduction-to-r-and-biostatistics-2012-version"
  },
  {
    "title": "Elder Research Two Day Course",
    "href": "http://www.r-chart.com/2010/09/elder-research-two-day-course.html"
  },
  {
    "title": "RStudio Keyboard Shortcut Reference PDF",
    "href": "http://www.gettinggeneticsdone.com/2011/03/rstudio-keyboard-shortcut-reference-pdf.html"
  },
  {
    "title": "ggplot Tutorial",
    "href": "https://feedproxy.google.com/~r/FellgernonBit-rstats/~3/ARBJDxgHwlo/ggplot-tutorial"
  },
  {
    "title": "Statistical Analysis and Visualization of the Drug War in Mexico",
    "href": "https://blog.diegovalle.net/2010/06/statistical-analysis-and-visualization.html"
  },
  {
    "title": "Introducing R on video",
    "href": "https://xianblog.wordpress.com/2010/03/10/introducing-r-on-video/"
  },
  {
    "title": "Grabbing Tables in Webpages Using the XML Package",
    "href": "http://yihui.name/en/2010/10/grabbing-tables-in-webpages-using-the-xml-package/"
  },
  {
    "title": "A Simple Shiny App for Monitoring Trading Strategies – Part II",
    "href": "http://www.thertrader.com/2014/08/07/a-simple-shiny-app-for-monitoring-trading-strategies-part-ii/"
  },
  {
    "title": "useR! 2016 Tutorials: Part 2",
    "href": "http://blog.revolutionanalytics.com/2016/07/user-2016-tutorials-part-2-.html"
  },
  {
    "title": "New Shiny App for Exploring Census Tract Demographics",
    "href": "http://www.arilamstein.com/blog/2015/06/18/new-app-for-exploring-census-tract-demographics/"
  },
  {
    "title": "forecast package v4.0",
    "href": "http://robjhyndman.com/hyndsight/forecast4/"
  },
  {
    "title": "HOWTO: X11 Forwarding for Oracle R Enterprise",
    "href": "https://blogs.oracle.com/R/entry/howto_x11_forwarding_with_r"
  },
  {
    "title": "Compute longest increasing/decreasing subsequence using Rcpp",
    "href": "http://www.mango-solutions.com/wp/2014/09/compute-longest-increasingdecreasing-subsequence-using-rcpp/"
  },
  {
    "title": "Yet another R package primer",
    "href": "https://kbroman.wordpress.com/2014/08/28/yet-another-r-package-primer/"
  },
  {
    "title": "Plotting Likert-Scales (net stacked distributions) with ggplot #rstats",
    "href": "https://strengejacke.wordpress.com/2013/07/17/plotting-likert-scales-net-stacked-distributions-with-ggplot-rstats/"
  },
  {
    "title": "3D Maps in R",
    "href": "http://r-nold.blogspot.com/2012/06/talking-about-elevation-one-can-also.html"
  },
  {
    "title": "Why the 2012 US elections are more exciting than 2008",
    "href": "http://beautifuldata.net/2012/11/why-the-2012-elections-are-exciting/"
  },
  {
    "title": "TTR_0.2 on CRAN",
    "href": "https://feedproxy.google.com/~r/FossTrading/~3/5gY-DN2vpg4/ttr02-on-cran.html"
  },
  {
    "title": "Mindoro Digital Elevation Map",
    "href": "http://r-nold.blogspot.com/2012/06/mindoro-digital-elevation-map.html"
  },
  {
    "title": "Inheriting in Items",
    "href": "http://www.backsidesmack.com/2011/06/no-steal-this-blog/"
  },
  {
    "title": "elliplot 1.1.1 package is now available at CRAN",
    "href": "https://tomizonor.wordpress.com/2013/10/12/elliplot-1-1-1/"
  },
  {
    "title": "Changing world, Changing JGB term structure",
    "href": "http://mockquant.blogspot.com/2011/11/changing-this-world-changing-jgb-term.html"
  },
  {
    "title": "Heating costs",
    "href": "http://factbased.blogspot.com/2011/12/heating-costs.html"
  }
]
