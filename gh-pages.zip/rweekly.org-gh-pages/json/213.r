[
  {
    "title": "Summarising multivariate palaeoenvironmental data",
    "href": "http://www.fromthebottomoftheheap.net/2014/01/09/pcurve-part-2/"
  },
  {
    "title": "PCA for NIR Spectra_part 002: \"Score planes\"",
    "href": "http://nir-quimiometria.blogspot.com/2012/02/pca-for-nir-spectrapart-002-score.html"
  },
  {
    "title": "R Plotting tips",
    "href": "http://evolvingspaces.blogspot.com/2010/07/r-plotting-tips.html"
  },
  {
    "title": "Vertical Histogram",
    "href": "http://uu-kk.blogspot.com/2014/02/vertical-histogram.html"
  },
  {
    "title": "Introducing the nominatim geocoding package",
    "href": "http://rud.is/b/2015/07/29/introducing-the-nominatim-geocoding-package/"
  },
  {
    "title": "R again in Google Summer of Code",
    "href": "http://industrialengineertools.blogspot.com/2011/03/r-again-in-google-summer-of-code.html"
  },
  {
    "title": "Presenting influence.ME at useR!",
    "href": "http://www.rensenieuwenhuis.nl/presenting-influence-me-at-user/"
  },
  {
    "title": "Trying a prefmap",
    "href": "http://wiekvoet.blogspot.com/2014/09/trying-prefmap.html"
  },
  {
    "title": "Let it snow!",
    "href": "http://www.statisticsblog.com/2012/12/let-it-snow/"
  },
  {
    "title": "Adding CITATION to your R package",
    "href": "http://computationalproteomic.blogspot.com/2014/08/making-your-r-package-citable.html"
  },
  {
    "title": "How the expiration of the assault weapon ban affected Mexico",
    "href": "https://blog.diegovalle.net/2010/09/how-expiration-of-assault-weapon-ban.html"
  },
  {
    "title": "Spreadsheet Errors (discussed in The Economist)",
    "href": "http://davegiles.blogspot.com/2016/09/spreadsheet-errors.html"
  },
  {
    "title": "What data science software tools do you use?",
    "href": "http://blog.revolutionanalytics.com/2015/05/what-data-science-software-tools-do-you-use.html"
  },
  {
    "title": "Comrades Marathon: A Race for Geriatrics?",
    "href": "http://www.exegetic.biz/blog/2014/07/comrades-marathon-a-race-for-geriatrics/?utm_source=rss&utm_medium=rss&utm_campaign=comrades-marathon-a-race-for-geriatrics"
  },
  {
    "title": "Forecast Update: Will 2014 be the Beginning of the End for SAS and SPSS?",
    "href": "http://r4stats.com/2013/05/14/beginning-of-the-end-v2/"
  },
  {
    "title": "trying to speed up Metropolis… and failing!",
    "href": "https://xianblog.wordpress.com/2014/06/13/trying-to-speed-up-metropolis-and-failing/"
  },
  {
    "title": "What value is cross country GDP correlation? [Part One]",
    "href": "http://www.backsidesmack.com/2011/05/what-value-is-cross-country-gdp-correlation-part-one/"
  },
  {
    "title": "Lotka-Volterra model ~ intro",
    "href": "https://probabilitynotes.wordpress.com/2010/03/30/lotka-volterra-model-intro/"
  },
  {
    "title": "Generate Quasi-Poisson Distribution Variable",
    "href": "https://web.archive.org/web/http://tianhuidong.github.com/blog/2012/06/04/generate-quasi-poisson-distribution-variable/"
  },
  {
    "title": "Mapping Australian electoral divisions with ggplot2",
    "href": "https://stronginstruments.com/2013/08/18/mapping-australian-electoral-divisions-with-ggplot2/"
  },
  {
    "title": "GBLUP example in R",
    "href": "http://ggorjan.blogspot.com/2012/03/gblup-example-in-r.html"
  },
  {
    "title": "The Elements of Statistical Learning",
    "href": "https://feedproxy.google.com/~r/OneRTipADay/~3/_YAB9RPjm2M/elements-of-statistical-learning.html"
  },
  {
    "title": "The guts of a statistical factor model",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/iJpEA-koHXk/"
  },
  {
    "title": "Urbanisation Continues – Modeling Regional Apartment Prices in Finland",
    "href": "http://ouzor.github.io/blog/2016/03/08/apartment-price-model.html"
  },
  {
    "title": "Identifying pathways for managing multiple disturbances to limit plant invasions",
    "href": "http://andrewgelman.com/2014/06/05/identifying-pathways-managing-multiple-disturbances-limit-plant-invasions/"
  },
  {
    "title": "Fair weather fans, redux",
    "href": "http://bayesball.blogspot.com/2013/09/fair-weather-fans-redux.html"
  },
  {
    "title": "Partial least squares path analysis",
    "href": "http://andrewgelman.com/2013/02/09/partial-least-squares-path-analysis/"
  },
  {
    "title": "rNOMADS 2.0.1 released",
    "href": "https://bovineaerospace.wordpress.com/2014/07/05/rnomads-2-0-1-released/"
  },
  {
    "title": "Revolution R Enterprise 4.3 now available",
    "href": "http://blog.revolutionanalytics.com/2011/04/revolution-r-enterprise-43-now-available.html"
  },
  {
    "title": "sjPlot 1.3 available #rstats #sjPlot",
    "href": "https://strengejacke.wordpress.com/2014/03/27/sjplot-1-3-available-rstats-sjplot/"
  },
  {
    "title": "Shiny and Leaflet for Visualization Awards",
    "href": "https://biologyforfun.wordpress.com/2016/09/04/shiny-and-leaflet-for-visualization-awards/"
  },
  {
    "title": "Creating a scale transformation",
    "href": "http://ellisp.github.io/blog/2015/09/05/creating-a-scale-transformation"
  },
  {
    "title": "There is no “Too Big” Data, is there?",
    "href": "http://freakonometrics.hypotheses.org/13946"
  },
  {
    "title": "Machine Learning Ex3 – multivariate linear regression",
    "href": "https://web.archive.org/web/http://al3xandr3.github.io/2011/03/08/ml-ex3.html"
  },
  {
    "title": "packed off!!!",
    "href": "https://xianblog.wordpress.com/2013/02/09/packed-off/"
  },
  {
    "title": "Machine Learning Ex3 – Multivariate Linear Regression",
    "href": "https://web.archive.org/web/http://ygc.name/2011/03/29/machine-learning-ex3-multivariate-linear-regression/"
  },
  {
    "title": "Package Update Roundup: Dec 2009 – Jan 2010",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2010/02/package-update-roundup-dec-2009-jan-2010.html"
  },
  {
    "title": "plyr, ggplot2 and triathlon results, part II",
    "href": "https://feedproxy.google.com/~r/ChristopheLadroueR/~3/_uF6rE7Klnc/"
  },
  {
    "title": "Happy Thanksgiving!",
    "href": "http://blog.revolutionanalytics.com/2015/11/happy-thanksgiving.html"
  },
  {
    "title": "Aquamacs 2.2 and ESS",
    "href": "https://web.archive.org/web/http://www.stanford.edu/~knoepfle/cgi-bin/flatpress/?x=entry:entry110325-181624"
  },
  {
    "title": "Jonathan Rougier – Nomograms for visualising relationships between three variables (useR! 2011)",
    "href": "https://csgillespie.wordpress.com/2011/08/16/jonathan-rougier-nomograms-for-visualising-relationships-between-three-variables/"
  },
  {
    "title": "Harvesting more Canadian climate data",
    "href": "http://www.fromthebottomoftheheap.net/2016/05/24/harvesting-more-canadian-climate-data/"
  },
  {
    "title": "What Countries are ‘Pulling their Weight’ for Haiti?",
    "href": "http://drewconway.com/zia/?p=1826"
  },
  {
    "title": "Teaching Assistant with R expertise needed in Toronto",
    "href": "http://ekonometrics.blogspot.com/2011/12/teaching-assistant-with-r-expertise.html"
  },
  {
    "title": "Plotting GTFS data with R",
    "href": "https://web.archive.org/web/http://jkunst.com/blog/category/r/rss/jkunst.com/jkunst.com/r/plotting-gtfs-data-with-r/"
  },
  {
    "title": "Improved Moving Average Code is available for download!",
    "href": "http://www.quantf.com/fotis-papailias/improved-moving-average-code-is-available-for-download/332"
  },
  {
    "title": "CHANCE: special issue on George Casella’s books",
    "href": "https://xianblog.wordpress.com/2013/02/10/chance-special-issue-on-george-casellas-books/"
  },
  {
    "title": "Animated plots in R and LaTeX",
    "href": "http://robjhyndman.com/hyndsight/animations/?utm_source=rss&utm_medium=rss&utm_campaign=animations"
  },
  {
    "title": "Coxcomb plots and ‘spiecharts’ in R",
    "href": "http://robinlovelace.net//r/2013/12/27/coxcomb-plots-spiecharts-R.html"
  },
  {
    "title": "Fantastic presentations from R using slidify and rCharts",
    "href": "http://www.datacommunitydc.org/blog/2013/08/fantastic-presentations-from-r-using-slidify-and-rcharts/?utm_source=rss&utm_medium=rss&utm_campaign=fantastic-presentations-from-r-using-slidify-and-rcharts"
  }
]
