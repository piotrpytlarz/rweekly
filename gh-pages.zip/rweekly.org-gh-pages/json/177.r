[
  {
    "title": "Small Area Estimation 101: old materials posted",
    "href": "http://civilstat.com/2015/04/small-area-estimation-101-old-materials-posted/"
  },
  {
    "title": "Cricket All Round Performances",
    "href": "http://www.wekaleamstudios.co.uk/posts/cricket-all-round-performances/"
  },
  {
    "title": "useR 2012: my materials",
    "href": "http://civilstat.com/2012/06/user-2012-my-materials/"
  },
  {
    "title": "A New Use for Pipes in R: Forkbombs",
    "href": "http://librestats.com/2014/08/06/a-new-use-for-pipes-in-r-forkbombs/"
  },
  {
    "title": "In case you missed it: May Roundup",
    "href": "http://blog.revolutionanalytics.com/2011/06/in-case-you-missed-it-may-roundup.html"
  },
  {
    "title": "R Function Binding Vectors and Matrices of Variable Length, bug fixed",
    "href": "http://freigeist.devmag.net/r/576-r-function-binding-vectors-and-matrices-of-variable-length.html"
  },
  {
    "title": "Tracking US Sentiments Over Time In Wikileaks",
    "href": "http://viksalgorithms.blogspot.com/2012/06/tracking-us-sentiments-over-time-in.html"
  },
  {
    "title": "N armed bandit simulation",
    "href": "http://random-miner.blogspot.com/2013/08/n-armed-bandit-simulation.html"
  },
  {
    "title": "Designing real-world 3-D objects with R",
    "href": "http://blog.revolutionanalytics.com/2012/10/3-d-objects-with-r.html"
  },
  {
    "title": "Going viral with R’s igraph package",
    "href": "http://blog.ryanwalker.us/2014/03/going-viral-with-rs-igraph-package.html"
  },
  {
    "title": "Visualisation of Likert scale results",
    "href": "http://rcrastinate.blogspot.com/2016/07/visualisation-of-likert-scale-results.html"
  },
  {
    "title": "Mixed model R2 (UPDATED)",
    "href": "https://aghaynes.wordpress.com/2013/03/28/mixed-model-r2/"
  },
  {
    "title": "R at the Consumer Financial Protection Bureau",
    "href": "http://blog.revolutionanalytics.com/2012/04/r-at-the-consumer-financial-protection-bureau.html"
  },
  {
    "title": "Creating a zoomable map of tweets with R",
    "href": "http://randomthoughtsonr.blogspot.com/2013/06/creating-zoomable-map-of-tweets-with-r.html"
  },
  {
    "title": "Is Online AD Space a Commodity?",
    "href": "http://flovv.github.io/Ad-Commodity/"
  },
  {
    "title": "Men set to live as long as women by 2010?",
    "href": "http://freakonometrics.hypotheses.org/16165"
  },
  {
    "title": "Ten Things the Emacs Social Science Starter Kit gives you",
    "href": "https://kieranhealy.org/blog/archives/2013/02/25/ten-things-the-emacs-social-science-starter-kit-gives-you/"
  },
  {
    "title": "Newest release of BCEA",
    "href": "https://gianlubaio.blogspot.com/2013/12/newest-release-of-bcea.html"
  },
  {
    "title": "The R-Files: Hadley Wickham",
    "href": "http://blog.revolutionanalytics.com/2010/09/the-r-files-hadley-wickham.html"
  },
  {
    "title": "R and the SGeMS blockdata format",
    "href": "http://rogiersbart.blogspot.com/2012/12/r-and-sgems-blockdata-format.html"
  },
  {
    "title": "The Clipboard can be Your Friend",
    "href": "https://web.archive.org/web/https://brocktibert.wordpress.com/2011/01/17/the-clipboard-can-be-your-friend/"
  },
  {
    "title": "Create polygons from a matrix",
    "href": "http://menugget.blogspot.com/2012/04/create-polygons-from-matrix.html"
  },
  {
    "title": "New Online Tool for Seasonal Adjustment",
    "href": "https://usefulr.wordpress.com/2015/03/20/new-online-tool-for-seasonal-adjustment/"
  },
  {
    "title": "Quandl Package – 5,000,000 free datasets at the tip of your fingers!",
    "href": "http://www.econometricsbysimulation.com/2013/05/quandl-package-5000000-free-datasets-at.html"
  },
  {
    "title": "dbetabinom versions",
    "href": "https://xianblog.wordpress.com/2013/02/18/dbetabinom-versions/"
  },
  {
    "title": "Autocorrelation functions of materially different time series",
    "href": "http://ellisp.github.io/blog/2015/09/19/timeseries-same-acf"
  },
  {
    "title": "REvolution Computing is now Revolution Analytics",
    "href": "http://blog.revolutionanalytics.com/2010/05/revolution-computing-is-now-revolution-analytics.html"
  },
  {
    "title": "Mapping Traffic Fatalities",
    "href": "http://lucaspuente.github.io/notes/2016/09/01/Mapping_Traffic_Fatalities"
  },
  {
    "title": "Web Scraping and “invalid multibyte string”",
    "href": "http://www.exegetic.biz/blog/2016/08/web-scraping-invalid-multibyte-string/"
  },
  {
    "title": "T-Shirts … designed with R!",
    "href": "http://decisionsandr.blogspot.com/2014/05/t-shirts-designed-with-r.html"
  },
  {
    "title": "Guns are Cool – States",
    "href": "http://wiekvoet.blogspot.com/2014/07/guns-are-cool-states.html"
  },
  {
    "title": "RSiteCatalyst Version 1.4.4 Release Notes",
    "href": "http://randyzwitch.com/rsitecatalyst-version-1-4-4-release-notes/"
  },
  {
    "title": "PerformanceAnalytics update released to CRAN",
    "href": "https://tradeblotter.wordpress.com/2014/09/16/performanceanalytics-update-released-to-cran/"
  },
  {
    "title": "Peter Norvig’s Spell Checker in Two Lines of Base R",
    "href": "http://www.sumsar.net/blog/2014/12/peter-norvigs-spell-checker-in-two-lines-of-r/"
  },
  {
    "title": "Introduction to R: free basic R course on DataCamp in italian",
    "href": "http://www.milanor.net/blog/introduction-r-free-basic-r-course-datacamp-italian/"
  },
  {
    "title": "A 3D Version of R’s curve() Function",
    "href": "http://www.johnmyleswhite.com/notebook/2011/03/21/a-3d-version-of-rs-curve-function/"
  },
  {
    "title": "A new Q&A website for Data-Analysis (based on StackOverFlow engine) – is waiting for you",
    "href": "https://www.r-statistics.com/2010/06/a-new-qa-website-for-data-analysis-based-on-stackoverflow-engine-is-waiting-for-you/"
  },
  {
    "title": "Revolution Analytics CTO on Big Data analytics platforms",
    "href": "http://blog.revolutionanalytics.com/2013/12/revolution-analytics-cto-on-big-data-analytics-platforms-.html"
  },
  {
    "title": "BBBT Podcast with David Smith",
    "href": "http://blog.revolutionanalytics.com/2012/01/bbbt-podcast-with-david-smith.html"
  },
  {
    "title": "R Structure Explained",
    "href": "http://davenportspatialanalytics.squarespace.com/blog/2012/4/5/r-structure-explained.html"
  },
  {
    "title": "An exercise in non-linear modeling",
    "href": "http://gforge.se/2014/09/an-exercise-in-non-linear-modeling/"
  },
  {
    "title": "Fear and Loathing in Data Science 2013-06-11 20:25:00",
    "href": "http://r-datameister.blogspot.com/2013/06/visual-exploration-of-time-series.html"
  },
  {
    "title": "The R-Podcast is Now on iTunes",
    "href": "http://www.r-podcast.org/the-r-podcast-is-now-on-itunes/"
  },
  {
    "title": "CRdata vs. Cloudnumbers",
    "href": "https://r-ecology.blogspot.com/2011/07/crdata-vs-cloudnumbers.html"
  },
  {
    "title": "Portfolio Cycle Charts",
    "href": "https://www.rmetrics.org/blog/PortfolioCycles"
  },
  {
    "title": "R GIS: Polygon Intersection with gIntersection{rgeos}",
    "href": "http://thebiobucket.blogspot.com/2013/09/r-gis-polygon-intersection-with.html"
  },
  {
    "title": "52 Vis Week #2 Wrap Up",
    "href": "http://rud.is/b/2016/04/13/52-vis-week-2-wrap-up/"
  },
  {
    "title": "R: Annotate the panels in a multi-panel lattice plot in 1 line",
    "href": "http://hack-r.com/r-annotate-the-panels-in-a-multi-panel-lattice-plot-in-1-line/"
  },
  {
    "title": "The Road to Default: Whaa???",
    "href": "http://dancingeconomist.blogspot.com/2011/07/road-to-default-whaa.html"
  },
  {
    "title": "Forecasts with ARIMA Models",
    "href": "http://freakonometrics.hypotheses.org/48264"
  }
]
