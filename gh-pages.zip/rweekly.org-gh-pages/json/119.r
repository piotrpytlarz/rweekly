[
  {
    "title": "Changing the Light Azimuth in Shaded Relief Representation by Clustering Aspect",
    "href": "http://r-video-tutorial.blogspot.com/2014/09/changing-light-azimuth-in-shaded-relief.html"
  },
  {
    "title": "Simulation: Efficiency of mean with median\r\n\r\nGoal: Show the…",
    "href": "https://web.archive.org/web/http://pr.cloudst.at/post/12163618595"
  },
  {
    "title": "Insight from FIFA 14’s Player Attributes (Using R)",
    "href": "http://suehpro.blogspot.com/2013/12/insight-from-fifa-14s-player-attributes.html"
  },
  {
    "title": "Building an R package (under Windows) without C, C++ or FORTRAN code",
    "href": "https://danganothererror.wordpress.com/2010/07/23/building-an-r-package-under-windows-without-c-c-or-fortran-code/"
  },
  {
    "title": "Wind Resource Assessment",
    "href": "http://r-video-tutorial.blogspot.com/2015/12/wind-resource-assessment.html"
  },
  {
    "title": "Dates and Times – Simple and Easy with lubridate Exercises (part 3)",
    "href": "http://r-exercises.com/2016/10/04/dates-and-times-simple-and-easy-with-lubridate-exercises-part-3/"
  },
  {
    "title": "Project Euler — problem 13",
    "href": "https://web.archive.org/web/http://ec2-184-73-106-109.compute-1.amazonaws.com/wordpress/?p=213"
  },
  {
    "title": "In case you missed it: July 2012 Roundup",
    "href": "http://blog.revolutionanalytics.com/2012/08/in-case-you-missed-it-july-2012-roundup.html"
  },
  {
    "title": "R Development Master Class with Hadley Wickham",
    "href": "http://blog.revolutionanalytics.com/2011/11/r-development-master-class-with-hadley-wickham.html"
  },
  {
    "title": "Exploring Mangalyaan tweets with R",
    "href": "https://notesofdabbler.wordpress.com/2014/09/27/exploring-mangalyaan-tweets-with-r/"
  },
  {
    "title": "Twotorials",
    "href": "https://aghaynes.wordpress.com/2012/06/12/twotorials/"
  },
  {
    "title": "A technique for doing parametrized unit testing in R: Case study with stock price data analysis",
    "href": "http://memosisland.blogspot.com/2013/09/a-technique-for-doing-parametrized-unit.html"
  },
  {
    "title": "Open soure software has changed the way we do business",
    "href": "http://blog.revolutionanalytics.com/2015/05/open-soure-software-has-changed-the-way-we-do-business.html"
  },
  {
    "title": "Calculating a Gini Coefficients for a Number of Locales at Once in R",
    "href": "http://blog.mollietaylor.com/2013/01/calculating-gini-coefficients-for.html"
  },
  {
    "title": "Old Post with New d3 Life–GARCH and MA Performance",
    "href": "http://timelyportfolio.blogspot.com/2013/05/old-post-with-new-d3-lifegarch-and-ma.html"
  },
  {
    "title": "Where are the Fat Tails?",
    "href": "http://timelyportfolio.blogspot.com/2012/06/where-are-fat-tails.html"
  },
  {
    "title": "RProtoBuf 0.3.0",
    "href": "http://dirk.eddelbuettel.com/blog/2013/07/15/"
  },
  {
    "title": "Generalised Linear Models in R",
    "href": "http://www.magesblog.com/2015/08/generalised-linear-models-in-r.html"
  },
  {
    "title": "Mastering R plot – Part 3: Outer margins",
    "href": "http://datascienceplus.com/mastering-r-plot-part-3-outer-margins/"
  },
  {
    "title": "Functional and Parallel time series cross-validation",
    "href": "https://feedproxy.google.com/~r/ModernToolMaking/~3/tA55YStURrM/functional-and-parallel-time-series.html"
  },
  {
    "title": "CHCN: Canadian Historical Climate Network",
    "href": "https://stevemosher.wordpress.com/2011/08/05/chcn-canadian-historical-climate-network/"
  },
  {
    "title": "Passing user-supplied C++ functions",
    "href": "http://gallery.rcpp.org/articles/passing-cpp-function-pointers/"
  },
  {
    "title": "Query your Google Analytics Data with the GAR package",
    "href": "http://www.analyticsforfun.com/2015/10/query-your-google-analytics-data-with.html"
  },
  {
    "title": "Time zones",
    "href": "http://pitfalls-r-us.blogspot.com/2012/07/time-zones.html"
  },
  {
    "title": "Steps toward recreating The Facebook IPO plot",
    "href": "http://nycdatascience.com/steps-toward-recreating-the-facebook-ipo-plot/"
  },
  {
    "title": "Different goals, different looks:  Infovis and the Chris Rock effect",
    "href": "http://andrewgelman.com/2011/07/05/different_goals/"
  },
  {
    "title": "How to use Bioconductor to find empirical evidence in support of π being a normal number",
    "href": "http://simplystatistics.org/2014/03/14/using-bioconductor-to-find-some-empirical-evidence-in-support-of-%CF%80-being-a-normal-number/"
  },
  {
    "title": "Mapping out Marriott’s Starwood Acquisition",
    "href": "http://blog.revolutionanalytics.com/2015/11/marriott.html"
  },
  {
    "title": "European Migration",
    "href": "http://wiekvoet.blogspot.com/2013/01/european-migration.html"
  },
  {
    "title": "a Simpson paradox of sorts",
    "href": "https://xianblog.wordpress.com/2016/05/06/a-simpson-paradox-of-sorts/"
  },
  {
    "title": "R and Salesforce",
    "href": "https://arungaikwad.wordpress.com/2012/02/25/r-and-salesforce/"
  },
  {
    "title": "Deploy Rook Apps: Part II",
    "href": "http://jeffreyhorner.tumblr.com/post/33814488298/deploy-rook-apps-part-ii"
  },
  {
    "title": "Zurich, March 9, 2011 – Rmetrics Presentation at ZurichR User Group",
    "href": "https://www.rmetrics.org/node/84"
  },
  {
    "title": "Craig Bellamy – quite dplyr",
    "href": "http://www.premiersoccerstats.com/wordpress/?p=1461"
  },
  {
    "title": "Sustainable Futures conference in Manchester",
    "href": "https://procomun.wordpress.com/2011/05/02/sustainable-futures-conference-in-manchester/"
  },
  {
    "title": "NYC Meetup: What’s Next for R Markdown",
    "href": "https://blog.rstudio.org/2012/05/24/nyc-meetup-r-markdown/"
  },
  {
    "title": "7 new R jobs (and dozens of Resumes) from around the world (2016-03-09)",
    "href": "https://www.r-users.com/jobs/data-scientist-machine-learning-3/"
  },
  {
    "title": "Bio7 at the useR! Conference 2015",
    "href": "http://bio7.org/?p=2572"
  },
  {
    "title": "Install R 2.15 and further versions in Debian Squeeze",
    "href": "http://tata-box-blog.blogspot.com/2012/04/install-r-215-and-further-versions-in.html"
  },
  {
    "title": "Next Kölner R User Meeting: Friday, 23 May 2014",
    "href": "http://www.magesblog.com/2014/05/next-kolner-r-user-meeting-friday-23.html"
  },
  {
    "title": "R & GGMap Visualization Case Study",
    "href": "https://www.r-bloggers.com/r-ggmap-visualization-case-study/"
  },
  {
    "title": "Higher Order Functions Exercises",
    "href": "http://r-exercises.com/2016/08/05/higher-order-functions-exercises/"
  },
  {
    "title": "R tip: Maximum screen width",
    "href": "http://www.compbiome.com/2010/04/r-tip-maximum-screen-width.html"
  },
  {
    "title": "seasonal 1.3: A Better Way to Seasonal Adjustment Diagnostics",
    "href": "https://usefulr.wordpress.com/2016/08/07/seasonal-1-3-a-better-way-to-seasonal-adjustment-diagnostics/"
  },
  {
    "title": "How to Shade Under a Normal Density in R",
    "href": "https://feedproxy.google.com/~r/CoffeeAndEconometricsInTheMorning/~3/wmKyYFRrgIo/how-to-shade-under-normal-density-in-r.html"
  },
  {
    "title": "Animating neural networks from the nnet package",
    "href": "https://beckmw.wordpress.com/2013/03/19/animating-neural-networks-from-the-nnet-package/"
  },
  {
    "title": "Using R to visualize geo optimization algorithms",
    "href": "http://bizcoding.blogspot.com/2013/05/using-r-to-visualize-geo-optimization.html"
  },
  {
    "title": "Separating Statistical Models of \"What Is Learned\" from \"How It Is Learned\"",
    "href": "http://joelcadwell.blogspot.com/2014/06/separating-statistical-models-of-what.html"
  },
  {
    "title": "stringdist 0.9: exercise all your cores",
    "href": "http://www.markvanderloo.eu/yaRb/2015/01/24/stringdist-0-9-exercise-all-your-cores/"
  },
  {
    "title": "On the growth of CRAN packages",
    "href": "http://blog.revolutionanalytics.com/2016/04/cran-package-growth.html"
  }
]
