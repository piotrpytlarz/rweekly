[
  {
    "title": "James Bond movies",
    "href": "http://opiateforthemass.es/articles/james-bond-film-ratings/"
  },
  {
    "title": "I Fought the (distribution) Law (and the Law did not win)",
    "href": "http://freakonometrics.hypotheses.org/19576"
  },
  {
    "title": "Ross Ihaka on the history of the R project",
    "href": "http://blog.revolutionanalytics.com/2016/06/ross-ihaka-on-the-history-of-the-r-project.html"
  },
  {
    "title": "Stochastic Oscillator",
    "href": "https://systematicinvestor.wordpress.com/2013/07/19/stochastic-oscillator/"
  },
  {
    "title": "ggtree in Bioconductor 3.1",
    "href": "https://web.archive.org/web/http://ygc.name/2015/01/19/ggtree-in-bioconductor-3-1/"
  },
  {
    "title": "rgraph6 on R-Forge",
    "href": "https://brokeringclosure.wordpress.com/2008/09/04/rgraph6-on-r-forge/"
  },
  {
    "title": "R Quickie: Custom Panel Functions and Default Arguments",
    "href": "https://casoilresource.lawr.ucdavis.edu/"
  },
  {
    "title": "useR! 2007 – Ames here I come!",
    "href": "https://web.archive.org/web/http://pineda-krch.com/2007/07/07/user-2007-ames-here-i-come/"
  },
  {
    "title": "Reverse Geocode using Google API and XML package in R – PART 2",
    "href": "http://datavisualizationineconomics.blogspot.com/2015/11/reverse-geocode-using-google-api-and.html"
  },
  {
    "title": "Taking R to the Limit: Large Datasets; Predictive modeling with PMML and ADAPA",
    "href": "https://feedproxy.google.com/~r/RUserGroups/~3/rvgy2713Op0/"
  },
  {
    "title": "Plotting Watts-Strogatz model",
    "href": "http://rsnippets.blogspot.com/2012/09/plotting-watts-strogatz-model.html"
  },
  {
    "title": "Design patterns for action buttons",
    "href": "https://blog.rstudio.org/2015/04/07/design-patterns-for-action-buttons/"
  },
  {
    "title": "Survival Analysis With Generalized Additive Models: Part V (stratified baseline hazards)",
    "href": "https://statmd.wordpress.com/2015/05/09/survival-analysis-with-generalized-additive-models-part-v-stratified-baseline-hazards/"
  },
  {
    "title": "visNetwork, Currencies,  and Minimum Spanning Trees",
    "href": "http://timelyportfolio.blogspot.com/2015/05/visnetwork-currencies-and-minimum.html"
  },
  {
    "title": "RHIPE in the SD Times",
    "href": "http://blog.revolutionanalytics.com/2010/10/rhipe-in-the-sd-times.html"
  },
  {
    "title": "ESSA2013 Conference",
    "href": "http://rsnippets.blogspot.com/2012/11/essa2013-conference.html"
  },
  {
    "title": "Streaming Hadoop Data Into R Scripts",
    "href": "http://perfdynamics.blogspot.com/2009/03/streaming-hadoop-data-into-r-scripts.html"
  },
  {
    "title": "Collapsing a bipartite co-occurrence network",
    "href": "http://f.briatte.org/r/collapsing-a-bipartite-co-occurrence-network"
  },
  {
    "title": "A Monty Simulation",
    "href": "http://statistical-research.com/a-monty-simulation/?utm_source=rss&utm_medium=rss&utm_campaign=a-monty-simulation"
  },
  {
    "title": "Visually Comparing Return Distributions",
    "href": "https://tradeblotter.wordpress.com/2013/01/18/visually-comparing-return-distributions/"
  },
  {
    "title": "colormap",
    "href": "http://dankelley.github.io//r/2014/04/30/colormap.html"
  },
  {
    "title": "Manhattanly: R package for Interactive Manhattan Plots",
    "href": "http://moderndata.plot.ly/manhattanly-r-package-for-interactive-manhattan-plots/"
  },
  {
    "title": "Building a Simple Web App using R",
    "href": "https://nerdsrule.co/2012/11/14/building-a-simple-web-app-using-r/"
  },
  {
    "title": "Simple visualization of a 11X5 table (for WordPress 2.9 Features Vote Results)",
    "href": "https://www.r-statistics.com/2009/07/simple-visualization-of-a-11x5-table-for-wordpress-2-9-features-vote-results/"
  },
  {
    "title": "Nest Thermostat and R – Creating a Shiny dashboard",
    "href": "http://blagrants.blogspot.com/2015/09/nest-thermostat-and-r-creating-shiny.html"
  },
  {
    "title": "apply lapply rapply sapply functions in R",
    "href": "http://www.dataperspective.info/2016/03/apply-lapply-rapply-sapply-functions-r.html"
  },
  {
    "title": "Package Update Roundup: Nov 2009",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2009/12/package-update-roundup-nov-2009.html"
  },
  {
    "title": "UseR! 2013 website at user2013.org",
    "href": "https://www.opencpu.org/"
  },
  {
    "title": "Day #19 RGG’s a b***h",
    "href": "https://web.archive.org/web/http://flyordie.sin.khk.be/2011/04/08/day-19-rgg-s-a-btch/"
  },
  {
    "title": "More fun with %.% and %>%",
    "href": "https://martinsbioblogg.wordpress.com/2014/03/27/more-fun-with-and/"
  },
  {
    "title": "Curious about big data in Montreal?",
    "href": "http://ekonometrics.blogspot.com/2015/10/curious-about-big-data-in-montreal.html"
  },
  {
    "title": "Missing data, logistic regression, and a predicted values plot (or two)",
    "href": "http://learningrbasic.blogspot.com/2009/07/missing-data-logistic-regression-and.html"
  },
  {
    "title": "In case you missed it: July Roundup",
    "href": "http://blog.revolutionanalytics.com/2011/08/in-case-you-missed-it-july-roundup.html"
  },
  {
    "title": "Approximate sunrise and sunset times",
    "href": "http://quantitative-ecology.blogspot.com/2007/10/approximate-sunrise-and-sunset-times.html"
  },
  {
    "title": "Doing away with “unknown timezone” warnings",
    "href": "https://rappster.wordpress.com/2011/11/08/doing-away-with-unknown-timezone-warnings/"
  },
  {
    "title": "Simple visually-weighted regression plots",
    "href": "http://is-r.tumblr.com/post/32193893263/simple-visually-weighted-regression-plots"
  },
  {
    "title": "Plotting GPX tracks with Shiny and Leaflet",
    "href": "http://rcrastinate.blogspot.com/2016/08/plotting-gpx-tracks-with-shiny-and.html"
  },
  {
    "title": "(String/text processing)++: stringi 0.2-3 released",
    "href": "http://www.rexamine.com/2014/05/stringi-0-2-3-released/"
  },
  {
    "title": "The ‘Deutsche Bahn’ (German Railway Corp.) is always late!!1! Or is it? And if, why?",
    "href": "http://rcrastinate.blogspot.com/2013/11/the-deutsche-bahn-german-railway-corp.html"
  },
  {
    "title": "A New Method for Statistical Disclosure Limitation, I",
    "href": "https://matloff.wordpress.com/2015/10/15/a-new-method-for-statistical-disclosure-limitation-i/"
  },
  {
    "title": "R User Conference in Spain: Call for Tutorials",
    "href": "http://blog.revolutionanalytics.com/2012/11/r-user-conference-in-spain-call-for-tutorials.html"
  },
  {
    "title": "Leveraging R for Job Openings for Economists",
    "href": "http://freigeist.devmag.net/r/910-leveraging-r-for-job-openings-for-economists.html"
  },
  {
    "title": "XYZ geographic data interpolation, part 2",
    "href": "http://menugget.blogspot.com/2012/02/having-recently-received-comment-on.html"
  },
  {
    "title": "Sudoku via simulated annealing",
    "href": "https://xianblog.wordpress.com/2010/02/23/sudoku-via-simulated-annealing/"
  },
  {
    "title": "DE solution in R (nonlinear oscillator)",
    "href": "http://dankelley.github.io/r/2014/06/15/nonlinear-oscillator.html"
  },
  {
    "title": "speed of R, C, &tc.",
    "href": "https://xianblog.wordpress.com/2012/02/03/speed-of-r-c-tc/"
  },
  {
    "title": "Confidence Intervals for Random Forests",
    "href": "http://blog.revolutionanalytics.com/2016/03/confidence-intervals-for-random-forest.html"
  },
  {
    "title": "NYC Motor Vehicle Collisions – Street-Level Heat Map",
    "href": "https://stablemarkets.wordpress.com/2015/03/10/nyc-motor-vehicle-collisions-street-level-heat-map/"
  },
  {
    "title": "How to detect heteroscedasticity and rectify it?",
    "href": "http://datascienceplus.com/how-to-detect-heteroscedasticity-and-rectify-it/"
  },
  {
    "title": "An Animation of the t Distribution as a Mixture of Normals",
    "href": "http://www.sumsar.net/blog/2013/12/t-as-a-mixture-of-normals/"
  }
]
