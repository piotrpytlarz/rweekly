[
  {
    "title": "What makes a hockey Hall-of-Famer?",
    "href": "http://blog.revolutionanalytics.com/2011/08/what-makes-a-hockey-hall-of-famer.html"
  },
  {
    "title": "Count different positions between two strings of equal length",
    "href": "https://fabiomarroni.wordpress.com/2011/11/26/count-different-positions-between-two-strings-of-equal-length/"
  },
  {
    "title": "Integrating R with Apache Hadoop",
    "href": "http://datascienceplus.com/integrating-r-with-apache-hadoop/"
  },
  {
    "title": "Rook shipped to CRAN",
    "href": "http://jeffreyhorner.tumblr.com/post/4634093934/rook-shipped-to-cran"
  },
  {
    "title": "True Significance of a T Statistic",
    "href": "http://statistical-research.com/true-significance-of-a-t-statistic/?utm_source=rss&utm_medium=rss&utm_campaign=true-significance-of-a-t-statistic"
  },
  {
    "title": "Creating Reproducible Software Environments with Packrat",
    "href": "http://bconnelly.net/2014/07/creating-reproducible-software-environments-with-packrat/"
  },
  {
    "title": "More republican debate analysis with R",
    "href": "http://enelmargen.org/datascience/r-debate-analysis-part-ii/"
  },
  {
    "title": "Frank Harrell to teach Regression Modeling Strategies short course",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2010/02/frank-harrell-to-teach-regression-modeling-strategies-short-course.html"
  },
  {
    "title": "Last day – online R courses at Udemy – for $15 only",
    "href": "https://www.udemy.com/courses/?pmtag=UDEMYQ330&utm_source=growth-affiliate&utm_medium=linkshare&utm_term=&utm_content=textlink&utm_campaign=_._pn__._ci__._ex_Y_._&siteID=eO5bByfCCNo-YiNnv82Nzex7qqOi72lhkg&LSNPUBID=eO5bByfCCNo"
  },
  {
    "title": "Force R help HTML server to always use the same URL port",
    "href": "http://www.jottr.org/2012/10/force-r-help-html-server-to-always-use.html"
  },
  {
    "title": "Variables can synergize, even in a linear model",
    "href": "http://www.win-vector.com/blog/2016/09/variables-can-synergize-even-in-a-linear-model/"
  },
  {
    "title": "Using planel.groups in lattice",
    "href": "http://www.magesblog.com/2013/09/using-planelgroups-in-lattice.html"
  },
  {
    "title": "Setting up StatET & Eclipse in Windows",
    "href": "http://gforge.se/2012/05/setting-up-statet-eclipse-in-windows/"
  },
  {
    "title": "Smaller or greater? – episode II",
    "href": "https://web.archive.org/web/https://infominer.wordpress.com/2011/05/20/smaller-or-greater-%E2%80%93-episode-ii/"
  },
  {
    "title": "c2d4u and RRutter Ubuntu PPA Updates",
    "href": "http://www.personal.psu.edu/mar36/blogs/the_ubuntu_r_blog/2014/03/c2d4u-and-rrutter-ubuntu-ppa-updates.html"
  },
  {
    "title": "3D plotting exercises",
    "href": "http://r-exercises.com/2016/04/06/3d-plotting-exercises/"
  },
  {
    "title": "Plotting Maps with R",
    "href": "https://web.archive.org/web/http://playingwithr.blogspot.com/2011/04/plotting-maps-with-r.html"
  },
  {
    "title": "Custom Amazon EC2 config for Rstudio",
    "href": "http://helmingstay.blogspot.com/2012/02/adduser-myusername-adduser-myusername.html"
  },
  {
    "title": "Canterbury Earthquakes part II",
    "href": "http://the-praise-of-insects.blogspot.com/2010/09/canterbury-earthquakes-part-ii.html"
  },
  {
    "title": "Annotations for “R For Dummies”",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/42-wcPBAt1Q/"
  },
  {
    "title": "Real-time Reporting with the Adobe Analytics API",
    "href": "http://randyzwitch.com/real-time-reporting-adobe-analytics-api/"
  },
  {
    "title": "A Tale of Two Bugs",
    "href": "http://www.arilamstein.com/blog/2016/04/04/new-version-choroplethr/"
  },
  {
    "title": "A Future for R: Slides from useR 2016",
    "href": "http://www.jottr.org/2016/07/a-future-for-r-slides-from-user-2016.html"
  },
  {
    "title": "Setting Up New R Notebook",
    "href": "http://data-steve.github.io/setting-up-r-notebook/"
  },
  {
    "title": "Importing google news data to R",
    "href": "http://moderntoolmaking.blogspot.com/2011/07/importing-google-news-data-to-r.html"
  },
  {
    "title": "SMART Hackathon: Day 1",
    "href": "https://hopstat.wordpress.com/2014/05/01/smart-hackathon-day-1/"
  },
  {
    "title": "Students in predominantly ethnic minority classes want segregated education very much. The others don’t.",
    "href": "http://stevepowell.blot.im/students-in-predominantly-ethnic-minority-classes-want-segregated-education-very-much-the-others-dont/"
  },
  {
    "title": "Rperform in Google Summer of Code 2016",
    "href": "https://techandmortals.wordpress.com/2016/05/21/rperform-in-google-summer-of-code-2016/"
  },
  {
    "title": "Updates to SoilWeb",
    "href": "https://casoilresource.lawr.ucdavis.edu/"
  },
  {
    "title": "Interactive presentations with deck.js",
    "href": "http://www.magesblog.com/2011/11/interactive-presentations.html"
  },
  {
    "title": "Revolution R Open 8.0.1 now available",
    "href": "http://blog.revolutionanalytics.com/2014/12/rro-801.html"
  },
  {
    "title": "The Statsguys on Data Analytics",
    "href": "http://davegiles.blogspot.com/2014/02/the-statsguys-on-data-analytics.html"
  },
  {
    "title": "I giovani nel mondo del lavoro",
    "href": "http://www.salvaggio.net/publications/R-blog/files/i-giovani-nel-mondo-del-lavoro.php"
  },
  {
    "title": "A complicated answer to a simple correlation question",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/1expLj9bpfY/"
  },
  {
    "title": "Advanced Graphics in R",
    "href": "http://www.bytemining.com/2010/01/advanced-graphics-in-r/"
  },
  {
    "title": "Speeding up R code: A case study",
    "href": "https://web.archive.org/web/http://blog.revolution-computing.com/2010/02/speeding-up-r-code-a-case-study.html"
  },
  {
    "title": "Explore New Zealand’s Tourist Industry with R and Shiny",
    "href": "http://blog.revolutionanalytics.com/2016/02/explore-new-zealands-tourist-industry-with-r-and-shiny.html"
  },
  {
    "title": "Sampling for Monte Carlo simulations with R",
    "href": "http://www.jameskeirstead.ca/r/sampling-for-monte-carlo-simulations-with-r/"
  },
  {
    "title": "10 new R jobs from around the world (2016-01-11)",
    "href": "https://www.r-users.com/jobs/quantitative-r-developer-cyberjaya-selangor-malaysia/"
  },
  {
    "title": "Data Preparation – Part I",
    "href": "http://www.flaviobarros.net/2013/10/31/data-preparation-tricks-part-i/"
  },
  {
    "title": "Calculating VaR with R",
    "href": "http://firsttimeprogrammer.blogspot.com/2014/07/calculating-var-with-r.html"
  },
  {
    "title": "The wonderful world of vim",
    "href": "https://xianblog.wordpress.com/2010/07/20/the-wonderful-world-of-vim/"
  },
  {
    "title": "Imputation by mean?",
    "href": "http://mkao006.blogspot.com/2012/09/imputation-by-mean.html"
  },
  {
    "title": "Product revenue prediction with R – part 2",
    "href": "http://www.tatvic.com/blog/product-revenue-prediction-with-r-part-2/"
  },
  {
    "title": "Another look at over-representation analysis interpretation",
    "href": "http://brainchronicle.blogspot.com/2012/05/another-look-at-over-representation.html"
  },
  {
    "title": "Open VS Closed Analysis Languages",
    "href": "http://rmflight.github.io/posts/2013/10/openvsclosed.html"
  },
  {
    "title": "Makefiles and Sweave",
    "href": "https://csgillespie.wordpress.com/2011/05/12/makefiles-and-sweave/"
  },
  {
    "title": "Because it’s Friday: Spurious correlation edition",
    "href": "https://feedproxy.google.com/~r/ModernToolMaking/~3/oQLFpuOJ1AQ/because-its-friday-spurious-correlation.html"
  },
  {
    "title": "Embedding R-generated Interactive HTML pages in MS PowerPoint",
    "href": "http://www.mango-solutions.com/wp/2015/02/embedding-r-generated-interactive-html-pages-in-ms-powerpoint/"
  },
  {
    "title": "Better modelling and visualisation of newspaper count data",
    "href": "http://blog.rolffredheim.com/2013/02/better-modelling-and-visualisation-of.html"
  }
]
