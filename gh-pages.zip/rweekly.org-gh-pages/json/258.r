[
  {
    "title": "lm System on Nikkei with New Chart",
    "href": "http://timelyportfolio.blogspot.com/2011/08/lm-system-on-nikkei-with-new-chart.html"
  },
  {
    "title": "Musings on Correlation (or yet another reason I fear for those non-methodologically inclined students in my cohort)",
    "href": "https://web.archive.org/web/http://nortalktoowise.com/2011/08/musings-on-correlation/"
  },
  {
    "title": "OKC Thunder:  Too close for comfort?",
    "href": "http://www.moreorlessnumbers.com/2013/12/okc-thunder-too-close-for-comfort.html"
  },
  {
    "title": "Poll Shows Open Source Almost Even with Commercial Analytics Software",
    "href": "http://r4stats.com/2012/05/31/open-source-almost-even/"
  },
  {
    "title": "Processing Punycode and IDNA Domain Names in R",
    "href": "http://datadrivensecurity.info/blog/posts/2015/Jun/processing-punycode-and-idna-domain-names-in-r/"
  },
  {
    "title": "Presenting Immer’s barley data",
    "href": "https://4dpiecharts.com/2010/10/31/presenting-immers-barley-data/"
  },
  {
    "title": "Google Summer of Code 2015",
    "href": "http://blog.fosstrading.com/2015/03/google-summer-of-code-2015.html"
  },
  {
    "title": "My Yahoo talk is now online",
    "href": "http://robjhyndman.com/hyndsight/yahoo2015/"
  },
  {
    "title": "Bayesian Nonparametrics in R",
    "href": "http://www.johnmyleswhite.com/notebook/2012/06/26/bayesian-nonparametrics-in-r/"
  },
  {
    "title": "Sweave Tutorial 3: Console Input and Output – Multiple Choice Test Analysis",
    "href": "http://jeromyanglim.blogspot.com/2010/11/sweave-tutorial-3-console-input-and.html"
  },
  {
    "title": "Statistical modeling and computation [book review]",
    "href": "https://xianblog.wordpress.com/2014/01/22/statistical-modeling-and-computation-book-review/"
  },
  {
    "title": "Find the function you’re looking for in R",
    "href": "http://www.gettinggeneticsdone.com/2009/09/find-function-youre-looking-for-in-r.html"
  },
  {
    "title": "Saptarshi Guha on Hadoop, R",
    "href": "http://blog.revolutionanalytics.com/2010/09/guha-hadoop-r.html"
  },
  {
    "title": "Criticism 5 of NHST: p-Values Measure Effort, Not Truth",
    "href": "http://www.johnmyleswhite.com/notebook/2012/07/17/criticism-5-of-nhst-p-values-measure-effort-not-truth/"
  },
  {
    "title": "Scraping SSL Labs Server Test Results With R",
    "href": "http://datadrivensecurity.info/blog/posts/2014/Apr/scraping-ssl-server-test-results-with-r/"
  },
  {
    "title": "Multidimensional Scaling and Company Similarity",
    "href": "http://petewerner.blogspot.com/2012/07/multidimensional-scaling-and-company.html"
  },
  {
    "title": "What’s the difference between POSIXct and POSIXlt?",
    "href": "http://isomorphism.es/post/36234613804/posixct-posixlt"
  },
  {
    "title": "Joy of Stats coming soon",
    "href": "https://feedproxy.google.com/~r/PortfolioProbeRLanguage/~3/Zp69gh5kM-k/"
  },
  {
    "title": "New Course: Intermediate R Programming Training Course",
    "href": "https://www.datacamp.com/community/blog/intermediate-r-programming"
  },
  {
    "title": "Visualizing your websites’ ecommerce performance with R",
    "href": "http://www.tatvic.com/blog/visualizing-your-websites-ecommerce-performance-with-r/"
  },
  {
    "title": "String manipulations on full names",
    "href": "http://f.briatte.org/r/string-manipulation-on-full-names"
  },
  {
    "title": "UK R Courses – 2012",
    "href": "https://csgillespie.wordpress.com/2011/09/17/uk-r-courses-2012/"
  },
  {
    "title": "Drawing Grids in R",
    "href": "http://thebiobucket.blogspot.com/2011/06/drawing-custom-grids-in-r.html"
  },
  {
    "title": "Scraping XML Tables with R",
    "href": "https://analystatlarge.wordpress.com/2014/05/16/scraping-xml-tables-with-r/"
  },
  {
    "title": "Expressions!",
    "href": "http://www.stat.tamu.edu/site-directory/?q=node%2F52"
  },
  {
    "title": "Split-plot 2: let’s throw in some spatial effects",
    "href": "http://www.quantumforest.com/2012/07/split-plot-2-lets-throw-in-some-spatial-effects/"
  },
  {
    "title": "Sweave.sh plays with weaver",
    "href": "http://ggorjan.blogspot.com/2009/01/sweavesh-plays-with-weaver.html"
  },
  {
    "title": "odfweave setup and counting logicals",
    "href": "http://wiekvoet.blogspot.com/2014/07/odfweave-setup-and-counting-logicals.html"
  },
  {
    "title": "The five element ninjas approach to teaching design matrices",
    "href": "http://mbjoseph.github.io/2016/04/25/model_matrix.html"
  },
  {
    "title": "Unemployment",
    "href": "http://wiekvoet.blogspot.com/2015/02/unemployment.html"
  },
  {
    "title": "Accessing Open Data Portal (India) using APIs",
    "href": "http://justanotherdatablog.blogspot.com/2014/04/accessing-open-data-portal-india-using.html"
  },
  {
    "title": "Google Summer of Code experiences",
    "href": "http://blog.rapporter.net/2013/09/google-summer-of-code-experiences.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+rapporter-r+%28R+stories+by+Rapporter%29"
  },
  {
    "title": "Looking after Datasets",
    "href": "http://blog.revolutionanalytics.com/2015/09/looking-after-datasets.html"
  },
  {
    "title": "The R-Files: Saptarshi Guha",
    "href": "http://blog.revolutionanalytics.com/2010/10/the-r-files-saptarshi-guha.html"
  },
  {
    "title": "Example 9.30: addressing multiple comparisons",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/wgI2a6YEE0s/example-930-addressing-multiple.html"
  },
  {
    "title": "Twifficiency Scores",
    "href": "http://www.johnmyleswhite.com/notebook/2010/08/18/twifficiency-scores/"
  },
  {
    "title": "Book Review: R in a Nutshell",
    "href": "http://lukemiller.org/index.php/2010/12/book-review-r-in-a-nutshell/"
  },
  {
    "title": "Descriptive statistics, causal inference, and story time",
    "href": "http://andrewgelman.com/2011/07/07/descriptive_sta/"
  },
  {
    "title": "The Purchase Funnel Survives the Consumer Decision Journey",
    "href": "http://joelcadwell.blogspot.com/2014/05/the-purchase-funnel-survives-consumer.html"
  },
  {
    "title": "Risk-Opportunity Analysis: Houston",
    "href": "https://feedproxy.google.com/~r/FossTrading/~3/KtnIwdoI5NQ/risk-opportunity-analysis-houston.html"
  },
  {
    "title": "Le Monde puzzle [#939]",
    "href": "https://xianblog.wordpress.com/2015/12/11/le-monde-puzzle-939/"
  },
  {
    "title": "Duck typing with quantmod",
    "href": "https://cartesianfaith.com/2011/02/04/duck-typing-with-quantmod/"
  },
  {
    "title": "Slightly Advanced rvest with Help from htmltools + XML + pipeR",
    "href": "http://timelyportfolio.blogspot.com/2014/11/slightly-advanced-rvest-with-help-from_26.html"
  },
  {
    "title": "Review: Kölner R Meeting 30 March 2012",
    "href": "http://www.magesblog.com/2012/04/review-kolner-r-meeting-30-march-2012.html"
  },
  {
    "title": "Facebook Graph API Explorer with R",
    "href": "https://tonybreyal.wordpress.com/2011/11/10/facebook-graph-api-explorer-with-r/"
  },
  {
    "title": "Using Arial in R figures destined for PLOS ONE",
    "href": "http://www.fromthebottomoftheheap.net/2013/09/09/preparing-figures-for-plos-one-with-r/"
  },
  {
    "title": "The R-Podcast Episode 1: Introduction",
    "href": "http://www.r-podcast.org/the-r-podcast-episode-1-introduction/"
  },
  {
    "title": "Don’t teach built-in plotting to beginners (teach ggplot2)",
    "href": "http://varianceexplained.org/r/teach_ggplot2_to_beginners/"
  },
  {
    "title": "Completion for java objects",
    "href": "http://romainfrancois.blog.free.fr/index.php?post/2009/08/09/Completion-for-java-objects"
  },
  {
    "title": "Exact Complexity of Mergesort, and an R Regression Oddity",
    "href": "http://www.bytemining.com/2010/02/exact-complexity-of-mergesort-and-an-r-regression-oddity/"
  }
]
