[
  {
    "title": "NG Spreads returns, a reliable earner.",
    "href": "http://timelyportfolio.blogspot.com/2011/12/is-drawdown-biggest-determinant-of.html"
  },
  {
    "title": "Accelerating R with multi-node parallelism –  Rmpi, BatchJobs and OpenLava",
    "href": "http://www.teraproc.com/teraproc-blog/accelerating-r-with-multi-node-parallelism-rmpi-batchjobs-and-openlava/"
  },
  {
    "title": "In case you missed it: June 2013 Roundup",
    "href": "http://blog.revolutionanalytics.com/2013/07/in-case-you-missed-it-june-2013-roundup.html"
  },
  {
    "title": "Hortonworks Hadoop, Big Data and Data Science",
    "href": "http://blog.revolutionanalytics.com/2013/09/hortonworks-hadoop-big-data-and-data-science.html"
  },
  {
    "title": "Unrequited lm Love",
    "href": "http://timelyportfolio.blogspot.com/2011/08/unrequited-lm-love.html"
  },
  {
    "title": "Genetic Algorithm Systematic Trading Development — Part 1",
    "href": "http://intelligenttradingtech.blogspot.com/2010/02/genetic-algorithm-systematic-trading.html"
  },
  {
    "title": "d3/R Streamgraph on White House Petition Data",
    "href": "http://data-steve.github.io/d3-r-streamgraph-on-white-house-petition-data/"
  },
  {
    "title": "Tukey and Mosteller’s Bulging Rule (and Ladder of Powers)",
    "href": "http://freakonometrics.hypotheses.org/14967"
  },
  {
    "title": "Zurich, Dec 2013 – Advanced R Training",
    "href": "https://web.archive.org/web/https://www.rmetrics.org/node/146"
  },
  {
    "title": "Trying Julia",
    "href": "http://wiekvoet.blogspot.com/2012/08/trying-julia.html"
  },
  {
    "title": "Weekend art in R (Part 4)",
    "href": "http://www.statisticsblog.com/2010/09/weekend-art-in-r-part-4/"
  },
  {
    "title": "Easy access to data on US politics: New version of pvsR now on BitBucket",
    "href": "http://giventhedata.blogspot.com/2016/07/easy-access-to-data-on-us-politics-new.html"
  },
  {
    "title": "Graphical insights from the 2012 UseR! Meeting",
    "href": "http://exploringdatablog.blogspot.com/2012/07/graphical-insights-from-2012-user.html"
  },
  {
    "title": "R Commander – hypothesis testing",
    "href": "http://www.wekaleamstudios.co.uk/posts/r-commander-hypothesis-testing/"
  },
  {
    "title": "Practical Data Science with R: Manning Deal of the Day November 19th 2013",
    "href": "http://www.win-vector.com/blog/2013/11/practical-data-science-with-r-manning-deal-of-the-day-november-19th-2013/?utm_source=rss&utm_medium=rss&utm_campaign=practical-data-science-with-r-manning-deal-of-the-day-november-19th-2013"
  },
  {
    "title": "R SQL-ish aggregation",
    "href": "https://strugglingthroughproblems.wordpress.com/2010/09/10/r-sql-ish-aggregation/"
  },
  {
    "title": "5 Interesting Free Books for R from beginner to experts",
    "href": "http://www.aphysicistinwallstreet.com/2011/11/free-books-for-r.html"
  },
  {
    "title": "The stats of Australian Rules Football",
    "href": "http://blog.revolutionanalytics.com/2013/08/the-stats-of-australian-rules-football.html"
  },
  {
    "title": "Sensemaking in R: A Plenitude of Models Makes for Good Storytelling",
    "href": "http://joelcadwell.blogspot.com/2015/08/sensemaking-in-r-plenitude-of-models.html"
  },
  {
    "title": "Betting on Pi",
    "href": "http://www.statisticsblog.com/2010/05/betting-on-pi/"
  },
  {
    "title": "R tip: Finding the location of minimum and maximums",
    "href": "http://www.compbiome.com/2010/02/r-tip-finding-location-of-minimum-and.html"
  },
  {
    "title": "Guardian Words: Visualized",
    "href": "http://rud.is/b/2014/03/15/guardian-words-visualized/"
  },
  {
    "title": "tenured research position with ABC skills!",
    "href": "https://xianblog.wordpress.com/2012/02/02/tenured-research-position-with-abc-skills/"
  },
  {
    "title": "Convert IP addresses to geolocation, latitude and longitude etc etc",
    "href": "https://robertgrantstats.wordpress.com/2013/05/29/convert-ip-addresses-to-geolocation-latitude-and-longitude-etc-etc/"
  },
  {
    "title": "Forecasting In R: The Greatest Shortcut That Failed The Ljung-Box",
    "href": "http://dancingeconomist.blogspot.com/2011/08/forecasting-in-r-greatest-shortcut-that.html"
  },
  {
    "title": "Really Big Objects Coming to R",
    "href": "http://simplystatistics.tumblr.com/post/27980822670/really-big-objects-coming-to-r"
  },
  {
    "title": "Web scraping with Python – the dark side of data",
    "href": "http://forgetfulfunctor.blogspot.com/2011/12/web-scraping-with-python-dark-side-of.html"
  },
  {
    "title": "Taking R to the Limit, Part I – Parallelization in R",
    "href": "http://www.bytemining.com/2010/07/taking-r-to-the-limit-part-i-parallelization-in-r/"
  },
  {
    "title": "Plotting Maps in rbokeh",
    "href": "http://ryanhafen.com/blog/rbokeh-gmap"
  },
  {
    "title": "Back to Blogging",
    "href": "http://www.johnmyleswhite.com/notebook/2012/03/31/back-to-blogging/"
  },
  {
    "title": "How to calculate confidence intervals of correlations with R",
    "href": "http://jeromyanglim.blogspot.com/2010/11/how-to-calculate-confidence-intervals.html"
  },
  {
    "title": "Assign n Email Addresses to x Cells, Intrinsically (Part II)",
    "href": "http://suehpro.blogspot.com/2014/03/assign-n-email-addresses-to-x-cells_27.html"
  },
  {
    "title": "A true data-doodler – Christophe Ladroue (R ddly and plyr on Triathlon Results)",
    "href": "http://datadoodlers.blogspot.com/2011/10/true-data-doodler-christophe-ladroue-r.html"
  },
  {
    "title": "R 2.12.0 scheduled for October 15",
    "href": "http://blog.revolutionanalytics.com/2010/09/r-2120-scheduled-for-october-15.html"
  },
  {
    "title": "Covcalc: Shiny App for Calculating Coverage Depth or Read Counts for Sequencing Experiments",
    "href": "http://www.gettinggeneticsdone.com/2016/06/shiny-app-calculate-coverage-readcount-for-sequencing-experiments.html"
  },
  {
    "title": "Get Some Class",
    "href": "http://www.mango-solutions.com/wp/2014/10/get-some-class/"
  },
  {
    "title": "Integrating R with production systems using an HTTP API",
    "href": "http://blog.revolutionanalytics.com/2014/08/using-r-inside-the-enterprise-integration-with-existing-systems.html"
  },
  {
    "title": "Do Torontonians Want a New Casino?  Survey Analysis Part 1",
    "href": "https://rforwork.info/2013/05/02/do-torontonians-want-a-new-casino-survey-analysis-part-1/"
  },
  {
    "title": "What’s New in Release 6.2: Additional ScaleR Features",
    "href": "http://blog.revolutionanalytics.com/2013/04/whats-new-in-release-62-additional-features.html"
  },
  {
    "title": "I had been wondering what impact my friending 200 people from my…",
    "href": "http://tlevine.tumblr.com/post/2607278187/i-had-been-wondering-what-impact-my-friending-200"
  },
  {
    "title": "House Effects in Argentinian polling",
    "href": "https://feedproxy.google.com/~r/danielmarcelino/~3/jNA7zvOi-To/"
  },
  {
    "title": "Collaborative lesson development with GitHub",
    "href": "http://www.gettinggeneticsdone.com/2014/06/collaborative-lesson-development-git-github.html"
  },
  {
    "title": "Visualize NHL Play-by-Play using Tableau Public and R",
    "href": "https://web.archive.org/web/https://brocktibert.wordpress.com/2011/02/13/visualize-nhl-play-by-play-using-tableau-public-and-r/"
  },
  {
    "title": "tcp timelines with ggplot2",
    "href": "https://web.archive.org/web/http://rjpower.org/wordpress/tcp-timelines-with-ggplot2/"
  },
  {
    "title": "Second year of entries!",
    "href": "https://feedproxy.google.com/~r/SASandR/~3/e3l73H2yxJU/second-year-of-entries.html"
  },
  {
    "title": "Rcpp 0.6.6",
    "href": "http://dirk.eddelbuettel.com/blog/2009/08/03/"
  },
  {
    "title": "Violins of Volatility",
    "href": "http://blog.revolutionanalytics.com/2011/03/violins-of-volatility.html"
  },
  {
    "title": "My #ACSPhilly #skolnik2012 slides for “Semantic pipelines to molecular properties”",
    "href": "http://chem-bla-ics.blogspot.com/2012/08/my-acsphilly-skolnik2012-slides-for.html"
  },
  {
    "title": "demodulating time series",
    "href": "http://dankelley.github.io//r/2014/02/17/demodulation.html"
  },
  {
    "title": "Calling R from SAS IML Studio",
    "href": "http://statsadventure.blogspot.com/2012/06/calling-r-from-sas-iml-studio.html"
  }
]
