[
  {
    "title": "Long-vector kludge in R",
    "href": "http://digitheadslabnotebook.blogspot.com/2012/07/long-vector-kludge-in-r.html"
  },
  {
    "title": "Stata embraces Bayesian statistics",
    "href": "http://ekonometrics.blogspot.com/2015/04/stata-embraces-bayesian-statistics.html"
  },
  {
    "title": "Catalan numbers for\r\ntriangulations\r\ngambler’s ruin\r\nbinary…",
    "href": "http://isomorphism.es/post/125213068458/catalan-numbers-for-triangulations-gamblers"
  },
  {
    "title": "Partial Dependence Plots",
    "href": "https://web.archive.org/web/http://dpmartin42.github.io/r/partial-dependence"
  },
  {
    "title": "Density Estimation of High-Frequency Financial Data",
    "href": "http://www.theresearchkitchen.com/archives/761"
  },
  {
    "title": "Le Monde puzzle [#920]",
    "href": "https://xianblog.wordpress.com/2015/07/23/le-monde-puzzle-920/"
  },
  {
    "title": "R, the master troll of statistical languages",
    "href": "http://www.talyarkoni.org/blog/2012/06/08/r-the-master-troll-of-statistical-languages/"
  },
  {
    "title": "Assumption Checking – Part I",
    "href": "http://www.beardedanalytics.com/assumption-checking-part-i/"
  },
  {
    "title": "SAS PROC MCMC example in R: Logistic Regression Random-Effects Model",
    "href": "http://wiekvoet.blogspot.com/2015/01/sas-proc-mcmc-example-in-r-logistic.html"
  },
  {
    "title": "GloVe vs word2vec revisited.",
    "href": "http://dsnotes.com//articles/glove-enwiki"
  },
  {
    "title": "Le Monde puzzle [43]",
    "href": "https://xianblog.wordpress.com/2010/11/08/le-monde-puzzle-43/"
  },
  {
    "title": "Flotsam 12: early June linkathon",
    "href": "http://www.quantumforest.com/2013/06/flotsam-12-early-june-linkathon/"
  },
  {
    "title": "Paper: The OpenCPU system – towards a universal interface for scientific computing through separation of concerns",
    "href": "https://www.opencpu.org/posts/opencpu-article-arxiv/"
  },
  {
    "title": "Blog aggregators",
    "href": "http://robjhyndman.com/hyndsight/blog-aggregators/"
  },
  {
    "title": "Job Satisfaction in England – GGPlot #2",
    "href": "https://www.hugedomains.com/domain_profile.cfm?d=amathew&e=com"
  },
  {
    "title": "SNA with R workshop at Sunbelt XXXII in Redondo Beach",
    "href": "http://bc.bojanorama.pl/2012/03/sna-with-r-workshop-at-sunbelt-xxxii-in-redondo-beach/"
  },
  {
    "title": "Two of my favorite data.table features",
    "href": "https://web.archive.org/web/http://educate-r.org//2014/01/06/FavDataTable/"
  },
  {
    "title": "GeoCoding,R, and The Rolling Stones – Part 2",
    "href": "https://rollingyours.wordpress.com/2013/03/20/geocodingr-and-the-rolling-stones-part-2/"
  },
  {
    "title": "Yes, you need more than just R for Big Data Analytics",
    "href": "http://blog.revolutionanalytics.com/2012/05/making-sense-of-big-data-requires-more-than-software.html"
  },
  {
    "title": "Oscar awards: good actor versus good actress",
    "href": "http://blog.free.fr/"
  },
  {
    "title": "Minimum Correlation Algorithm Speed comparison",
    "href": "https://systematicinvestor.wordpress.com/2012/09/26/minimum-correlation-algorithm-speed-comparison/"
  },
  {
    "title": "Drawdown Visualization",
    "href": "http://timelyportfolio.blogspot.com/2011/08/drawdown-visualization.html"
  },
  {
    "title": "Conversion of Meucci’s MatLab Code",
    "href": "https://tradeblotter.wordpress.com/2012/09/07/conversion-of-meuccis-matlab-code/"
  },
  {
    "title": "Consuming R from SAP Mobile Platform",
    "href": "http://blagrants.blogspot.com/2012/11/consuming-r-from-sap-mobile-platform.html"
  },
  {
    "title": "Rotational Trading Strategies: borrowing ideas from Engineering Returns",
    "href": "https://systematicinvestor.wordpress.com/2011/12/20/rotational-trading-strategies-borrowing-ideas-from-engineering-returns/"
  },
  {
    "title": "Project Euler Problem #28",
    "href": "https://web.archive.org/web/http://www.theresearchkitchen.com/blog/archives/371"
  },
  {
    "title": "introduction to R: learning by doing (part 2: plots)",
    "href": "https://web.archive.org/web/http://www.geo-affine.org/2012/07/10/introduction-to-r-learning-by-doing-part-2-plots/"
  },
  {
    "title": "BMS 0.3.1 Released",
    "href": "https://web.archive.org/web/http://bms.zeugner.eu/blog/2012-09-05/bms-031-released"
  },
  {
    "title": "Exploring distributions of Ensatina salamander subspecies using rvertnet by Neil Kelly",
    "href": "https://vijaybarve.wordpress.com/2012/08/09/exploring-distributions-of-ensatina-salamander-subspecies-using-rvertnet-by-neil-kelly/"
  },
  {
    "title": "Datasets handpicked by students",
    "href": "http://citizen-statistician.org/2013/04/15/datasets-handpicked-by-students/"
  },
  {
    "title": "Pegging your multicore CPU in Revolution R, Good and Bad",
    "href": "https://web.archive.org/web/http://www.stat.cmu.edu/~nmv/2010/06/09/pegging-your-multicore-cpu-in-revolution-r-good-and-bad/"
  },
  {
    "title": "OpenAnalytics @ UseR 2013: What’s on the Program?",
    "href": "https://www.openanalytics.eu/blog/openanalytics-user-2013-whats-program"
  },
  {
    "title": "Individuals and Moving Range Charts in R",
    "href": "https://tomhopper.me/2014/03/01/individuals-and-moving-range-charts-in-r/"
  },
  {
    "title": "Exploring Recursive CTEs with sqldf",
    "href": "http://blog.revolutionanalytics.com/2015/12/exploring-recursive-ctes-with-sqldf.html"
  },
  {
    "title": "rPithon vs. rPython",
    "href": "https://statcompute.wordpress.com/2015/03/30/rpithon-vs-rpython/"
  },
  {
    "title": "Oracle’s Strategy for Advanced Analytics",
    "href": "https://blogs.oracle.com/R/entry/oracle_s_strategy_for_advanced"
  },
  {
    "title": "ALUES: Agricultural Land Use Evaluation System, R package",
    "href": "http://alstatr.blogspot.com/2014/10/alues-agricultural-land-use-evaluation.html"
  },
  {
    "title": "Simulate data with R",
    "href": "http://firsttimeprogrammer.blogspot.com/2014/07/simulate-data-with-r.html"
  },
  {
    "title": "Forbes on putting R-based analytics in the hands of business analysts",
    "href": "http://blog.revolutionanalytics.com/2013/10/forbes-on-putting-r-based-analytics-in-the-hands-of-business-analysts-.html"
  },
  {
    "title": "Project Euler — problem 17",
    "href": "https://web.archive.org/web/http://ec2-184-73-106-109.compute-1.amazonaws.com/wordpress/?p=324&utm_source=rss&utm_medium=rss&utm_campaign=project-euler-problem-17"
  },
  {
    "title": "useR! 2012: Call for Late-Breaking Posters; REGULAR REGISTRATION ENDS 12May",
    "href": "https://www.r-bloggers.com/user-2012-call-for-late-breaking-posters-regular-registration-ends-12may/"
  },
  {
    "title": "“Introduction to R” Course Milano; February 21-22, 2013",
    "href": "http://www.milanor.net/blog/introduction-to-r-course-milano-february-21-22-2013/"
  },
  {
    "title": "Visualizing a tiny slice of India’s demographics with information from Wikipedia",
    "href": "http://www.analyticsandvisualization.com/2013/07/visualizing-tiny-slice-of-indias.html"
  },
  {
    "title": "5 new R jobs (for Augest 13th 2014)",
    "href": "https://www.r-bloggers.com/5-new-r-jobs-for-augest-13th-2014/"
  },
  {
    "title": "MAT8886 the Dirichlet distribution",
    "href": "http://blog.free.fr/"
  },
  {
    "title": "Color Quantization in R",
    "href": "http://blog.ryanwalker.us/2016/01/color-quantization-in-r.html"
  },
  {
    "title": "The Art of R Programming – Matloff (2011)",
    "href": "https://feedproxy.google.com/~r/ProgrammingR/~3/gCcxbtnZFxU/"
  },
  {
    "title": "GSOC 2014: Let’s do it again!",
    "href": "https://tradeblotter.wordpress.com/2014/03/12/gsoc-2014-lets-do-it-again/"
  },
  {
    "title": "Revisiting text processing with R and Python",
    "href": "http://bommaritollc.com/2013/05/25/revisiting-text-processing-with-r-and-python/?utm_source=rss&utm_medium=rss&utm_campaign=revisiting-text-processing-with-r-and-python"
  },
  {
    "title": "K-means in images and R",
    "href": "https://web.archive.org/web/http://jkunst.com/post/k-means-images-and-r/"
  }
]
